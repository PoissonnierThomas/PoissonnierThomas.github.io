<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>MainWindow</name>

    <!-- Titre et messages généraux -->
    <message>
        <source>Recipe Manager - S2.01</source>
        <translation>Gestionnaire de Recettes - S2.01</translation>
    </message>
    <message>
        <source>Application started - Lecture mode</source>
        <translation>Application démarrée - Mode lecture</translation>
    </message>

    <!-- Panel Master -->
    <message>
        <source>Recipe list</source>
        <translation>Liste des Recettes</translation>
    </message>
    <message>
        <source>Search for a recipe...</source>
        <translation>Rechercher une recette...</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouvelle</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>

    <!-- Panel Detail -->
    <message>
        <source>Recipe details</source>
        <translation>Détails de la Recette</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Sauvegarder...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>

    <!-- Informations générales -->
    <message>
        <source>General informations</source>
        <translation>Informations Générales</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nom :</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation>Catégorie :</translation>
    </message>
    <message>
        <source>Nb. of people:</source>
        <translation>Nb. personnes :</translation>
    </message>
    <message>
        <source>Price/pers.:</source>
        <translation>Prix/pers. :</translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation>Créateur :</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Date :</translation>
    </message>
    <message>
        <source>Path to the picture</source>
        <translation>Chemin vers l'image</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Parcourir...</translation>
    </message>
    <message>
        <source>Picture:</source>
        <translation>Photo :</translation>
    </message>

    <!-- Catégories -->
    <message>
        <source>Starter</source>
        <translation>Entrée</translation>
    </message>
    <message>
        <source>Main course</source>
        <translation>Plat</translation>
    </message>
    <message>
        <source>Dessert</source>
        <translation>Dessert</translation>
    </message>
    <message>
        <source>Sweet</source>
        <translation>Entremet</translation>
    </message>
    <message>
        <source>Soup</source>
        <translation>Soupe</translation>
    </message>

    <!-- Description -->
    <message>
        <source>Description</source>
        <translation>Description</translation>
    </message>

    <!-- Ingrédients -->
    <message>
        <source>Ingredients</source>
        <translation>Ingrédients</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Quantité</translation>
    </message>
    <message>
        <source>Unit</source>
        <translation>Unité</translation>
    </message>
    <message>
        <source>Double-click on an ingredient to edit it</source>
        <translation>Double-cliquez sur un ingrédient pour le modifier</translation>
    </message>

    <!-- Menus -->
    <message>
        <source>File</source>
        <translation>Fichier</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation>Ouvrir...</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Édition</translation>
    </message>
    <message>
        <source>Edition mode</source>
        <translation>Mode Édition</translation>
    </message>

    <!-- Messages de chargement -->
    <message>
        <source>Default XML loading...</source>
        <translation>Chargement XML par défaut...</translation>
    </message>
    <message>
        <source>Charged recipe:</source>
        <translation>Recette chargée :</translation>
    </message>
    <message>
        <source>Error parsing XML:</source>
        <translation>Erreur parsing XML :</translation>
    </message>
    <message>
        <source>Resource file not found</source>
        <translation>Fichier de ressources non trouvé</translation>
    </message>
    <message>
        <source>No default recipe - Use File > Open</source>
        <translation>Aucune recette par défaut - Utilisez Fichier > Ouvrir</translation>
    </message>

    <!-- Formatage des recettes -->
    <message>
        <source>people</source>
        <translation>personnes</translation>
    </message>

    <!-- Messages de sélection -->
    <message>
        <source>Selected recipe:</source>
        <translation>Recette sélectionnée :</translation>
    </message>
    <message>
        <source>Details: %1</source>
        <translation>Détails : %1</translation>
    </message>
    <message>
        <source>Recipe displayed, Modified Data =</source>
        <translation>Recette affichée, Données modifiées =</translation>
    </message>
    <message>
        <source>Select a recipe</source>
        <translation>Sélectionnez une recette</translation>
    </message>

    <!-- Messages de mode -->
    <message>
        <source>Edition mode active</source>
        <translation>Mode édition activé</translation>
    </message>
    <message>
        <source>Lecture mode</source>
        <translation>Mode lecture</translation>
    </message>

    <!-- Messages de modification -->
    <message>
        <source>Modifications not saved</source>
        <translation>Modifications non sauvegardées</translation>
    </message>
    <message>
        <source>Modified data detected</source>
        <translation>Données modifiées détectées</translation>
    </message>
    <message>
        <source>Recipe saved</source>
        <translation>Recette sauvegardée</translation>
    </message>
    <message>
        <source>Modifications canceled</source>
        <translation>Modifications annulées</translation>
    </message>
    <message>
        <source>Recipe saved:</source>
        <translation>Recette sauvegardée :</translation>
    </message>

    <!-- Dialogue de confirmation -->
    <message>
        <source>Modifications haven't been saved.
Would you like to cancel them?</source>
        <translation>Des modifications n'ont pas été sauvegardées.
Voulez-vous les abandonner ?</translation>
    </message>

    <!-- Création de recette -->
    <message>
        <source>New Recipe</source>
        <translation>Nouvelle Recette</translation>
    </message>
    <message>
        <source>Description of the new recipe</source>
        <translation>Description de la nouvelle recette</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Utilisateur</translation>
    </message>
    <message>
        <source>New recipe created</source>
        <translation>Nouvelle recette créée</translation>
    </message>

    <!-- Suppression de recette -->
    <message>
        <source>Delete the recipe</source>
        <translation>Supprimer la recette</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the '%1' recipe?</source>
        <translation>Êtes-vous sûr de vouloir supprimer la recette '%1' ?</translation>
    </message>
    <message>
        <source>Recipe deleted</source>
        <translation>Recette supprimée</translation>
    </message>

    <!-- Gestion des ingrédients - Ajout -->
    <message>
        <source>New ingredient</source>
        <translation>Nouvel ingrédient</translation>
    </message>
    <message>
        <source>Name of the ingredient:</source>
        <translation>Nom de l'ingrédient :</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Quantité :</translation>
    </message>
    <message>
        <source>Unit (French unit such as: g, ml, piece, etc.):</source>
        <translation>Unité (g, ml, pièce, etc.) :</translation>
    </message>
    <message>
        <source>Ingredient added successfully</source>
        <translation>Ingrédient ajouté avec succès</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <source>Error while adding the ingredient: %1</source>
        <translation>Erreur lors de l'ajout de l'ingrédient : %1</translation>
    </message>

    <!-- Suppression d'ingrédients -->
    <message>
        <source>Delete the ingredient</source>
        <translation>Supprimer l'ingrédient</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the '%1' ingredient?</source>
        <translation>Êtes-vous sûr de vouloir supprimer l'ingrédient '%1' ?</translation>
    </message>
    <message>
        <source>'%1' ingredient deleted successfully</source>
        <translation>Ingrédient '%1' supprimé avec succès</translation>
    </message>
    <message>
        <source>Error while deleting: %1</source>
        <translation>Erreur lors de la suppression : %1</translation>
    </message>

    <!-- Modification d'ingrédients -->
    <message>
        <source>Modify the ingredient</source>
        <translation>Modifier l'ingrédient</translation>
    </message>
    <message>
        <source>Modify the quantity</source>
        <translation>Modifier la quantité</translation>
    </message>
    <message>
        <source>Modify the unit</source>
        <translation>Modifier l'unité</translation>
    </message>
    <message>
        <source>'%1' ingredient modified successfully</source>
        <translation>Ingrédient '%1' modifié avec succès</translation>
    </message>
    <message>
        <source>Error while modifying: %1</source>
        <translation>Erreur lors de la modification : %1</translation>
    </message>

    <!-- Gestion des photos -->
    <message>
        <source>Select a picture</source>
        <translation>Sélectionner une photo</translation>
    </message>
    <message>
        <source>Pictures (*.png *.jpg *.jpeg *.bmp *.gif)</source>
        <translation>Images (*.png *.jpg *.jpeg *.bmp *.gif)</translation>
    </message>

    <!-- Gestion des fichiers -->
    <message>
        <source>Open a recipe file</source>
        <translation>Ouvrir un fichier de recettes</translation>
    </message>
    <message>
        <source>Recipe files (*.xml *.json);;XML files (*.xml);;JSON files (*.json);;All files (*)</source>
        <translation>Fichiers de recettes (*.xml *.json);;Fichiers XML (*.xml);;Fichiers JSON (*.json);;Tous les fichiers (*)</translation>
    </message>
    <message>
        <source>Unrecognized file format. Please choose an XML or JSON file.</source>
        <translation>Format de fichier non reconnu. Veuillez choisir un fichier XML ou JSON.</translation>
    </message>
    <message>
        <source>Cannot open the file: %1</source>
        <translation>Impossible d'ouvrir le fichier : %1</translation>
    </message>
    <message>
        <source>XML file loaded: %1</source>
        <translation>Fichier XML chargé : %1</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation>Erreur de parsing</translation>
    </message>
    <message>
        <source>Error while loading: %1</source>
        <translation>Erreur lors du chargement : %1</translation>
    </message>
    <message>
        <source>JSON error</source>
        <translation>Erreur JSON</translation>
    </message>
    <message>
        <source>JSON parsing error: %1</source>
        <translation>Erreur de parsing JSON : %1</translation>
    </message>
    <message>
        <source>JSON file loaded: %1</source>
        <translation>Fichier JSON chargé : %1</translation>
    </message>

    <!-- Image de la recette -->
    <message>
        <source>Recipe picture</source>
        <translation>Photo de la Recette</translation>
    </message>
    <message>
        <source>No image available</source>
        <translation>Aucune image disponible</translation>
    </message>
    <message>
        <source>Image loaded:</source>
        <translation>Image chargée :</translation>
    </message>
    <message>
        <source>Image not found: %1</source>
        <translation>Image non trouvée : %1</translation>
    </message>
    <message>
        <source>Image not found:</source>
        <translation>Image non trouvée :</translation>
    </message>
    <!-- Mode sombre -->
    <message>
        <source>Dark mode</source>
        <translation>Mode Sombre</translation>
    </message>
    <message>
        <source>Dark mode enabled</source>
        <translation>Mode sombre activé</translation>
    </message>
    <message>
        <source>Light mode enabled</source>
        <translation>Mode clair activé</translation>
    </message>
    <!-- Adaptation des quantités -->
    <message>
        <source>Total price:</source>
        <translation>Prix total :</translation>
    </message>
    <message>
        <source>Quantities shown for original portions</source>
        <translation>Quantités affichées pour les portions originales</translation>
    </message>
    <message>
        <source>Quantities adapted for %1 people</source>
        <translation>Quantités adaptées pour %1 personnes</translation>
    </message>
    <message>
        <source>Original quantity: %1 %2</source>
        <translation>Quantité originale : %1 %2</translation>
    </message>
</context>
</TS>
