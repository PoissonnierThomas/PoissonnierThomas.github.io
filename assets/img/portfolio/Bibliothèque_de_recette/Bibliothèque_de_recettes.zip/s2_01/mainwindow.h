#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QListWidget>
#include <QTableWidget>
#include <QLineEdit>
#include <QComboBox>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QDateEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>
#include <QGroupBox>
#include <QFormLayout>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QScrollArea>
#include <QFrame>
#include <QMenuBar>
#include <QStatusBar>
#include <QAction>
#include <QHeaderView>
#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QCloseEvent>
#include <QResizeEvent>
#include <memory>
#include <QPixmap>
#include <vector>
#include "recette.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Recettes
    void onRecetteSelectionnee();
    void onNouvelleRecette();
    void onSupprimerRecette();
    void onRechercheRecette(const QString &texte);

    // Edition
    void onModeEditionToggled(bool actif);
    void onSauvegarder();
    void onAnnuler();

    // Ingrédients
    void onAjouterIngredient();
    void onSupprimerIngredient();
    void onIngredientSelectionne();
    void onModifierIngredient();

    // Fichiers
    void ouvrirFichier();
    void onParcourirPhoto();

    // Modifications
    void onDonneesModifiees();
    void onModeSombreToggled(bool actif);

    //Sauvegardes
    void sauvegarderFichier();
private:
    //  Widgets principaux
    QWidget *centralWidget;
    QSplitter *mainSplitter;

    // Master Panel (Liste)
    QFrame *frameListeRecettes;
    QLabel *labelTitreListe;
    QLineEdit *lineEditRecherche;
    QListWidget *listWidgetRecettes;
    QPushButton *btnNouvelleRecette;
    QPushButton *btnSupprimerRecette;

    // Detail Panel (édition)
    QFrame *frameDetailRecette;
    QLabel *labelTitreDetail;
    QPushButton *btnSauvegarder;
    QPushButton *btnAnnuler;
    QScrollArea *scrollArea;
    QWidget *scrollContent;

    // Utilitaires
    QGroupBox *groupBoxInfos;
    QLineEdit *lineEditNom;
    QComboBox *comboBoxCategorie;
    QSpinBox *spinBoxNbPersonnes;
    QDoubleSpinBox *doubleSpinBoxPrix;
    QLineEdit *lineEditCreateur;
    QDateEdit *dateEditDate;
    QLineEdit *lineEditPhoto;
    QPushButton *btnParcourirPhoto;

    // Description
    QGroupBox *groupBoxDescription;
    QTextEdit *textEditDescription;

    // Ingrédients
    QGroupBox *groupBoxIngredients;
    QTableWidget *tableWidgetIngredients;
    QPushButton *btnAjouterIngredient;
    QPushButton *btnSupprimerIngredient;

    // Affichage de l'image
    QLabel *labelImageRecette;
    QGroupBox *groupBoxImage;

    // Menu
    QAction *actionOuvrir;
    QAction *actionSauvegarder;
    QAction *actionQuitter;
    QAction *actionModeEdition;
    QAction *actionModeSombre;

    // Données
    std::vector<std::unique_ptr<Recette>> recettes;
    Recette* recetteActuelle;
    bool modeEdition;
    bool donneesModifiees;

    // Sauvegarde pour annulation
    struct DonneesOriginales {
        std::string nom, categorie, photo, createur, description;
        size_t nbConvives;
        double prix;
        Date date;
        std::vector<Ingredient*> ingredients;
    } donneesOriginales;

    // Méthodes
    void setupInterface();
    void setupMenus();
    void setupMasterPanel();
    void setupDetailPanel();
    void connecterSignaux();

    // Gestion des données
    void chargerRecettesParDefaut();
    void chargerRecetteXML(const QString &fichier);
    void chargerRecetteJSON(const QString &fichier);
    void parseRecetteJSON(const QJsonObject &obj);
    Date parseDateJSON(const QString &dateStr);

    // Affichage
    void mettreAJourListeRecettes();
    void afficherRecette(Recette* recette);
    void viderFormulaire();
    void mettreAJourTableIngredients();
    QString formatRecetteListe(const Recette* recette) const;

    // Edition
    void activerEdition(bool activer);
    void connecterSignauxModification();
    void deconnecterSignauxModification();
    void sauvegarderRecetteActuelle();
    void sauvegarderDonneesOriginales();
    void restaurerDonneesOriginales();
    bool confirmerAbandonModifications();
    void sauvegarderRecettesJSON(const QString& fichier);
    void sauvegarderRecettesXML(const QString& fichier);

    // Utilitaires
    void redimensionnerColonnes();
    void appliquerStyle();
    QString formaterPrix(double prix);
    QString categorieVersInterface(const std::string& categorie);
    void chargerImageRecette(const QString& nomImage);
    void appliquerThemeSombre(bool activer);
    bool modeSombre;

protected:
    void resizeEvent(QResizeEvent *event) override;
    void closeEvent(QCloseEvent *event) override;
};

#endif // MAINWINDOW_H
