#include "mainwindow.h"
#include "matricetrajetsdialog.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QFileDialog>
#include <QMessageBox>
#include <QTimer>
#include <QWidget>
#include <QSettings>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <limits>
#define _USE_MATH_DEFINES  // Pour Windows
#include <cmath>

// Fonction pour charger les villes depuis un fichier CSV
std::vector<Ville*> chargerVilles(const QString& fichier) {
    std::vector<Ville*> villes;
    std::ifstream fichierVilles(fichier.toStdString());

    if (!fichierVilles.is_open()) {
        return villes;
    }

    // Ignorer l'en-tête 
    std::string ligne;
    std::getline(fichierVilles, ligne);

    // Lire les villes
    while (std::getline(fichierVilles, ligne)) {
        std::istringstream iss(ligne);
        Ville* ville = new Ville(iss);
        villes.push_back(ville);
    }

    fichierVilles.close();
    return villes;
}

// Fonction pour charger les trajets depuis un fichier CSV
std::vector<Trajet*> chargerTrajets(const QString& fichier, const std::vector<Ville*>& villes) {
    std::vector<Trajet*> trajets;
    std::ifstream fichierTrajets(fichier.toStdString());

    if (!fichierTrajets.is_open()) {
        return trajets;
    }


    std::string ligne;
    // Lire les trajets
    while (std::getline(fichierTrajets, ligne)) {
        std::istringstream iss(ligne);
        Trajet* trajet = new Trajet(iss, villes);
        if (trajet->getVille1() != nullptr && trajet->getVille2() != nullptr) {
            trajets.push_back(trajet);
        } else {
            delete trajet; // Trajet invalide (ville non trouvée)
        }
    }

    fichierTrajets.close();
    return trajets;
}

// Fonction pour avoir le temps en heures et minutes au lieu de minutes simples
QString formaterTemps(size_t minutes) {
    int heures = minutes / 60;
    int minutesRestantes = minutes % 60;

    if (heures > 0) {
        return QString("%1h %2min").arg(heures).arg(minutesRestantes);
    } else {
        return QString("%1min").arg(minutesRestantes);
    }
}

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent), fw(nullptr), routeGroup(nullptr) {
    setWindowTitle("Calculateur de trajets");
    setMinimumSize(1200, 800);

    QFont appFont = QApplication::font();
    QApplication::setFont(appFont);

    // Créer la barre de menu
    QMenuBar* menuBar = new QMenuBar(this);
    menuBar->setFont(appFont);
    setMenuBar(menuBar);

    // Menu Fichier
    QMenu* menuFichier = menuBar->addMenu("&Fichier");
    menuFichier->setFont(appFont);

    QAction* actionChargerVilles = new QAction("Charger fichier &villes", this);
    actionChargerVilles->setShortcut(QKeySequence("Ctrl+V"));
    actionChargerVilles->setFont(appFont);
    menuFichier->addAction(actionChargerVilles);

    QAction* actionChargerTrajets = new QAction("Charger fichier &trajets", this);
    actionChargerTrajets->setShortcut(QKeySequence("Ctrl+T"));
    actionChargerTrajets->setFont(appFont);
    menuFichier->addAction(actionChargerTrajets);

    menuFichier->addSeparator();

    QAction* actionQuitter = new QAction("&Quitter", this);
    actionQuitter->setShortcut(QKeySequence("Ctrl+Q"));
    actionQuitter->setFont(appFont);
    menuFichier->addAction(actionQuitter);

    // Menu Carte
    QMenu* menuCarte = menuBar->addMenu("&Carte");
    menuCarte->setFont(appFont);

    QAction* actionResetView = new QAction("&Réinitialiser la vue", this);
    actionResetView->setShortcut(QKeySequence("Ctrl+R"));
    actionResetView->setFont(appFont);
    menuCarte->addAction(actionResetView);

    QAction* actionZoomIn = new QAction("Zoom &avant", this);
    actionZoomIn->setShortcut(QKeySequence("Ctrl++"));
    actionZoomIn->setFont(appFont);
    menuCarte->addAction(actionZoomIn);

    QAction* actionZoomOut = new QAction("Zoom a&rrière", this);
    actionZoomOut->setShortcut(QKeySequence("Ctrl+-"));
    actionZoomOut->setFont(appFont);
    menuCarte->addAction(actionZoomOut);

    // Menu Affichage
    QMenu* menuAffichage = menuBar->addMenu("&Affichage");
    menuAffichage->setFont(appFont);

    QAction* actionMatriceTrajets = new QAction("&Matrice des trajets directs", this);
    actionMatriceTrajets->setShortcut(QKeySequence("Ctrl+M"));
    actionMatriceTrajets->setFont(appFont);
    menuAffichage->addAction(actionMatriceTrajets);

    // Menu Aide
    QMenu* menuAide = menuBar->addMenu("&Aide");
    menuAide->setFont(appFont);

    QAction* actionAPropos = new QAction("À &propos", this);
    actionAPropos->setFont(appFont);
    menuAide->addAction(actionAPropos);

    // Menu Historique
    menuHistorique = menuBar->addMenu("&Historique");
    menuHistorique->setFont(appFont);

    actionAfficherHistorique = new QAction("&Afficher l'historique", this);
    actionAfficherHistorique->setShortcut(QKeySequence("Ctrl+H"));
    actionAfficherHistorique->setFont(appFont);
    menuHistorique->addAction(actionAfficherHistorique);

    actionViderHistorique = new QAction("&Vider l'historique", this);
    actionViderHistorique->setFont(appFont);
    menuHistorique->addAction(actionViderHistorique);

    // Connexion des actions
    connect(actionAfficherHistorique, &QAction::triggered, this, &MainWindow::afficherHistorique);
    connect(actionViderHistorique, &QAction::triggered, this, &MainWindow::effacerHistorique);

    // Créer la barre d'outils
    QToolBar* toolBar = new QToolBar("Barre d'outils principale", this);
    toolBar->setIconSize(QSize(32, 32)); // Grandes icônes
    toolBar->setMovable(false);
    toolBar->setFont(appFont);
    addToolBar(toolBar);

    // Ajouter des actions avec des icônes du système Qt
    QAction* actionOutilVilles = new QAction(this->style()->standardIcon(QStyle::SP_FileIcon), "Charger villes", this);
    actionOutilVilles->setFont(appFont);
    toolBar->addAction(actionOutilVilles);

    QAction* actionOutilTrajets = new QAction(this->style()->standardIcon(QStyle::SP_DirIcon), "Charger trajets", this);
    actionOutilTrajets->setFont(appFont);
    toolBar->addAction(actionOutilTrajets);

    toolBar->addSeparator();

    QAction* actionOutilCalculer = new QAction(this->style()->standardIcon(QStyle::SP_MediaPlay), "Calculer trajet", this);
    actionOutilCalculer->setFont(appFont);
    actionOutilCalculer->setEnabled(false);
    toolBar->addAction(actionOutilCalculer);

    QAction* actionOutilMatrice = new QAction(this->style()->standardIcon(QStyle::SP_FileDialogDetailedView), "Matrice des trajets", this);
    actionOutilMatrice->setFont(appFont);
    toolBar->addAction(actionOutilMatrice);

    toolBar->addSeparator();

    QAction* actionOutilReset = new QAction(this->style()->standardIcon(QStyle::SP_BrowserReload), "Réinitialiser vue", this);
    actionOutilReset->setFont(appFont);
    toolBar->addAction(actionOutilReset);

    QAction* actionOutilZoomIn = new QAction(this->style()->standardIcon(QStyle::SP_ArrowUp), "Zoom +", this);
    actionOutilZoomIn->setFont(appFont);
    toolBar->addAction(actionOutilZoomIn);

    QAction* actionOutilZoomOut = new QAction(this->style()->standardIcon(QStyle::SP_ArrowDown), "Zoom -", this);
    actionOutilZoomOut->setFont(appFont);
    toolBar->addAction(actionOutilZoomOut);

    // Barre de statut
    QStatusBar* statusBar = new QStatusBar(this);
    statusBar->setFont(appFont);
    setStatusBar(statusBar);
    statusBar->showMessage("Prêt. Commencez par charger un fichier de villes.");

    // Création des widgets
    QWidget* centralWidget = new QWidget(this);
    QVBoxLayout* mainLayout = new QVBoxLayout(centralWidget);

    // Section chargement des données
    /*QHBoxLayout* loadLayout = new QHBoxLayout();
    btnChargerVilles = new QPushButton("Charger les villes");
    btnChargerTrajets = new QPushButton("Charger les trajets");
    loadLayout->addWidget(btnChargerVilles);
    loadLayout->addWidget(btnChargerTrajets);
    mainLayout->addLayout(loadLayout);*/

    // Section sélection des villes avec recherche
    QHBoxLayout* selectionLayout = new QHBoxLayout();

    // Zone de départ
    QVBoxLayout* departLayout = new QVBoxLayout();
    QLabel* lblDepart = new QLabel("Ville de départ:");
    searchDepart = new QLineEdit();
    searchDepart->setPlaceholderText("Tapez pour rechercher une ville");
    labelVilleDepart = new QLabel("Aucune ville sélectionnée");
    labelVilleDepart->setStyleSheet("font-weight: bold; color: blue;");
    listeSuggestionsDepart = new QListWidget();
    listeSuggestionsDepart->setMaximumHeight(200);
    listeSuggestionsDepart->setHidden(true);
    departLayout->addWidget(lblDepart);
    departLayout->addWidget(searchDepart);
    departLayout->addWidget(labelVilleDepart);
    departLayout->addWidget(listeSuggestionsDepart);

    // Zone d'arrivée
    QVBoxLayout* arriveeLayout = new QVBoxLayout();
    QLabel* lblArrivee = new QLabel("Ville d'arrivée:");
    searchArrivee = new QLineEdit();
    searchArrivee->setPlaceholderText("Tapez pour rechercher une ville");
    labelVilleArrivee = new QLabel("Aucune ville sélectionnée");
    labelVilleArrivee->setStyleSheet("font-weight: bold; color: green;");
    listeSuggestionsArrivee = new QListWidget();
    listeSuggestionsArrivee->setMaximumHeight(200);
    listeSuggestionsArrivee->setHidden(true);
    arriveeLayout->addWidget(lblArrivee);
    arriveeLayout->addWidget(searchArrivee);
    arriveeLayout->addWidget(labelVilleArrivee);
    arriveeLayout->addWidget(listeSuggestionsArrivee);

    // Section des étapes intermédiaires
    QVBoxLayout* etapesLayout = new QVBoxLayout();
    QLabel* lblEtapes = new QLabel("Étapes intermédiaires:");
    searchEtape = new QLineEdit();
    searchEtape->setPlaceholderText("Ajouter une étape...");
    listeSuggestionsEtape = new QListWidget();
    listeSuggestionsEtape->setMaximumHeight(150);
    listeSuggestionsEtape->setHidden(true);

    QHBoxLayout* etapeButtonsLayout = new QHBoxLayout();
    btnAjouterEtape = new QPushButton("Ajouter");
    btnAjouterEtape->setEnabled(false);
    btnSupprimerEtape = new QPushButton("Supprimer");
    btnSupprimerEtape->setEnabled(false);
    QPushButton* btnAideEtapes = new QPushButton("?");
    btnAideEtapes->setMaximumWidth(30);
    btnAideEtapes->setToolTip("Afficher l'aide sur les étapes intermédiaires");
    etapeButtonsLayout->addWidget(btnAjouterEtape);
    etapeButtonsLayout->addWidget(btnSupprimerEtape);
    etapeButtonsLayout->addWidget(btnAideEtapes);

    QHBoxLayout* etapeButtonsLayout2 = new QHBoxLayout();
    btnMontrerEtape = new QPushButton("Monter");
    btnMontrerEtape->setEnabled(false);
    btnViderEtapes = new QPushButton("Vider");
    btnViderEtapes->setEnabled(false);
    etapeButtonsLayout2->addWidget(btnMontrerEtape);
    etapeButtonsLayout2->addWidget(btnViderEtapes);

    listeEtapes = new QListWidget();
    listeEtapes->setSelectionMode(QAbstractItemView::SingleSelection);
    listeEtapes->setDragDropMode(QAbstractItemView::InternalMove);
    listeEtapes->setMinimumHeight(100);

    etapesLayout->addWidget(lblEtapes);
    etapesLayout->addWidget(searchEtape);
    etapesLayout->addWidget(listeSuggestionsEtape);
    etapesLayout->addLayout(etapeButtonsLayout);
    etapesLayout->addLayout(etapeButtonsLayout2);
    etapesLayout->addWidget(listeEtapes);

    // Ajouter les layouts 
    selectionLayout->addLayout(departLayout);
    selectionLayout->addLayout(arriveeLayout);
    selectionLayout->addLayout(etapesLayout);
    mainLayout->addLayout(selectionLayout);

    // Bouton de calcul
    btnCalculer = new QPushButton("Calculer le trajet");
    btnCalculer->setEnabled(false);
    mainLayout->addWidget(btnCalculer);

    // Section résultats: disposition côte à côte (carte à gauche, texte à droite)
    QHBoxLayout* resultsLayout = new QHBoxLayout();

    // Initialiser le rendu graphique (carte)
    setupGraphicsView();
    mapView->setMinimumWidth(400); 

    // Label pour la carte
    QVBoxLayout* mapLayout = new QVBoxLayout();
    QLabel* lblMap = new QLabel("Carte du trajet:");
    mapLayout->addWidget(lblMap);
    mapLayout->addWidget(mapView);

    // Bouton de réinitialisation de la vue
    btnResetView = new QPushButton("Réinitialiser la vue");
    mapLayout->addWidget(btnResetView);

    // Résultats textuels
    QVBoxLayout* textLayout = new QVBoxLayout();
    QLabel* lblResultat = new QLabel("Résultats du trajet:");
    txtResultat = new QTextEdit();
    txtResultat->setReadOnly(true);
    textLayout->addWidget(lblResultat);
    textLayout->addWidget(txtResultat);

    // Ajouter les deux sections au layout des résultats
    resultsLayout->addLayout(mapLayout, 1);  // La carte prend 1 unité d'espace
    resultsLayout->addLayout(textLayout, 1); // Les résultats textuels prennent 1 unité d'espace

    mainLayout->addLayout(resultsLayout);

    setCentralWidget(centralWidget);

    // Création des anciens widgets pour compatibilité mais ne pas les afficher
    comboVilleDepart = new QComboBox();
    comboVilleArrivee = new QComboBox();
    comboVilleDepart->hide();
    comboVilleArrivee->hide();

    // Connexion des signaux et slots
    /*connect(btnChargerVilles, &QPushButton::clicked, this, &MainWindow::chargerFichierVilles);
    connect(btnChargerTrajets, &QPushButton::clicked, this, &MainWindow::chargerFichierTrajets);
    */connect(btnCalculer, &QPushButton::clicked, this, &MainWindow::calculerTrajet);
    connect(btnResetView, &QPushButton::clicked, this, &MainWindow::resetView);
    connect(searchDepart, &QLineEdit::textChanged, this, &MainWindow::updateSuggestionsDepart);
    connect(searchArrivee, &QLineEdit::textChanged, this, &MainWindow::updateSuggestionsArrivee);
    connect(listeSuggestionsDepart, &QListWidget::itemClicked, this, &MainWindow::selectVilleDepart);
    connect(listeSuggestionsArrivee, &QListWidget::itemClicked, this, &MainWindow::selectVilleArrivee);

    // Connexions pour les étapes
    connect(searchEtape, &QLineEdit::textChanged, this, &MainWindow::updateSuggestionsEtape);
    connect(listeSuggestionsEtape, &QListWidget::itemClicked, this, &MainWindow::selectVilleEtape);
    connect(btnAjouterEtape, &QPushButton::clicked, this, &MainWindow::ajouterEtape);
    connect(btnSupprimerEtape, &QPushButton::clicked, this, &MainWindow::supprimerEtape);
    connect(btnMontrerEtape, &QPushButton::clicked, this, &MainWindow::monterEtape);
    connect(btnViderEtapes, &QPushButton::clicked, this, &MainWindow::viderEtapes);
    connect(btnAideEtapes, &QPushButton::clicked, this, &MainWindow::afficherAideEtapes);

    connect(listeEtapes, &QListWidget::itemSelectionChanged, [this]() {
        btnSupprimerEtape->setEnabled(listeEtapes->selectedItems().count() > 0);
        btnMontrerEtape->setEnabled(listeEtapes->selectedItems().count() > 0);
    });

    // Connexion des actions de menu et de barre d'outils
    connect(actionChargerVilles, &QAction::triggered, this, &MainWindow::chargerFichierVilles);
    connect(actionChargerTrajets, &QAction::triggered, this, &MainWindow::chargerFichierTrajets);
    connect(actionResetView, &QAction::triggered, this, &MainWindow::resetView);
    connect(actionQuitter, &QAction::triggered, this, &QWidget::close);
    connect(actionMatriceTrajets, &QAction::triggered, this, &MainWindow::afficherMatriceTrajets);

    connect(actionOutilVilles, &QAction::triggered, this, &MainWindow::chargerFichierVilles);
    connect(actionOutilTrajets, &QAction::triggered, this, &MainWindow::chargerFichierTrajets);
    connect(actionOutilCalculer, &QAction::triggered, this, &MainWindow::calculerTrajet);
    connect(actionOutilReset, &QAction::triggered, this, &MainWindow::resetView);
    connect(actionOutilMatrice, &QAction::triggered, this, &MainWindow::afficherMatriceTrajets);

    connect(actionZoomIn, &QAction::triggered, this, [this](){
        mapView->scale(1.2, 1.2);
    });
    connect(actionZoomOut, &QAction::triggered, this, [this](){
        mapView->scale(1/1.2, 1/1.2);
    });
    connect(actionOutilZoomIn, &QAction::triggered, this, [this](){
        mapView->scale(1.2, 1.2);
    });
    connect(actionOutilZoomOut, &QAction::triggered, this, [this](){
        mapView->scale(1/1.2, 1/1.2);
    });

    connect(actionAPropos, &QAction::triggered, this, [this](){
        QMessageBox::about(this, "À propos",
                           "Calculateur de trajets POISSONNIER Thomas S2_02.\n\n"
                           "Cette application permet de calculer le chemin le plus court entre deux villes grâce à l'algorithme de Floyd-Warshall.\n\n"
                           "© Mai 2025 - Arles");
    });

    // Installer le filtre d'événements pour le zoom
    mapView->viewport()->installEventFilter(this);

    // Initialiser les variables de sélection
    selectedVilleDepart = nullptr;
    selectedVilleArrivee = nullptr;

    // Initialiser les chemins de fichiers par défaut
    defaultVillesPath = "";
    defaultTrajetsPath = "";

    // Chager les fichiers au démarrage
    QTimer::singleShot(500, this, &MainWindow::chargerFichiersParDefaut);
}

MainWindow::~MainWindow() {
    // Libération de la mémoire
    for (auto ville : villes) {
        delete ville;
    }
    for (auto trajet : trajets) {
        delete trajet;
    }
    delete fw;
}

void MainWindow::setupGraphicsView() {
    // Créer la scène et la vue
    mapScene = new QGraphicsScene(this);
    mapView = new QGraphicsView(mapScene);

    mapView->setRenderHint(QPainter::Antialiasing);
    mapView->setRenderHint(QPainter::TextAntialiasing);
    mapView->setRenderHint(QPainter::SmoothPixmapTransform);

    // Permettre le zoom avec la molette de la souris
    mapView->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
    mapView->setResizeAnchor(QGraphicsView::AnchorViewCenter);

    // Activer le glisser-déposer pour naviguer dans la carte
    mapView->setDragMode(QGraphicsView::ScrollHandDrag);
    mapView->setInteractive(true);

    // Charger l'image de carte de France
    QPixmap franceCarte(":/ressources/France_contours.png");

    if (franceCarte.isNull()) {
        // Image non trouvée, afficher un message d'erreur
        QGraphicsTextItem* errorText = mapScene->addText("Impossible de charger la carte de France");
        errorText->setDefaultTextColor(Qt::red);
        mapScene->setSceneRect(0, 0, 800, 600);
    } else {
        // Ajouter l'image à la scène
        QGraphicsPixmapItem* mapItem = mapScene->addPixmap(franceCarte);
        mapItem->setZValue(0); // Mettre en arrière-plan

        // Définir la taille de la scène basée sur l'image
        mapScene->setSceneRect(mapItem->boundingRect());
    }

    // Créer le groupe pour les éléments du trajet
    routeGroup = new QGraphicsItemGroup();
    mapScene->addItem(routeGroup);

    // Ajouter un texte d'instructions initial
    QGraphicsTextItem* instructions = mapScene->addText("Calculez un trajet pour l'afficher sur cette carte");
    instructions->setPos(10, 10);
    QFont font = instructions->font();
    font.setPointSize(12);
    font.setItalic(true);
    instructions->setFont(font);
    instructions->setDefaultTextColor(QColor(100, 100, 100));
    instructions->setZValue(10); // Au-dessus de tout

    // Créer un fond blanc semi-transparent pour le texte
    QRectF textRect = instructions->boundingRect();
    QGraphicsRectItem* textBg = new QGraphicsRectItem(textRect);
    textBg->setBrush(QColor(255, 255, 255, 180));
    textBg->setPen(Qt::NoPen);
    textBg->setPos(instructions->pos());
    textBg->setZValue(9); // Juste en dessous du texte
    mapScene->addItem(textBg);

    // Adapter la vue à la scène
    mapView->fitInView(mapScene->sceneRect(), Qt::KeepAspectRatio);
}

QPointF MainWindow::coordToPoint(double longitude, double latitude) const {
    // Limites géographiques de la France (approximatives)
    const double MIN_LONG = -5.5;  // Longitude minimale
    const double MAX_LONG = 9.5;   // Longitude maximale
    const double MIN_LAT = 41.0;   // Latitude minimale
    const double MAX_LAT = 51.5;   // Latitude maximale

    // Récupérer les dimensions de la scène (basées sur l'image)
    QRectF sceneRect = mapScene->sceneRect();

    // Placer les coordonnées entre 0 et 1
    double normalizedX = (longitude - MIN_LONG) / (MAX_LONG - MIN_LONG);
    double normalizedY = 1.0 - (latitude - MIN_LAT) / (MAX_LAT - MIN_LAT); // Inverser Y car latitude augmente vers le nord

    // Convertir en coordonnées de pixels
    double x = sceneRect.x() + normalizedX * sceneRect.width();
    double y = sceneRect.y() + normalizedY * sceneRect.height();

    return QPointF(x, y);
}

void MainWindow::displayRouteOnGraphicsView(const std::vector<const Ville*>& chemin) {
    // Effacer tous les éléments précédents du trajet
    while (!routeGroup->childItems().isEmpty()) {
        QGraphicsItem* item = routeGroup->childItems().first();
        routeGroup->removeFromGroup(item);
        delete item;
    }

    // Si aucun chemin n'est fourni, afficher un message puis retourner
    if (chemin.empty()) {
        QGraphicsTextItem* noPathText = new QGraphicsTextItem("Aucun trajet à afficher");
        noPathText->setPos(10, 50);
        QFont font = noPathText->font();
        font.setPointSize(14);
        font.setBold(true);
        noPathText->setFont(font);
        noPathText->setDefaultTextColor(Qt::red);
        routeGroup->addToGroup(noPathText);
        return;
    }

    // Dessiner les lignes du trajet
    for (size_t i = 0; i < chemin.size() - 1; ++i) {
        const Ville* ville1 = chemin[i];
        const Ville* ville2 = chemin[i + 1];

        QPointF p1 = coordToPoint(ville1->getLongitude(), ville1->getLatitude());
        QPointF p2 = coordToPoint(ville2->getLongitude(), ville2->getLatitude());

        // Créer une ligne avec dégradé de couleur
        QLinearGradient gradient(p1, p2);
        gradient.setColorAt(0, QColor(100, 100, 255)); // Bleu plus clair au début
        gradient.setColorAt(1, QColor(0, 0, 200));     // Bleu plus foncé à la fin

        QPen linePen(gradient, 4, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
        QGraphicsLineItem* line = new QGraphicsLineItem(QLineF(p1, p2));
        line->setPen(linePen);
        line->setZValue(1); // Au-dessus de la carte
        routeGroup->addToGroup(line);

        // Ajouter une flèche directionnelle au milieu de la ligne
        QPointF midPoint = (p1 + p2) / 2;
        QLineF lineF(p1, p2);
        double angle = lineF.angle(); // Angle en degrés

        QPolygonF arrow;
        double arrowSize = 10;
        arrow << QPointF(-arrowSize, -arrowSize/2)
              << QPointF(0, arrowSize/2)
              << QPointF(arrowSize, -arrowSize/2);

        QGraphicsPolygonItem* arrowItem = new QGraphicsPolygonItem(arrow);
        arrowItem->setBrush(QColor(0, 0, 150));
        arrowItem->setPen(Qt::NoPen);
        arrowItem->setPos(midPoint);
        arrowItem->setRotation(-angle);
        arrowItem->setZValue(2);
        routeGroup->addToGroup(arrowItem);
    }

    // Dessiner les points pour chaque ville du trajet
    for (size_t i = 0; i < chemin.size(); ++i) {
        const Ville* ville = chemin[i];
        QPointF center = coordToPoint(ville->getLongitude(), ville->getLatitude());

        QColor pointColor;
        double pointSize;

        if (i == 0) {
            // Point de départ en vert
            pointColor = QColor(0, 150, 0);
            pointSize = 16;
        } else if (i == chemin.size() - 1) {
            // Point d'arrivée en rouge
            pointColor = QColor(200, 0, 0);
            pointSize = 16;
        } else {
            // Vérifier si c'est une étape définie par l'utilisateur
            bool estEtapeDefinie = false;

            // Vérifier si c'est une étape définie par l'utilisateur
            for (const Ville* etape : etapesIntermediaires) {
                if (ville == etape) {
                    // Étape définie en violet
                    pointColor = QColor(150, 0, 150);
                    pointSize = 14;
                    estEtapeDefinie = true;
                    break;
                }
            }

            if (!estEtapeDefinie) {
                // Points de passage en bleu
                pointColor = QColor(0, 0, 200);
                pointSize = 10;
            }
        }

        // Ajouter une ombre pour donner un effet 3D
        QRadialGradient shadowGradient(center.x(), center.y(), pointSize * 0.7);
        shadowGradient.setColorAt(0, QColor(0, 0, 0, 70));
        shadowGradient.setColorAt(1, QColor(0, 0, 0, 0));

        QGraphicsEllipseItem* shadow = new QGraphicsEllipseItem(
            center.x() - pointSize/2 + 2,
            center.y() - pointSize/2 + 2,
            pointSize, pointSize);
        shadow->setBrush(shadowGradient);
        shadow->setPen(Qt::NoPen);
        shadow->setZValue(2.8);
routeGroup->addToGroup(shadow);

        // Effet de brillance sur le point
        QRadialGradient pointGradient(center.x() - pointSize/4, center.y() - pointSize/4, pointSize);
        pointGradient.setColorAt(0, pointColor.lighter(150));
        pointGradient.setColorAt(0.7, pointColor);
        pointGradient.setColorAt(1, pointColor.darker(150));

        QGraphicsEllipseItem* point = new QGraphicsEllipseItem(
            center.x() - pointSize/2,
            center.y() - pointSize/2,
            pointSize, pointSize);
        point->setBrush(pointGradient);
        point->setPen(QPen(pointColor.darker(), 1.5));
        point->setZValue(3);
        routeGroup->addToGroup(point);

        // Ajouter le nom de la ville avec un cadre blanc pour lisibilité
        QGraphicsTextItem* text = new QGraphicsTextItem(QString::fromStdString(ville->getNom()));
        text->setPos(center.x() + pointSize, center.y() - pointSize * 1.5);
        text->setZValue(3.5);

        // Style du texte
        QFont font = text->font();
        font.setPointSize(12);
        text->setFont(font);

        // Vérifier les différents types de points et appliquer le style approprié
        bool estEtapeDefinie = false;
        for (size_t etapeIdx = 0; etapeIdx < etapesIntermediaires.size(); ++etapeIdx) {
            if (ville == etapesIntermediaires[etapeIdx]) {
                text->setPlainText(text->toPlainText() + QString(" (Étape %1)").arg(etapeIdx + 1));
                text->setDefaultTextColor(QColor(150, 0, 150));
                font.setBold(true);
                text->setFont(font);
                estEtapeDefinie = true;
                break;
            }
        }

        if (i == 0) {
            text->setPlainText(text->toPlainText() + " (Départ)");
            text->setDefaultTextColor(QColor(0, 100, 0));
            font.setBold(true);
            font.setPointSize(14);
            text->setFont(font);
        } else if (i == chemin.size() - 1) {
            text->setPlainText(text->toPlainText() + " (Arrivée)");
            text->setDefaultTextColor(QColor(150, 0, 0));
            font.setBold(true);
            font.setPointSize(14);
            text->setFont(font);
        } else if (!estEtapeDefinie) {
            text->setDefaultTextColor(QColor(0, 0, 150));
        }

        // Ajouter un rectangle blanc semi-transparent derrière le texte
        QRectF textRect = text->boundingRect();
        QGraphicsRectItem* textBg = new QGraphicsRectItem(textRect);
        textBg->setBrush(QColor(255, 255, 255, 220));
        textBg->setPen(QPen(QColor(230, 230, 230), 1));
        textBg->setPos(text->pos());
        textBg->setZValue(3.2);

        routeGroup->addToGroup(textBg);
        routeGroup->addToGroup(text);

        // Ajouter des informations supplémentaires sur la ville en infobulle
        QString tooltip = QString("%1\nPays: %2\nPopulation: %3\nCoordonnées: %4, %5")
                              .arg(QString::fromStdString(ville->getNom()))
                              .arg(QString::fromStdString(ville->getPays()))
                              .arg(ville->getPopulation())
                              .arg(ville->getLatitude())
                              .arg(ville->getLongitude());

        // Créer une zone invisible mais interactive pour l'infobulle
        QGraphicsRectItem* tooltipArea = new QGraphicsRectItem(
            center.x() - pointSize,
            center.y() - pointSize,
            pointSize * 2,
            pointSize * 2);
        tooltipArea->setPen(Qt::NoPen);
        tooltipArea->setBrush(Qt::transparent);
        tooltipArea->setToolTip(tooltip);
        tooltipArea->setZValue(4);
        tooltipArea->setAcceptHoverEvents(true);
        routeGroup->addToGroup(tooltipArea);
    }

    // Ajouter une légende
    createLegend();

    // Ajuster la vue pour montrer le trajet complet si le nombre de villes est petit
    if (chemin.size() < 10) {
        QRectF boundingRect = routeGroup->boundingRect();
        mapView->fitInView(boundingRect.adjusted(-50, -50, 50, 50), Qt::KeepAspectRatio);
    } else {
        // Sinon, donner une vue générale de la France
        mapView->fitInView(mapScene->sceneRect(), Qt::KeepAspectRatio);
    }
}

void MainWindow::createLegend() {
    // Position et dimensions de la légende
    int legendX = 20;
    int legendY = 20;
    int legendWidth = 190;
    int legendHeight = 160; // Augmenté pour ajouter la légende pour les étapes
    int itemHeight = 25;

    // Créer la boîte de légende
    QGraphicsRectItem* legendBg = new QGraphicsRectItem(0, 0, legendWidth, legendHeight);
    legendBg->setBrush(QColor(255, 255, 255, 230));
    legendBg->setPen(QPen(Qt::gray, 1));
    legendBg->setPos(legendX, legendY);
    legendBg->setZValue(5);
    routeGroup->addToGroup(legendBg);

    // Titre de la légende
    QGraphicsTextItem* legendTitle = new QGraphicsTextItem("Légende");
    legendTitle->setFont(QFont("Arial", 16, QFont::Bold));
    legendTitle->setPos(legendX + 10, legendY + 5);
    legendTitle->setZValue(5.1);
    routeGroup->addToGroup(legendTitle);

    // Point de départ
    QGraphicsEllipseItem* startPoint = new QGraphicsEllipseItem(
        legendX + 10,
        legendY + legendTitle->boundingRect().height() + 15,
        12, 12);
    startPoint->setBrush(QColor(0, 150, 0));
    startPoint->setPen(QPen(QColor(0, 100, 0), 1));
    startPoint->setZValue(5.1);
    routeGroup->addToGroup(startPoint);

    QGraphicsTextItem* startText = new QGraphicsTextItem("Ville de départ");
    QFont legendFont = startText->font();
    legendFont.setPointSize(11);
    startText->setFont(legendFont);
    startText->setPos(legendX + 30, legendY + legendTitle->boundingRect().height() + 10);
    startText->setZValue(5.1);
    routeGroup->addToGroup(startText);

    // Point étape
    QGraphicsEllipseItem* etapePoint = new QGraphicsEllipseItem(
        legendX + 10,
        legendY + legendTitle->boundingRect().height() + 15 + itemHeight,
        12, 12);
    etapePoint->setBrush(QColor(150, 0, 150));
    etapePoint->setPen(QPen(QColor(100, 0, 100), 1));
    etapePoint->setZValue(5.1);
    routeGroup->addToGroup(etapePoint);

    QGraphicsTextItem* etapeText = new QGraphicsTextItem("Étape définie");
    etapeText->setFont(legendFont);
    etapeText->setPos(legendX + 30, legendY + legendTitle->boundingRect().height() + 10 + itemHeight);
    etapeText->setZValue(5.1);
    routeGroup->addToGroup(etapeText);

    // Point intermédiaire
    QGraphicsEllipseItem* midPoint = new QGraphicsEllipseItem(
        legendX + 10,
        legendY + legendTitle->boundingRect().height() + 15 + itemHeight * 2,
        12, 12);
    midPoint->setBrush(QColor(0, 0, 200));
    midPoint->setPen(QPen(QColor(0, 0, 150), 1));
    midPoint->setZValue(5.1);
    routeGroup->addToGroup(midPoint);

    QGraphicsTextItem* midText = new QGraphicsTextItem("Ville intermédiaire");
    midText->setFont(legendFont);
    midText->setPos(legendX + 30, legendY + legendTitle->boundingRect().height() + 10 + itemHeight * 2);
    midText->setZValue(5.1);
    routeGroup->addToGroup(midText);

    // Point d'arrivée
    QGraphicsEllipseItem* endPoint = new QGraphicsEllipseItem(
        legendX + 10,
        legendY + legendTitle->boundingRect().height() + 15 + itemHeight * 3,
        12, 12);
    endPoint->setBrush(QColor(200, 0, 0));
    endPoint->setPen(QPen(QColor(150, 0, 0), 1));
    endPoint->setZValue(5.1);
    routeGroup->addToGroup(endPoint);

    QGraphicsTextItem* endText = new QGraphicsTextItem("Ville d'arrivée");
    endText->setFont(legendFont);
    endText->setPos(legendX + 30, legendY + legendTitle->boundingRect().height() + 10 + itemHeight * 3);
    endText->setZValue(5.1);
    routeGroup->addToGroup(endText);

    // Ligne de trajet
    QGraphicsLineItem* pathLine = new QGraphicsLineItem(
        legendX + 10,
        legendY + legendTitle->boundingRect().height() + 21 + itemHeight * 4,
        legendX + 25,
        legendY + legendTitle->boundingRect().height() + 21 + itemHeight * 4);
    pathLine->setPen(QPen(QColor(0, 0, 200), 4, Qt::SolidLine, Qt::RoundCap));
    pathLine->setZValue(5.1);
    routeGroup->addToGroup(pathLine);

    QGraphicsTextItem* pathText = new QGraphicsTextItem("Trajet");
    pathText->setFont(legendFont);
    pathText->setPos(legendX + 30, legendY + legendTitle->boundingRect().height() + 10 + itemHeight * 4);
    pathText->setZValue(5.1);
    routeGroup->addToGroup(pathText);
}

void MainWindow::resetView() {
    if (mapView && mapScene) {
        mapView->fitInView(mapScene->sceneRect(), Qt::KeepAspectRatio);
    }
}

void MainWindow::resizeEvent(QResizeEvent* event) {
    QMainWindow::resizeEvent(event);

    // Adapter la vue à chaque redimensionnement
    if (mapView && mapScene) {
        mapView->fitInView(mapScene->sceneRect(), Qt::KeepAspectRatio);
    }
}

bool MainWindow::eventFilter(QObject* obj, QEvent* event) {
    if (obj == mapView->viewport()) {
        if (event->type() == QEvent::Wheel) {
            QWheelEvent* wheelEvent = static_cast<QWheelEvent*>(event);

            // Zoom avec Ctrl+molette
            if (wheelEvent->modifiers() & Qt::ControlModifier) {
                if (wheelEvent->angleDelta().y() > 0) {
                    // Zoom in
                    mapView->scale(1.2, 1.2);
                } else {
                    // Zoom out
                    mapView->scale(1/1.2, 1/1.2);
                }
                return true;
            }
        }
    }
    return QMainWindow::eventFilter(obj, event);
}

void MainWindow::updateSuggestionsDepart(const QString& text) {
    listeSuggestionsDepart->clear();
    if (text.isEmpty()) {
        listeSuggestionsDepart->setHidden(true);
        return;
    }

    listeSuggestionsDepart->setHidden(false);
    int count = 0;
    for (const auto& ville : villes) {
        QString nomVille = QString::fromStdString(ville->getNom() + " (" + ville->getPays() + ")");
        if (nomVille.contains(text, Qt::CaseInsensitive)) {
            QListWidgetItem* item = new QListWidgetItem(nomVille);
            item->setData(Qt::UserRole, QVariant::fromValue(static_cast<void*>(ville)));
            listeSuggestionsDepart->addItem(item);
            count++;

            // Limiter le nombre de suggestions pour de meilleures performances
            if (count >= 10) break;
        }
    }
}

void MainWindow::updateSuggestionsArrivee(const QString& text) {
    listeSuggestionsArrivee->clear();
    if (text.isEmpty()) {
        listeSuggestionsArrivee->setHidden(true);
        return;
    }

    listeSuggestionsArrivee->setHidden(false);
    int count = 0;
    for (const auto& ville : villes) {
        QString nomVille = QString::fromStdString(ville->getNom() + " (" + ville->getPays() + ")");
        if (nomVille.contains(text, Qt::CaseInsensitive)) {
            QListWidgetItem* item = new QListWidgetItem(nomVille);
            item->setData(Qt::UserRole, QVariant::fromValue(static_cast<void*>(ville)));
            listeSuggestionsArrivee->addItem(item);
            count++;

            // Limiter le nombre de suggestions pour de meilleures performances
            if (count >= 10) break;
        }
    }
}

void MainWindow::updateSuggestionsEtape(const QString& text) {
    listeSuggestionsEtape->clear();
    btnAjouterEtape->setEnabled(false);

    if (text.isEmpty()) {
        listeSuggestionsEtape->setHidden(true);
        return;
    }

    listeSuggestionsEtape->setHidden(false);
    int count = 0;
    for (const auto& ville : villes) {
        QString nomVille = QString::fromStdString(ville->getNom() + " (" + ville->getPays() + ")");
        if (nomVille.contains(text, Qt::CaseInsensitive)) {
            QListWidgetItem* item = new QListWidgetItem(nomVille);
            item->setData(Qt::UserRole, QVariant::fromValue(static_cast<void*>(ville)));
            listeSuggestionsEtape->addItem(item);
            count++;

            // Limiter le nombre de suggestions
            if (count >= 10) break;
        }
    }
}

void MainWindow::selectVilleDepart(QListWidgetItem* item) {
    selectedVilleDepart = static_cast<Ville*>(item->data(Qt::UserRole).value<void*>());
    searchDepart->setText(item->text());
    labelVilleDepart->setText(QString::fromStdString("Sélectionné: " + selectedVilleDepart->getNom()));
    listeSuggestionsDepart->setHidden(true);
    btnCalculer->setEnabled(selectedVilleDepart != nullptr && selectedVilleArrivee != nullptr && !trajets.empty());

    // Mettre à jour également le bouton dans la barre d'outils
    QList<QAction*> actions = this->findChildren<QToolBar*>().first()->actions();
    for (QAction* action : actions) {
        if (action->text() == "Calculer trajet") {
            action->setEnabled(selectedVilleDepart != nullptr && selectedVilleArrivee != nullptr && !trajets.empty());
            break;
        }
    }

    // Mettre à jour la barre de statut
    if (selectedVilleDepart != nullptr) {
        statusBar()->showMessage(QString("Ville de départ sélectionnée : %1").arg(QString::fromStdString(selectedVilleDepart->getNom())), 3000);
    }
}

void MainWindow::selectVilleArrivee(QListWidgetItem* item) {
    selectedVilleArrivee = static_cast<Ville*>(item->data(Qt::UserRole).value<void*>());
    searchArrivee->setText(item->text());
    labelVilleArrivee->setText(QString::fromStdString("Sélectionné: " + selectedVilleArrivee->getNom()));
    listeSuggestionsArrivee->setHidden(true);
    btnCalculer->setEnabled(selectedVilleDepart != nullptr && selectedVilleArrivee != nullptr && !trajets.empty());

    // Mettre à jour également le bouton dans la barre d'outils
    QList<QAction*> actions = this->findChildren<QToolBar*>().first()->actions();
    for (QAction* action : actions) {
        if (action->text() == "Calculer trajet") {
            action->setEnabled(selectedVilleDepart != nullptr && selectedVilleArrivee != nullptr && !trajets.empty());
            break;
        }
    }

    // Mettre à jour la barre de statut
    if (selectedVilleArrivee != nullptr) {
        statusBar()->showMessage(QString("Ville d'arrivée sélectionnée : %1").arg(QString::fromStdString(selectedVilleArrivee->getNom())), 3000);
    }
}

void MainWindow::selectVilleEtape(QListWidgetItem* item) {
    Ville* villeSelectionnee = static_cast<Ville*>(item->data(Qt::UserRole).value<void*>());
    searchEtape->setText(item->text());
    listeSuggestionsEtape->setHidden(true);
    btnAjouterEtape->setEnabled(true);

    // Stocker temporairement la ville sélectionnée dans searchEtape
    searchEtape->setProperty("selectedVille", QVariant::fromValue(static_cast<void*>(villeSelectionnee)));
}

void MainWindow::resetSelections() {
    selectedVilleDepart = nullptr;
    selectedVilleArrivee = nullptr;
    searchDepart->clear();
    searchArrivee->clear();
    labelVilleDepart->setText("Aucune ville sélectionnée");
    labelVilleArrivee->setText("Aucune ville sélectionnée");
    listeSuggestionsDepart->clear();
    listeSuggestionsArrivee->clear();
    listeSuggestionsDepart->setHidden(true);
    listeSuggestionsArrivee->setHidden(true);
    btnCalculer->setEnabled(false);

    // Vider aussi les étapes
    viderEtapes();
}

void MainWindow::chargerFichierVilles() {
    QString fichier = QFileDialog::getOpenFileName(this, "Sélectionner le fichier des villes", "", "Fichiers CSV (*.csv)");

    if (fichier.isEmpty()) {
        return;
    }

    // Nettoyer les villes existantes
    for (auto ville : villes) {
        delete ville;
    }
    villes.clear();

    // Réinitialiser les sélections
    resetSelections();

    // Pour la compatibilité avec l'ancien code
    comboVilleDepart->clear();
    comboVilleArrivee->clear();

    // Charger les nouvelles villes
    villes = chargerVilles(fichier);

    if (villes.empty()) {
        QMessageBox::warning(this, "Erreur", "Aucune ville n'a pu être chargée.");
        return;
    }

    // Tri des villes par nom pour faciliter la recherche
    std::sort(villes.begin(), villes.end(),
              [](const Ville* a, const Ville* b) {
                  return a->getNom() < b->getNom();
              });

    // Pour la compatibilité avec l'ancien code, remplir les combobox cachés
    for (const auto& ville : villes) {
        QString nomVille = QString::fromStdString(ville->getNom() + " (" + ville->getPays() + ")");
        comboVilleDepart->addItem(nomVille);
        comboVilleArrivee->addItem(nomVille);
    }

    txtResultat->setText(QString("Chargement de %1 villes réussi. Commencez à taper dans les champs de recherche pour sélectionner des villes.").arg(villes.size()));

    // Sauvegarder le chemin du fichier
    defaultVillesPath = fichier;

    if (!trajets.empty()) {
        statusBar()->showMessage(QString("%1 villes et %2 trajets chargés.").arg(villes.size()).arg(trajets.size()), 5000);
    } else {
        statusBar()->showMessage(QString("%1 villes chargées. Veuillez maintenant charger les trajets.").arg(villes.size()), 5000);
    }
}

void MainWindow::chargerFichierTrajets() {
    if (villes.empty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez d'abord charger les villes.");
        return;
    }

    QString fichier = QFileDialog::getOpenFileName(this, "Sélectionner le fichier des trajets", "", "Fichiers CSV (*.csv)");

    if (fichier.isEmpty()) {
        return;
    }

    // Nettoyer les trajets existants
    for (auto trajet : trajets) {
        delete trajet;
    }
    trajets.clear();
    delete fw;
    fw = nullptr;

    // Charger les nouveaux trajets
    trajets = chargerTrajets(fichier, villes);

    if (trajets.empty()) {
        QMessageBox::warning(this, "Erreur", "Aucun trajet n'a pu être chargé.");
        return;
    }

    // Sauvegarder le chemin du fichier
    defaultTrajetsPath = fichier;

    txtResultat->append(QString("Chargement de %1 trajets réussi.").arg(trajets.size()));

    // Créer le graphe Floyd-Warshall
    fw = new FloydWarshall(villes, trajets);

    // Activer le bouton de calcul si les villes sont sélectionnées
    btnCalculer->setEnabled(selectedVilleDepart != nullptr && selectedVilleArrivee != nullptr);

    statusBar()->showMessage(QString("%1 trajets chargés avec succès.").arg(trajets.size()), 5000);
}

void MainWindow::ajouterEtape() {
    Ville* villeEtape = static_cast<Ville*>(searchEtape->property("selectedVille").value<void*>());

    if (!villeEtape) return;

    // Vérifier que cette ville n'est pas déjà dans la liste des étapes
    for (int i = 0; i < listeEtapes->count(); ++i) {
        QListWidgetItem* item = listeEtapes->item(i);
        Ville* ville = static_cast<Ville*>(item->data(Qt::UserRole).value<void*>());
        if (ville == villeEtape) {
            QMessageBox::warning(this, "Étape déjà ajoutée",
                                "Cette ville est déjà présente dans les étapes.");
            return;
        }
    }

    // Vérifier que cette ville n'est ni le départ ni l'arrivée
    if (villeEtape == selectedVilleDepart || villeEtape == selectedVilleArrivee) {
        QMessageBox::warning(this, "Étape invalide",
                            "Cette ville est déjà définie comme départ ou arrivée.");
        return;
    }

    // Ajouter l'étape à la liste
    QListWidgetItem* newItem = new QListWidgetItem(searchEtape->text());
    newItem->setData(Qt::UserRole, QVariant::fromValue(static_cast<void*>(villeEtape)));
    listeEtapes->addItem(newItem);

    // Ajouter à notre vecteur d'étapes
    etapesIntermediaires.push_back(villeEtape);

    // Activer le bouton vider
    btnViderEtapes->setEnabled(true);

    // Effacer le champ de recherche et la sélection
    searchEtape->clear();
    searchEtape->setProperty("selectedVille", QVariant());
    btnAjouterEtape->setEnabled(false);

    // Mettre à jour le statut
    statusBar()->showMessage("Étape ajoutée: " + QString::fromStdString(villeEtape->getNom()), 3000);
}

void MainWindow::supprimerEtape() {
    QList<QListWidgetItem*> selectedItems = listeEtapes->selectedItems();
    if (selectedItems.isEmpty()) return;

    QListWidgetItem* selectedItem = selectedItems.first();
    int row = listeEtapes->row(selectedItem);

    // Supprimer l'étape de notre vecteur
    if (row >= 0 && row < static_cast<int>(etapesIntermediaires.size())) {
        etapesIntermediaires.erase(etapesIntermediaires.begin() + row);
    }

    // Supprimer l'item de la liste
    delete listeEtapes->takeItem(row);

    // Désactiver le bouton vider si plus d'étapes
    btnViderEtapes->setEnabled(listeEtapes->count() > 0);
    btnSupprimerEtape->setEnabled(false);
    btnMontrerEtape->setEnabled(false);

    // Mettre à jour le statut
    statusBar()->showMessage("Étape supprimée", 3000);
}

void MainWindow::monterEtape() {
    QList<QListWidgetItem*> selectedItems = listeEtapes->selectedItems();
    if (selectedItems.isEmpty()) return;

    QListWidgetItem* selectedItem = selectedItems.first();
    int row = listeEtapes->row(selectedItem);

    if (row > 0) {
        // Échanger dans la liste visuelle
        QListWidgetItem* item = listeEtapes->takeItem(row);
        listeEtapes->insertItem(row - 1, item);
        listeEtapes->setCurrentItem(item);

        // Échanger dans notre vecteur
        std::swap(etapesIntermediaires[row], etapesIntermediaires[row - 1]);
    }
}

void MainWindow::viderEtapes() {
    // Demander confirmation
    QMessageBox::StandardButton reponse = QMessageBox::question(this,
        "Confirmer", "Voulez-vous supprimer toutes les étapes ?",
        QMessageBox::Yes|QMessageBox::No);

    if (reponse == QMessageBox::Yes) {
        // Vider la liste visuelle
        listeEtapes->clear();

        // Vider notre vecteur
        etapesIntermediaires.clear();

        // Désactiver les boutons
        btnViderEtapes->setEnabled(false);
        btnSupprimerEtape->setEnabled(false);
        btnMontrerEtape->setEnabled(false);

        // Mettre à jour le statut
        statusBar()->showMessage("Toutes les étapes ont été supprimées", 3000);
    }
}

std::vector<const Ville*> MainWindow::calculerItineraireAvecEtapes() {
    std::vector<const Ville*> itineraireComplet;

    if (!selectedVilleDepart || !selectedVilleArrivee || trajets.empty()) {
        return itineraireComplet;
    }

    // Si aucune étape, calculer l'itinéraire direct
    if (etapesIntermediaires.empty()) {
        std::vector<const Ville*> chemin = fw->getChemin(selectedVilleDepart, selectedVilleArrivee);
        size_t temps = fw->getTempsTrajet(selectedVilleDepart, selectedVilleArrivee);
        ResultatChemin resultat = {temps, chemin};
    }

    // Calculer l'itinéraire par segments
    std::vector<const Ville*> points;
    points.push_back(selectedVilleDepart);

    // Ajouter toutes les étapes intermédiaires
    for (Ville* etape : etapesIntermediaires) {
        points.push_back(etape);
    }

    points.push_back(selectedVilleArrivee);

    // Construire l'itinéraire complet
    for (size_t i = 0; i < points.size() - 1; ++i) {
        const Ville* pointDepart = points[i];
        const Ville* pointArrivee = points[i + 1];

        std::vector<const Ville*> chemin = fw->getChemin(pointDepart, pointArrivee);
        size_t temps = fw->getTempsTrajet(pointDepart, pointArrivee);
        ResultatChemin segment = {temps, chemin};

        if (segment.chemin.empty()) {
            // Aucun chemin pour ce segment
            QMessageBox::warning(this, "Trajet impossible",
                               QString("Impossible de trouver un chemin entre %1 et %2.")
                               .arg(QString::fromStdString(pointDepart->getNom()))
                               .arg(QString::fromStdString(pointArrivee->getNom())));
            return std::vector<const Ville*>();
        }

        // Ajouter le segment au chemin complet (sauf le point d'arrivée s'il n'est pas le dernier segment)
        if (i == 0) {
            // Pour le premier segment, ajouter tout le chemin
            itineraireComplet.insert(itineraireComplet.end(), segment.chemin.begin(), segment.chemin.end());
        } else {
            // Pour les segments suivants, ne pas répéter le premier point (déjà ajouté)
            itineraireComplet.insert(itineraireComplet.end(), segment.chemin.begin() + 1, segment.chemin.end());
        }
    }

    return itineraireComplet;
}

void MainWindow::calculerTrajet() {
    if (!fw || villes.empty() || trajets.empty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez charger les villes et les trajets.");
        return;
    }

    if (!selectedVilleDepart || !selectedVilleArrivee) {
        QMessageBox::warning(this, "Erreur", "Veuillez sélectionner les villes de départ et d'arrivée.");
        return;
    }

    if (selectedVilleDepart == selectedVilleArrivee && etapesIntermediaires.empty()) {
        txtResultat->setText("La ville de départ et d'arrivée sont identiques. Temps de trajet : 0 min.");

        // Effacer le trajet précédent sur la carte
        if (routeGroup) {
            while (!routeGroup->childItems().isEmpty()) {
                QGraphicsItem* item = routeGroup->childItems().first();
                routeGroup->removeFromGroup(item);
                delete item;
            }
        }
        return;
    }

    // Afficher des informations de débogage
    txtResultat->setText(QString("Recherche de trajet entre %1 et %2...\n")
                             .arg(QString::fromStdString(selectedVilleDepart->getNom()))
                             .arg(QString::fromStdString(selectedVilleArrivee->getNom())));

    if (!etapesIntermediaires.empty()) {
        txtResultat->append("Étapes intermédiaires :");
        for (const Ville* etape : etapesIntermediaires) {
            txtResultat->append(" - " + QString::fromStdString(etape->getNom()));
        }
        txtResultat->append("");
    }

    // Calcul de l'itinéraire avec étapes si nécessaire
    std::vector<const Ville*> chemin = calculerItineraireAvecEtapes();

    // Si un trajet a été trouvé, l'afficher sur la carte
    if (!chemin.empty()) {
        displayRouteOnGraphicsView(chemin);

        // Calculer le temps total et la distance totale
        size_t tempsTotal = 0;
        double distanceTotale = 0.0;

        for (size_t i = 0; i < chemin.size() - 1; ++i) {
            const Ville* ville1 = chemin[i];
            const Ville* ville2 = chemin[i + 1];

            // Trouver le temps de ce segment
            for (const auto& trajet : trajets) {
                if ((trajet->getVille1() == ville1 && trajet->getVille2() == ville2) ||
                    (trajet->getVille2() == ville1 && trajet->getVille1() == ville2)) {
                    tempsTotal += trajet->getTemps();
                    break;
                }
            }

            // Calculer la distance approximative
            const double R = 6371; // Rayon de la Terre en km
            double lat1 = ville1->getLatitude() * M_PI / 180;
            double lat2 = ville2->getLatitude() * M_PI / 180;
            double dLat = (ville2->getLatitude() - ville1->getLatitude()) * M_PI / 180;
            double dLon = (ville2->getLongitude() - ville1->getLongitude()) * M_PI / 180;

            double a = sin(dLat/2) * sin(dLat/2) + cos(lat1) * cos(lat2) * sin(dLon/2) * sin(dLon/2);
            double c = 2 * atan2(sqrt(a), sqrt(1-a));
            double d = R * c;

            distanceTotale += d;
        }


        // Si un trajet a été trouvé avec succès, l'ajouter à l'historique
        if (!chemin.empty() && tempsTotal > 0) {
            // Récupérer les noms des étapes intermédiaires
            std::vector<QString> nomsEtapes;
            for (const Ville* etape : etapesIntermediaires) {
                nomsEtapes.push_back(QString::fromStdString(etape->getNom()));
            }

            // Créer un objet TrajetHistorique
            TrajetHistorique trajetHisto(
                QString::fromStdString(selectedVilleDepart->getNom()),
                QString::fromStdString(selectedVilleArrivee->getNom()),
                nomsEtapes,
                tempsTotal,
                distanceTotale,
                QDateTime::currentDateTime()
                );

            // Ajouter à l'historique
            ajouterTrajetHistorique(trajetHisto);
        }

        // Afficher l'itinéraire textuel
        QString texteResultat = QString("Trajet trouvé entre %1 et %2 :\n\n")
                                    .arg(QString::fromStdString(selectedVilleDepart->getNom()))
                                    .arg(QString::fromStdString(selectedVilleArrivee->getNom()));

        texteResultat += "Itinéraire :\n";
        for (size_t i = 0; i < chemin.size(); ++i) {
            const Ville* ville = chemin[i];
            texteResultat += QString::fromStdString(ville->getNom() + " (" + ville->getPays() + ")");

            if (i < chemin.size() - 1) {
                const Ville* prochaineVille = chemin[i + 1];
                size_t tempsEtape = 0;

                // Trouver le temps entre ces deux villes
                for (const auto& trajet : trajets) {
                    if ((trajet->getVille1() == ville && trajet->getVille2() == prochaineVille) ||
                        (trajet->getVille2() == ville && trajet->getVille1() == prochaineVille)) {
                        tempsEtape = trajet->getTemps();
                        break;
                    }
                }

                texteResultat += QString(" → %1 → ").arg(formaterTemps(tempsEtape));
            }
        }

        texteResultat += QString("\n\nTemps total : %1").arg(formaterTemps(tempsTotal));
        texteResultat += QString("\nDistance approximative : %1 km").arg(round(distanceTotale));

        txtResultat->append(texteResultat);
        statusBar()->showMessage(QString("Trajet trouvé ! Durée totale : %1").arg(formaterTemps(tempsTotal)), 0);
    } else {
        // Effacer la carte si aucun trajet trouvé
        if (routeGroup) {
            while (!routeGroup->childItems().isEmpty()) {
                QGraphicsItem* item = routeGroup->childItems().first();
                routeGroup->removeFromGroup(item);
                delete item;
            }
        }

        QString texteResultat = QString("Aucun trajet possible entre %1 et %2 avec les étapes spécifiées.")
                                    .arg(QString::fromStdString(selectedVilleDepart->getNom()))
                                    .arg(QString::fromStdString(selectedVilleArrivee->getNom()));

        txtResultat->append(texteResultat);
        statusBar()->showMessage("Aucun trajet possible avec ces paramètres.", 0);
    }
}

void MainWindow::afficherMatriceTrajets() {
    if (trajets.empty() || villes.empty()) {
        QMessageBox::warning(this, "Erreur",
                             "Veuillez d'abord charger les fichiers des villes et des trajets.");
        return;
    }

    // Créer et afficher la boîte de dialogue
    MatriceTrajetsDialog dialog(this, villes, trajets);
    dialog.exec();
}

void MainWindow::afficherAideEtapes() {
    QMessageBox aide(this);
    aide.setWindowTitle("Aide - Étapes intermédiaires");
    aide.setIcon(QMessageBox::Information);
    aide.setText("Comment utiliser les étapes intermédiaires:");
    aide.setInformativeText(
        "Les étapes intermédiaires vous permettent de définir des villes de passage obligatoires.\n\n"
        "1. Recherchez une ville dans le champ 'Ajouter une étape'\n"
        "2. Sélectionnez-la dans la liste de suggestions\n"
        "3. Cliquez sur 'Ajouter' pour l'ajouter à votre itinéraire\n"
        "4. Répétez pour ajouter plusieurs étapes\n\n"
        "Utilisez le bouton 'Monter'pour changer l'ordre des étapes.\n"
        "L'itinéraire sera calculé en respectant l'ordre exact des étapes intermédiaires."
        );
    aide.setStandardButtons(QMessageBox::Ok);
    aide.exec();
}

void MainWindow::chargerFichiersParDefaut() {
    // Afficher un message dans la barre de statut
    statusBar()->showMessage("Chargement automatique des données...");

    // Nettoyer les données existantes
    for (auto ville : villes) {
        delete ville;
    }
    villes.clear();

    for (auto trajet : trajets) {
        delete trajet;
    }
    trajets.clear();

    delete fw;
    fw = nullptr;

    // Charger les villes depuis les ressources
    villes = chargerVillesRessources(":/ressources/villes.csv");

    if (!villes.empty()) {
        // Tri des villes par nom pour faciliter la recherche
        std::sort(villes.begin(), villes.end(),
                  [](const Ville* a, const Ville* b) {
                      return a->getNom() < b->getNom();
                  });

        // Pour la compatibilité avec l'ancien code, remplir les combobox cachés
        comboVilleDepart->clear();
        comboVilleArrivee->clear();
        for (const auto& ville : villes) {
            QString nomVille = QString::fromStdString(ville->getNom() + " (" + ville->getPays() + ")");
            comboVilleDepart->addItem(nomVille);
            comboVilleArrivee->addItem(nomVille);
        }

        txtResultat->setText(QString("Chargement automatique de %1 villes réussi.").arg(villes.size()));

        // Charger les trajets depuis les ressources
        trajets = chargerTrajetsRessources(":/ressources/temps.csv", villes);

        if (!trajets.empty()) {
            txtResultat->append(QString("Chargement automatique de %1 trajets réussi.").arg(trajets.size()));

            // Créer le graphe Floyd-Warshall
            fw = new FloydWarshall(villes, trajets);

            statusBar()->showMessage(QString("%1 villes et %2 trajets chargés automatiquement.").arg(villes.size()).arg(trajets.size()), 5000);
        } else {
            txtResultat->append("Échec du chargement automatique des trajets.");
            statusBar()->showMessage("Échec du chargement automatique des trajets.", 5000);
        }
    } else {
        txtResultat->setText("Échec du chargement automatique des villes.");
        statusBar()->showMessage("Échec du chargement automatique des villes.", 5000);
    }
}

void MainWindow::sauvegarderChemins(const QString& villesPath, const QString& trajetsPath) {
    // Enregistrer les chemins dans les paramètres de l'application
    QSettings settings("VotreOrganisation", "CalculateurTrajets");
    settings.setValue("defaultVillesPath", villesPath);
    settings.setValue("defaultTrajetsPath", trajetsPath);
}

void MainWindow::lireDerniersChemins() {
    // Lire les chemins depuis les paramètres de l'application
    QSettings settings("VotreOrganisation", "CalculateurTrajets");
    defaultVillesPath = settings.value("defaultVillesPath", "").toString();
    defaultTrajetsPath = settings.value("defaultTrajetsPath", "").toString();
}



void MainWindow::ajouterTrajetHistorique(const TrajetHistorique& trajet) {
    // Ajouter le trajet au début de la liste (le plus récent en premier)
    historiqueTrajet.prepend(trajet);

    // Limiter la taille de l'historique
    while (historiqueTrajet.size() > MAX_HISTORIQUE) {
        historiqueTrajet.removeLast();
    }

    // Mettre à jour le statut
    statusBar()->showMessage("Trajet ajouté à l'historique", 3000);
}

void MainWindow::afficherHistorique() {
    if (historiqueTrajet.isEmpty()) {
        QMessageBox::information(this, "Historique", "Aucun trajet dans l'historique.");
        return;
    }

    // Créer une boîte de dialogue avec une liste
    QDialog dialog(this);
    dialog.setWindowTitle("Historique des trajets");
    dialog.setMinimumSize(700, 500);

    QVBoxLayout* layout = new QVBoxLayout(&dialog);

    // Titre
    QLabel* titre = new QLabel("Historique des trajets calculés", &dialog);
    QFont fontTitre = titre->font();
    fontTitre.setPointSize(14);
    fontTitre.setBold(true);
    titre->setFont(fontTitre);
    layout->addWidget(titre);

    // Tableau pour afficher l'historique
    QTableWidget* tableau = new QTableWidget(&dialog);
    tableau->setColumnCount(5);
    tableau->setHorizontalHeaderLabels(QStringList() << "Date/Heure" << "Départ" << "Arrivée" << "Temps" << "Distance");
    tableau->setRowCount(historiqueTrajet.size());
    tableau->setSelectionBehavior(QAbstractItemView::SelectRows);
    tableau->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tableau->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    // Remplir le tableau
    for (int i = 0; i < historiqueTrajet.size(); ++i) {
        const TrajetHistorique& trajet = historiqueTrajet.at(i);

        // Date et heure
        QTableWidgetItem* itemDate = new QTableWidgetItem(trajet.dateCalcul.toString("dd/MM/yyyy hh:mm"));
        tableau->setItem(i, 0, itemDate);

        // Départ
        QTableWidgetItem* itemDepart = new QTableWidgetItem(trajet.nomDepart);
        tableau->setItem(i, 1, itemDepart);

        // Arrivée
        QTableWidgetItem* itemArrivee = new QTableWidgetItem(trajet.nomArrivee);
        tableau->setItem(i, 2, itemArrivee);

        // Temps
        QTableWidgetItem* itemTemps = new QTableWidgetItem(formaterTemps(trajet.tempsTotal));
        tableau->setItem(i, 3, itemTemps);

        // Distance
        QTableWidgetItem* itemDistance = new QTableWidgetItem(QString("%1 km").arg(trajet.distanceTotal, 0, 'f', 1));
        tableau->setItem(i, 4, itemDistance);
    }

    layout->addWidget(tableau);

    // Boutons d'action
    QHBoxLayout* boutonsLayout = new QHBoxLayout();

    QPushButton* btnDetails = new QPushButton("Voir les détails", &dialog);
    QPushButton* btnRecharger = new QPushButton("Recharger ce trajet", &dialog);
    QPushButton* btnFermer = new QPushButton("Fermer", &dialog);

    boutonsLayout->addWidget(btnDetails);
    boutonsLayout->addWidget(btnRecharger);
    boutonsLayout->addStretch();
    boutonsLayout->addWidget(btnFermer);

    layout->addLayout(boutonsLayout);

    // Connexion des boutons
    connect(btnFermer, &QPushButton::clicked, &dialog, &QDialog::accept);

    connect(btnDetails, &QPushButton::clicked, [this, tableau, &dialog]() {
        int row = tableau->currentRow();
        if (row >= 0 && row < historiqueTrajet.size()) {
            const TrajetHistorique& trajet = historiqueTrajet.at(row);
            QString details = QString("Détails du trajet du %1\n\n")
                                  .arg(trajet.dateCalcul.toString("dd/MM/yyyy à hh:mm"));

            details += QString("De: %1\nÀ: %2\n\n").arg(trajet.nomDepart).arg(trajet.nomArrivee);

            if (!trajet.etapesNoms.empty()) {
                details += "Étapes intermédiaires:\n";
                for (const QString& etape : trajet.etapesNoms) {
                    details += QString("- %1\n").arg(etape);
                }
                details += "\n";
            }

            details += QString("Temps total: %1\n").arg(formaterTemps(trajet.tempsTotal));
            details += QString("Distance: %1 km").arg(trajet.distanceTotal, 0, 'f', 1);

            QMessageBox::information(&dialog, "Détails du trajet", details);
        } else {
            QMessageBox::warning(&dialog, "Attention", "Veuillez sélectionner un trajet dans la liste.");
        }
    });

    connect(btnRecharger, &QPushButton::clicked, [this, tableau, &dialog]() {
        int row = tableau->currentRow();
        if (row >= 0 && row < historiqueTrajet.size()) {
            // Récupérer le trajet sélectionné
            const TrajetHistorique& trajet = historiqueTrajet.at(row);

            // Rechercher les villes dans la liste des villes chargées
            Ville* villeDepart = nullptr;
            Ville* villeArrivee = nullptr;
            std::vector<Ville*> etapes;

            for (Ville* ville : villes) {
                QString nomVille = QString::fromStdString(ville->getNom());

                if (nomVille == trajet.nomDepart) {
                    villeDepart = ville;
                } else if (nomVille == trajet.nomArrivee) {
                    villeArrivee = ville;
                } else {
                    // Vérifier si c'est une étape
                    for (const QString& etapeNom : trajet.etapesNoms) {
                        if (nomVille == etapeNom) {
                            etapes.push_back(ville);
                            break;
                        }
                    }
                }
            }

            // Vérifier si toutes les villes ont été trouvées
            if (!villeDepart || !villeArrivee) {
                QMessageBox::warning(&dialog, "Erreur",
                                     "Impossible de recharger ce trajet car certaines villes ne sont pas disponibles "
                                     "dans le fichier de villes actuellement chargé.");
                return;
            }

            // Fermer la boîte de dialogue
            dialog.accept();

            // Mettre à jour les sélections
            selectedVilleDepart = villeDepart;
            selectedVilleArrivee = villeArrivee;
            searchDepart->setText(QString::fromStdString(villeDepart->getNom() + " (" + villeDepart->getPays() + ")"));
            searchArrivee->setText(QString::fromStdString(villeArrivee->getNom() + " (" + villeArrivee->getPays() + ")"));
            labelVilleDepart->setText(QString::fromStdString("Sélectionné: " + villeDepart->getNom()));
            labelVilleArrivee->setText(QString::fromStdString("Sélectionné: " + villeArrivee->getNom()));

            // Vider et recréer les étapes
            viderEtapes();
            etapesIntermediaires = etapes;

            for (Ville* etape : etapes) {
                QListWidgetItem* newItem = new QListWidgetItem(
                    QString::fromStdString(etape->getNom() + " (" + etape->getPays() + ")"));
                newItem->setData(Qt::UserRole, QVariant::fromValue(static_cast<void*>(etape)));
                listeEtapes->addItem(newItem);
            }

            btnViderEtapes->setEnabled(!etapes.empty());
            btnCalculer->setEnabled(true);

            // Calculer automatiquement le trajet
            calculerTrajet();
        } else {
            QMessageBox::warning(&dialog, "Attention", "Veuillez sélectionner un trajet dans la liste.");
        }
    });

    // Exécuter la boîte de dialogue
    dialog.exec();
}

void MainWindow::effacerHistorique() {
    if (historiqueTrajet.isEmpty()) {
        QMessageBox::information(this, "Historique", "L'historique est déjà vide.");
        return;
    }

    QMessageBox::StandardButton reponse = QMessageBox::question(this,
                                                                "Confirmer", "Voulez-vous vraiment effacer tout l'historique des trajets ?",
                                                                QMessageBox::Yes|QMessageBox::No);

    if (reponse == QMessageBox::Yes) {
        historiqueTrajet.clear();
        statusBar()->showMessage("Historique effacé", 3000);
    }
}


std::vector<Ville*> MainWindow::chargerVillesRessources(const QString& ressourcePath) {
    std::vector<Ville*> villes;

    // Ouvrir le fichier de ressource
    QFile file(ressourcePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Impossible d'ouvrir la ressource:" << ressourcePath;
        return villes;
    }

    // Lire l'en-tête
    QTextStream in(&file);
    QString header = in.readLine();

    // Lire les villes ligne par ligne
    while (!in.atEnd()) {
        QString line = in.readLine();
        std::istringstream iss(line.toStdString());
        Ville* ville = new Ville(iss);
        villes.push_back(ville);
    }

    file.close();
    qDebug() << "Chargement réussi de" << villes.size() << "villes depuis" << ressourcePath;
    return villes;
}

std::vector<Trajet*> MainWindow::chargerTrajetsRessources(const QString& ressourcePath, const std::vector<Ville*>& villes) {
    std::vector<Trajet*> trajets;

    // Ouvrir le fichier de ressource
    QFile file(ressourcePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Impossible d'ouvrir la ressource:" << ressourcePath;
        return trajets;
    }

    // Lire l'en-tête
    QTextStream in(&file);
    QString header = in.readLine();

    // Lire les trajets ligne par ligne
    while (!in.atEnd()) {
        QString line = in.readLine();
        std::istringstream iss(line.toStdString());
        Trajet* trajet = new Trajet(iss, villes);
        if (trajet->getVille1() != nullptr && trajet->getVille2() != nullptr) {
            trajets.push_back(trajet);
        } else {
            delete trajet; // Trajet invalide (ville non trouvée)
        }
    }

    file.close();
    qDebug() << "Chargement réussi de" << trajets.size() << "trajets depuis" << ressourcePath;
    return trajets;
}
