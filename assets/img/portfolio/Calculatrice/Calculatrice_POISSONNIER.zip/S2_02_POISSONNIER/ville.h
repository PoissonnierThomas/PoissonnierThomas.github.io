#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#ifndef VILLE_H
#define VILLE_H

class Ville
{
private:
    std::string nom, nom_ASCII, nomsalternatifs;
    double latitude, longitude;
    std::string pays, iso2, iso3;
    std::string region,regionASCII,regioncode, region_type, capital;
    double densite;
    size_t population, population_zone;
    short int ranking;
    std::string fuseau;
    bool nom_identique;
    size_t id;
public:
    Ville(std::istream &is);
    ~Ville() {}
    friend std::ostream& operator<<(std::ostream &os, const Ville& ville); // Afficher une ville dans un flux






    // Accesseurs
    std::ostream& getAll(std::ostream &os) const ;
    void getAll() const ;
    inline size_t getId() const { return id; }
    inline std::string getNom() const { return nom; }
    inline std::string getNomAscii() const { return nom_ASCII; }
    inline std::string getNomAlternatifs() const { return nomsalternatifs; }
    inline std::string getPays() const { return pays; }
    inline std::string getIso2() const { return iso2; }
    inline std::string getIso3() const { return iso3; }
    inline std::string getRegion() const { return region; }
    inline std::string getRegionAscii() const { return regionASCII; }
    inline std::string getRegionCode() const { return regioncode; }
    inline std::string getRegionType() const { return region_type; }
    inline std::string getCapital() const { return capital; }
    inline double getDensite() const {return densite;};
    inline double getLatitude() const { return latitude; }
    inline double getLongitude() const { return longitude; }
    inline size_t getPopulation() const { return population; }
    inline size_t getPopulationZone() const { return population_zone; }
    inline short int getRanking() const {return ranking;}
    inline std::string getFuseau() const {return fuseau;}
};

#endif // VILLE_H
