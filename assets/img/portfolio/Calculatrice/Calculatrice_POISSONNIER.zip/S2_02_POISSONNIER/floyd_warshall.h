#ifndef FLOYD_WARSHALL_H
#define FLOYD_WARSHALL_H

#include "ville.h"
#include "trajet.h"
#include <vector>
#include <limits>
#include <map>

class FloydWarshall {
private:
    std::vector<std::vector<size_t>> dist;   // Matrice des distances
    std::vector<std::vector<size_t>> next;   // Matrice pour la reconstruction de chemin
    std::vector<const Ville*> villes;        // Liste des villes
    std::map<const Ville*, size_t> villeToIndex; // Etablissement des liens ville -> index

public:
    // Constructeur prenant un vecteur de villes et un vecteur de trajets
    FloydWarshall(const std::vector<Ville*>& villes, const std::vector<Trajet*>& trajets);

    // Retourne le temps du trajet le plus court entre deux villes
    size_t getTempsTrajet(const Ville* depart, const Ville* arrivee) const;

    // Construit et retourne le chemin le plus court entre deux villes
    std::vector<const Ville*> getChemin(const Ville* depart, const Ville* arrivee) const;

    // Fonction renvoyant la matrice des distances
    const std::vector<std::vector<size_t>>& getDistMatrix() const;
};

// Structure pour encapsuler les résultats du chemin
struct ResultatChemin {
    size_t temps;
    std::vector<const Ville*> chemin;
};

// Fonction pour trouver le chemin le plus court entre deux villes
ResultatChemin trouverCheminPlusCourt(
    const std::vector<Ville*>& villes,
    const std::vector<Trajet*>& trajets,
    const Ville* villeDepart,
    const Ville* villeArrivee);

#endif // FLOYD_WARSHALL_H
