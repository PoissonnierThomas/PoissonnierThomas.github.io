#include "matricetrajetsdialog.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QComboBox>
#include <QSpinBox>
#include <QSet>
#include <QString>
#include <fstream>
#include <algorithm>
#include <set>

MatriceTrajetsDialog::MatriceTrajetsDialog(QWidget* parent,
                                           const std::vector<Ville*>& villes,
                                           const std::vector<Trajet*>& trajets)
    : QDialog(parent), villes(villes), trajets(trajets)
{
    setWindowTitle("Matrice des Trajets Directs");
    setMinimumSize(900, 700);

    // Création du layout principal
    QVBoxLayout* layout = new QVBoxLayout(this);

    // Création du titre
    lblTitre = new QLabel("Matrice des temps de trajet directs entre villes");
    QFont titreFont = lblTitre->font();
    titreFont.setPointSize(14);
    titreFont.setBold(true);
    lblTitre->setFont(titreFont);
    lblTitre->setAlignment(Qt::AlignCenter);
    layout->addWidget(lblTitre);

    // Options de filtrage
    QHBoxLayout* filtreLayout = new QHBoxLayout();

    // Filtre par région
    QLabel* lblRegion = new QLabel("Filtrer par région/pays:");
    comboFiltreRegion = new QComboBox();
    comboFiltreRegion->addItem("Toutes les régions/pays");

    // Collecter toutes les régions et pays uniques
    QSet<QString> regions;
    QSet<QString> pays;

    for (const Ville* ville : villes) {
        if (!ville->getPays().empty()) {
            pays.insert(QString::fromStdString(ville->getPays()));
        }
        if (!ville->getRegion().empty()) {
            regions.insert(QString::fromStdString(ville->getRegion()));
        }
    }

    // Ajouter les pays (préfixés)
    QList<QString> listePays;
    // Convertir QSet en QList manuellement
    for (const QString& p : pays) {
        listePays.append(p);
    }
    std::sort(listePays.begin(), listePays.end());
    for (const QString& p : listePays) {
        comboFiltreRegion->addItem("Pays: " + p, p);
    }

    // Ajouter les régions (préfixées)
    QList<QString> listeRegions;
    // Convertir QSet en QList manuellement
    for (const QString& r : regions) {
        listeRegions.append(r);
    }
    std::sort(listeRegions.begin(), listeRegions.end());
    for (const QString& r : listeRegions) {
        comboFiltreRegion->addItem("Région: " + r, r);
    }

    // Limite du nombre de villes
    QLabel* lblLimite = new QLabel("Limiter à:");
    spinLimiteVilles = new QSpinBox();
    spinLimiteVilles->setRange(10, 200);
    spinLimiteVilles->setValue(50);
    spinLimiteVilles->setSuffix(" villes");

    // Bouton d'application des filtres
    btnFiltrer = new QPushButton("Appliquer");

    filtreLayout->addWidget(lblRegion);
    filtreLayout->addWidget(comboFiltreRegion);
    filtreLayout->addWidget(lblLimite);
    filtreLayout->addWidget(spinLimiteVilles);
    filtreLayout->addWidget(btnFiltrer);
    layout->addLayout(filtreLayout);

    // Création du tableau
    tableauMatrice = new QTableWidget(this);
    tableauMatrice->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    tableauMatrice->verticalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    tableauMatrice->setEditTriggers(QAbstractItemView::NoEditTriggers);
    layout->addWidget(tableauMatrice);

    // Boutons
    QHBoxLayout* buttonsLayout = new QHBoxLayout();
    btnExporter = new QPushButton("Exporter en CSV");
    btnFermer = new QPushButton("Fermer");
    buttonsLayout->addWidget(btnExporter);
    buttonsLayout->addStretch();
    buttonsLayout->addWidget(btnFermer);
    layout->addLayout(buttonsLayout);

    // Connexion des signaux
    connect(btnFermer, &QPushButton::clicked, this, &QDialog::accept);
    connect(btnExporter, &QPushButton::clicked, this, &MatriceTrajetsDialog::exporterCSV);
    connect(btnFiltrer, &QPushButton::clicked, this, &MatriceTrajetsDialog::filtrerDonnees);

    // Construire la matrice de trajets
    construireMatriceTrajets();

    // Remplir le tableau avec toutes les villes (mais limité)
    villesAffichees = villes;
    std::sort(villesAffichees.begin(), villesAffichees.end(),
              [](const Ville* a, const Ville* b) {
                  return a->getNom() < b->getNom();
              });

    // Limiter le nombre de villes affichées
    if (villesAffichees.size() > static_cast<size_t>(spinLimiteVilles->value())) {
        villesAffichees.resize(spinLimiteVilles->value());
    }

    remplirTableau();
}

void MatriceTrajetsDialog::construireMatriceTrajets() {
    // Initialiser la matrice
    matriceTrajetsDirects.clear();

    // Remplir la matrice avec les trajets directs
    for (const Trajet* trajet : trajets) {
        const Ville* ville1 = trajet->getVille1();
        const Ville* ville2 = trajet->getVille2();

        if (ville1 && ville2) {
            size_t id1 = ville1->getId();
            size_t id2 = ville2->getId();
            size_t temps = trajet->getTemps();

            // Stocker le trajet dans les deux sens (car les trajets sont bidirectionnels)
            matriceTrajetsDirects[id1][id2] = temps;
            matriceTrajetsDirects[id2][id1] = temps; // Bidirectionnel
        }
    }
}

void MatriceTrajetsDialog::filtrerDonnees() {
    // Réinitialiser la liste des villes affichées
    villesAffichees.clear();

    // Obtenir les critères de filtrage
    QString filtreRegion = comboFiltreRegion->currentText();
    int limiteVilles = spinLimiteVilles->value();

    // Filtrer les villes
    if (filtreRegion.startsWith("Toutes")) {
        // Aucun filtre de région/pays
        villesAffichees = villes;
    } else if (filtreRegion.startsWith("Pays: ")) {
        // Filtre par pays
        QString pays = filtreRegion.mid(6); // Supprimer "Pays: "
        for (Ville* ville : villes) {
            if (QString::fromStdString(ville->getPays()) == pays) {
                villesAffichees.push_back(ville);
            }
        }
    } else if (filtreRegion.startsWith("Région: ")) {
        // Filtre par région
        QString region = filtreRegion.mid(8); // Supprimer "Région: "
        for (Ville* ville : villes) {
            if (QString::fromStdString(ville->getRegion()) == region) {
                villesAffichees.push_back(ville);
            }
        }
    }

    // Trier les villes par nom
    std::sort(villesAffichees.begin(), villesAffichees.end(),
              [](const Ville* a, const Ville* b) {
                  return a->getNom() < b->getNom();
              });

    // Limiter le nombre de villes
    if (villesAffichees.size() > static_cast<size_t>(limiteVilles)) {
        villesAffichees.resize(limiteVilles);
    }

    // Mettre à jour le tableau
    remplirTableau();
}

void MatriceTrajetsDialog::remplirTableau() {
    // Fixer les dimensions du tableau
    int nbVilles = villesAffichees.size();
    tableauMatrice->setRowCount(nbVilles + 1); // +1 pour l'en-tête
    tableauMatrice->setColumnCount(nbVilles + 1); // +1 pour l'en-tête

    // Définir l'élément en haut à gauche
    QTableWidgetItem* cornerItem = new QTableWidgetItem("Ville → / ↓");
    cornerItem->setTextAlignment(Qt::AlignCenter);
    QFont boldFont = cornerItem->font();
    boldFont.setBold(true);
    cornerItem->setFont(boldFont);
    cornerItem->setBackground(Qt::lightGray);
    tableauMatrice->setItem(0, 0, cornerItem);

    // Définir les en-têtes de colonnes (horizontaux)
    for (int i = 0; i < nbVilles; i++) {
        QTableWidgetItem* headerItem = new QTableWidgetItem(QString::fromStdString(villesAffichees[i]->getNom()));
        headerItem->setTextAlignment(Qt::AlignCenter);
        headerItem->setFont(boldFont);
        headerItem->setBackground(Qt::lightGray);
        headerItem->setToolTip(QString::fromStdString(villesAffichees[i]->getNom() + " (" +
                                                      villesAffichees[i]->getPays() + ")"));
        tableauMatrice->setItem(0, i + 1, headerItem);
    }

    // Définir les en-têtes de lignes (verticaux)
    for (int i = 0; i < nbVilles; i++) {
        QTableWidgetItem* headerItem = new QTableWidgetItem(QString::fromStdString(villesAffichees[i]->getNom()));
        headerItem->setTextAlignment(Qt::AlignCenter);
        headerItem->setFont(boldFont);
        headerItem->setBackground(Qt::lightGray);
        headerItem->setToolTip(QString::fromStdString(villesAffichees[i]->getNom() + " (" +
                                                      villesAffichees[i]->getPays() + ")"));
        tableauMatrice->setItem(i + 1, 0, headerItem);
    }

    // Remplir la matrice avec les temps de trajet
    for (int i = 0; i < nbVilles; i++) {
        for (int j = 0; j < nbVilles; j++) {
            if (i == j) {
                // Diagonal = 0
                QTableWidgetItem* item = new QTableWidgetItem("0");
                item->setTextAlignment(Qt::AlignCenter);
                item->setBackground(QColor(240, 240, 240));
                tableauMatrice->setItem(i + 1, j + 1, item);
            } else {
                // Vérifier s'il existe un trajet direct
                const Ville* ville1 = villesAffichees[i];
                const Ville* ville2 = villesAffichees[j];

                if (matriceTrajetsDirects.count(ville1->getId()) &&
                    matriceTrajetsDirects[ville1->getId()].count(ville2->getId())) {

                    size_t temps = matriceTrajetsDirects[ville1->getId()][ville2->getId()];
                    QTableWidgetItem* item = new QTableWidgetItem(formaterTemps(temps));
                    item->setTextAlignment(Qt::AlignCenter);

                    // Coloration selon le temps de trajet
                    if (temps < 60) { // Moins d'une heure
                        item->setBackground(QColor(200, 255, 200)); // Vert clair
                    } else if (temps < 120) { // 1-2 heures
                        item->setBackground(QColor(255, 255, 200)); // Jaune clair
                    } else if (temps < 240) { // 2-4 heures
                        item->setBackground(QColor(255, 220, 180)); // Orange clair
                    } else { // Plus de 4 heures
                        item->setBackground(QColor(255, 200, 200)); // Rouge clair
                    }

                    // Définir la donnée brute comme tooltip
                    item->setToolTip(QString("%1 → %2: %3 minutes")
                                         .arg(QString::fromStdString(ville1->getNom()))
                                         .arg(QString::fromStdString(ville2->getNom()))
                                         .arg(temps));

                    tableauMatrice->setItem(i + 1, j + 1, item);
                } else {
                    // Pas de trajet direct
                    QTableWidgetItem* item = new QTableWidgetItem("-");
                    item->setTextAlignment(Qt::AlignCenter);
                    item->setBackground(QColor(230, 230, 230)); // Gris clair
                    tableauMatrice->setItem(i + 1, j + 1, item);
                }
            }
        }
    }

    // Ajuster les tailles des colonnes et des lignes
    tableauMatrice->resizeColumnsToContents();
    tableauMatrice->resizeRowsToContents();
}

QString MatriceTrajetsDialog::formaterTemps(size_t minutes) const {
    int heures = minutes / 60;
    int minutesRestantes = minutes % 60;

    if (heures > 0) {
        return QString("%1h%2").arg(heures).arg(minutesRestantes, 2, 10, QChar('0'));
    } else {
        return QString("%1min").arg(minutesRestantes);
    }
}

void MatriceTrajetsDialog::exporterCSV() {
    QString filename = QFileDialog::getSaveFileName(this,
                                                    "Exporter la matrice de trajets",
                                                    QString(),
                                                    "Fichiers CSV (*.csv)");

    if (filename.isEmpty())
        return;

    std::ofstream file(filename.toStdString());
    if (!file.is_open()) {
        QMessageBox::critical(this, "Erreur", "Impossible d'ouvrir le fichier pour l'écriture.");
        return;
    }

    // Écrire les données
    for (int row = 0; row < tableauMatrice->rowCount(); ++row) {
        for (int col = 0; col < tableauMatrice->columnCount(); ++col) {
            QTableWidgetItem* item = tableauMatrice->item(row, col);
            if (item) {
                // Gérer les caractères spéciaux dans les champs CSV
                std::string text = item->text().toStdString();
                bool needsQuotes = text.find(';') != std::string::npos ||
                                   text.find(',') != std::string::npos ||
                                   text.find('"') != std::string::npos;

                if (needsQuotes) {
                    // Doubler les guillemets pour échapper
                    std::string escaped;
                    for (char c : text) {
                        escaped.push_back(c);
                        if (c == '"') escaped.push_back('"');
                    }
                    file << "\"" << escaped << "\"";
                } else {
                    file << text;
                }
            }

            if (col < tableauMatrice->columnCount() - 1) {
                file << ";";
            }
        }
        file << "\n";
    }

    file.close();

    QMessageBox::information(this, "Exportation réussie",
                             "La matrice des trajets a été exportée avec succès.");
}
