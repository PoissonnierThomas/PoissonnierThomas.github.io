#include <QMainWindow>
#include <QComboBox>
#include <QPushButton>
#include <QTextEdit>
#include <QLineEdit>
#include <QListWidget>
#include <QLabel>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>
#include <QGraphicsLineItem>
#include <QGraphicsEllipseItem>
#include <QGraphicsTextItem>
#include <QGraphicsItemGroup>
#include <QResizeEvent>
#include <QWheelEvent>
#include <QStatusBar>
#include <QApplication>
#include <QMenuBar>
#include <QToolBar>
#include <QString>
#include <QDateTime>
#include <vector>
#include "ville.h"
#include "trajet.h"
#include "floyd_warshall.h"

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// Structure pour stocker un trajet dans l'historique
struct TrajetHistorique {
    QString nomDepart;
    QString nomArrivee;
    std::vector<QString> etapesNoms;
    size_t tempsTotal;
    double distanceTotal;
    QDateTime dateCalcul;

    // Constructeur pour faciliter la création
    TrajetHistorique(const QString& depart, const QString& arrivee,
                     const std::vector<QString>& etapes,
                     size_t temps, double distance,
                     const QDateTime& date = QDateTime::currentDateTime())
        : nomDepart(depart), nomArrivee(arrivee), etapesNoms(etapes),
        tempsTotal(temps), distanceTotal(distance), dateCalcul(date) {}
};


class MainWindow : public QMainWindow {
    Q_OBJECT

private:
    // Widgets pour la recherche avec auto-complétion
    QLineEdit* searchDepart;
    QLineEdit* searchArrivee;
    QListWidget* listeSuggestionsDepart;
    QListWidget* listeSuggestionsArrivee;
    QLabel* labelVilleDepart;
    QLabel* labelVilleArrivee;

    // Anciens widgets de sélection (supprimés dans l'interface mais conservés pour compatibilité)
    QComboBox* comboVilleDepart;
    QComboBox* comboVilleArrivee;

    QPushButton* btnCalculer;
    QPushButton* btnChargerVilles;
    QPushButton* btnChargerTrajets;
    QPushButton* btnResetView;
    QTextEdit* txtResultat;

    // Composants pour la visualisation graphique
    QGraphicsScene* mapScene;
    QGraphicsView* mapView;
    QGraphicsItemGroup* routeGroup;  // Groupe pour les éléments du trajet

    std::vector<Ville*> villes;
    std::vector<Trajet*> trajets;
    FloydWarshall* fw;

    // Variables pour stocker les villes sélectionnées
    Ville* selectedVilleDepart;
    Ville* selectedVilleArrivee;

    // Méthodes pour la visualisation graphique
    void setupGraphicsView();
    void displayRouteOnGraphicsView(const std::vector<const Ville*>& chemin);
    void createLegend();

    // Fonction pour convertir lat/long en coordonnées d'écran
    QPointF coordToPoint(double longitude, double latitude) const;

    // Chemins par défaut pour les fichiers de villes et trajets
    QString defaultVillesPath;
    QString defaultTrajetsPath;

    // Méthode pour charger les fichiers par défaut au démarrage
    void chargerFichiersParDefaut();

    // Méthode pour sauvegarder les derniers chemins utilisés
    void sauvegarderChemins(const QString& villesPath, const QString& trajetsPath);

    // Méthode pour lire les derniers chemins utilisés
    void lireDerniersChemins();

    // Ajouts pour la gestion des étapes intermédiaires
    QListWidget* listeEtapes;
    QPushButton* btnAjouterEtape;
    QPushButton* btnSupprimerEtape;
    QPushButton* btnMontrerEtape;
    QPushButton* btnViderEtapes;
    QLineEdit* searchEtape;
    QListWidget* listeSuggestionsEtape;
    std::vector<Ville*> etapesIntermediaires;


    // Historique des trajets calculés
    QList<TrajetHistorique> historiqueTrajet;

    // Nombre maximum de trajets à conserver dans l'historique
    static const int MAX_HISTORIQUE = 20;

    // Méthodes pour la gestion de l'historique
    void ajouterTrajetHistorique(const TrajetHistorique& trajet);
    void afficherHistorique();
    void effacerHistorique();

    // Widget pour l'historique
    QMenu* menuHistorique;
    QAction* actionAfficherHistorique;
    QAction* actionViderHistorique;


public:
    MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

protected:
    void resizeEvent(QResizeEvent* event) override;
    bool eventFilter(QObject* obj, QEvent* event) override;

private slots:
    void chargerFichierVilles();
    void chargerFichierTrajets();
    void calculerTrajet();
    void resetView();

    // Méthodes pour la recherche avec auto-complétion
    void updateSuggestionsDepart(const QString& text);
    void updateSuggestionsArrivee(const QString& text);
    void selectVilleDepart(QListWidgetItem* item);
    void selectVilleArrivee(QListWidgetItem* item);
    void resetSelections();

    void afficherMatriceTrajets();

    // Méthodes pour la gestion des étapes
    void updateSuggestionsEtape(const QString& text);
    void selectVilleEtape(QListWidgetItem* item);
    void ajouterEtape();
    void supprimerEtape();
    void monterEtape();
    void viderEtapes();

    // Méthode modifiée pour calculer l'itinéraire avec étapes
    std::vector<const Ville*> calculerItineraireAvecEtapes();

    void afficherAideEtapes();

    // Méthodes pour charger les fichiers depuis les ressources
    std::vector<Ville*> chargerVillesRessources(const QString& ressourcePath);
    std::vector<Trajet*> chargerTrajetsRessources(const QString& ressourcePath, const std::vector<Ville*>& villes);
};

#endif // MAINWINDOW_H
