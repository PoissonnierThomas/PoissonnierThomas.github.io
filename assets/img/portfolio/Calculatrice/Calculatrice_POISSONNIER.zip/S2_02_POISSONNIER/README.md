# Calculateur de Trajets POISSONNIER Thomas

## Présentation du Projet

Ce projet est un calculateur de trajets développé pour la SAé S2.02 "Temps de route". L'application permet de calculer le chemin le plus court entre deux villes, en utilisant l'algorithme de Floyd-Warshall pour trouver l'itinéraire optimal.

## Explication algorithmique : Floyd-Warshall

### Introduction à l'algorithme 

L'algorithme de Floyd-Warshall est une méthode efficace pour trouver les plus courts chemins entre toutes les paires de sommets dans un graphe pondéré. Contrairement aux algorithmes comme Dijkstra qui calculent les chemins à partir d'un seul sommet source, Floyd-Warshall calcule  tous les chemins possibles entre chaque paire de villes.
Dans ce projet, le graphe est constitué de villes (sommets) reliées par des trajets (arêtes) dont les poids sont les temps de parcours en minutes.

### Fonctionnement de l'algorithme

Floyd-Warshall repose sur une approche de programmation dynamique. L'idée centrale est que si le plus court chemin de i à j passe par un sommet intermédiaire k, alors ce chemin est la somme des plus courts chemins de i à k et de k à j.


### Avantages et inconvénients 

Avantages : 

* Calcule tous les chemins les plus courts en une seule exécution
* Simple à implémenter et à comprendre

Inconvénients :

* Complexité O(n³) qui peut être problématique pour de très grands graphes
* Consommation mémoire O(n²)
* Ne détecte pas directement les cycles négatifs (qui n'existent pas dans notre cas, car les temps sont positifs)

### Pourquoi Floyd-Warshall pour ce projet ?

L'algorithme est parfaitement adapté à notre calculateur de trajets car :

1. Nous avons besoin de calculer potentiellement plusieurs itinéraires différents
2. Le nombre de villes reste raisonnable (quelques centaines maximum)
3. Le précalcul de tous les chemins permet une réponse instantanée aux requêtes des utilisateurs
4. L'ajout d'étapes intermédiaires est facilité par la connaissance de tous les plus courts chemins
5. Il n'existe pas de trajets dont le temps est négatif

Cette implémentation nous permet d'offrir un calculateur d'itinéraires rapide et flexible, capable de gérer efficacement des ajustements comme l'ajout d'étapes intermédiaires imposées par l'utilisateur.

## Fonctionnalités

- Chargement de villes depuis un fichier CSV
- Chargement de trajets entre les villes depuis un fichier CSV
- Recherche de villes avec auto-complétion
- Calcul du chemin le plus court entre deux villes
- Possibilité d'ajouter des étapes intermédiaires
- Affichage graphique de l'itinéraire sur une carte
- Affichage du temps de trajet total
- Historique des trajets calculés
- Affichage de la matrice des trajets directs entre villes

## Structure du Projet

Le projet est organisé autour de plusieurs classes :

- **Ville** : Représente une ville avec ses coordonnées géographiques, son nom, etc.
- **Trajet** : Définit un trajet entre deux villes avec un temps de parcours
- **FloydWarshall** : Implémente l'algorithme pour trouver les plus courts chemins
- **MainWindow** : Gère l'interface graphique principale (carte, boutons, Affichages)
- **MatriceTrajetsDialog** : Affiche la matrice des trajets directs entre villes dans une fenêtre à part


## De quoi est composé le dossier de rendu

Dans le dossier dans lequel vous avez trouvé ce README, vous trouverez :

- Les fichiers .cpp et .h des classes présentées dans la structure du projet
- Le main.cpp pour tout regrouper et lancer l'application
- Un fichier .pro pour créer un exécutable à partir de ces fichiers
- Un fichier .pro.user
- Un fichier resources.qrc permettant au compilateur de faire le lien entre les ressources et l'application
- Un dossier ressources contenant les dîtes ressources :
   * Les fichiers temps.csv et villes.csv permettant de charger villes et trajets directs
   * Une image France_contours.png pour un affichage graphique avec un meilleur rendu
   * Un dossier documentation contenant une copie de ce README, un fichier texte (Classes.txt) décrivant les différentes classes ...


## Comment utiliser l'application

1. **Démarrage** : Lancez l'application
2. **Chargement des données (Si cela ne s'est pas fait automatiquement)** : 
   - Cliquez sur "Charger les villes" pour sélectionner votre fichier CSV de villes
   - Cliquez sur "Charger les trajets" pour sélectionner votre fichier CSV de trajets
3. **Calcul d'un trajet** :
   - Tapez le nom d'une ville de départ dans le champ correspondant et sélectionnez-la
   - Tapez le nom d'une ville d'arrivée et sélectionnez-la
   - Ajoutez des étapes intermédiaires (Optionnel)
   - Cliquez sur "Calculer le trajet"
4. **Analyse des résultats** :
   - Visualisez l'itinéraire sur la carte
   - Consultez les détails du trajet (temps, distance, étapes)
   - Ajuster le zoom à votre convenance (Zoom+, Zoom-, Réinitialiser la vue)

## Format des fichiers d'entrée

### Fichier des villes (CSV)
```
nom;nomascii;nomsalternatifs;latitude;longitude;pays;iso2;iso3;nom région;...
Paris;Paris;Paris la ville lumière;48.8566;2.3522;France;FR;FRA;Île-de-France;...
```

### Fichier des trajets (CSV)
```
ville1,ville2,temps_en_minutes
Paris,Lyon,115
```

## Difficultés rencontrées

La première difficulté rencontrée a été de charger efficacement les fichiers, il a notamment fallu que je réalise une classe complète de Ville qui permette de récupérer toutes les données du fichier villes.csv. Une fois les deux fichiers chargés, il a fallu concevoir le plan de développement de mon application, décider d'une chronologie des fonctionnalités à développer afin de prioriser mon temps de travail. J'ai d'abord codé l'algorithme Floyd-Warshall pour ensuite l'utiliser pour afficher mes trajets. L'utilisation de la carte (dont le png est une image libre de droits trouvée sur wikiFiles) fut une grande amélioration graphique du logiciel mais aura été chronophage. Ensuite, ajouter une fenêtre qui s'ouvre sur la matrice des trajets entre les villes fut relativement simple, tout comme l'affichage d'un historique. Plusieurs fois il a fallu que je réorganise mon code car les fonctions n'étaient pas rangées correctement et je m'y perdais souvent. Il a également souvent été question de résoudre des erreurs que je n'avais pas l'habitude de rencontrer, c'est pourquoi vous trouverez de nombreux éléments de déboguage et sécurités (trouvés en partie sur de la documentation sur internet).

## Améliorations possibles

- Aspect graphique pas le plus développé
- Il doit rester des vestiges d'anciennes fonctions, classes ou variables dans le code


## Conclusion

Ce projet m'a permis de faire le lien entre la gestion des données, des graphes et d'une application permettant un rendu graphique grâce à Qt. C'était un projet intéressant qui aura nécessité un bon nombre d'heures et une bonne dose de patience pour résoudre des erreurs inattendues. Il aura également fallu chercher pas mal de documentation sur Internet pour bien utiliser les différentes classes Qt et avoir un rendu qui ressemblait vraiment à ce que je voulais faire (exemple : recherche par auto-complétion au lieu de l'utilisation de combo-box plus "simples").
Je suis toutefois satisfait de mon rendu bien qu'il manque peut-être de quelques fonctionnalités supplémentaires pour le rendre plus complet.

---

**Auteur** : [POISSONNIER Thomas]  
**Date** : Mai 2025  
**Lieu** : Arles, France