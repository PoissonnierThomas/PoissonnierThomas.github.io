#ifndef MATRICETRAJETSDIALOG_H
#define MATRICETRAJETSDIALOG_H

#include <QDialog>
#include <QTableWidget>
#include <QPushButton>
#include <QLabel>
#include <QHeaderView>
#include <QVBoxLayout>
#include <QComboBox>
#include <QSpinBox>
#include <vector>
#include <map>
#include "ville.h"
#include "trajet.h"

class MatriceTrajetsDialog : public QDialog {   // Classe sur la fenêtre permettant d'afficher la matrice des trajets directs en fonction des villes
    Q_OBJECT

private:
    QTableWidget* tableauMatrice;
    QPushButton* btnFermer;
    QPushButton* btnExporter;
    QLabel* lblTitre;
    QComboBox* comboFiltreRegion;
    QSpinBox* spinLimiteVilles;
    QPushButton* btnFiltrer;

    const std::vector<Ville*>& villes;
    const std::vector<Trajet*>& trajets;

    // Carte des trajets directs: ville1_id -> ville2_id -> temps
    std::map<size_t, std::map<size_t, size_t>> matriceTrajetsDirects;

    // Liste des villes actuellement affichées
    std::vector<Ville*> villesAffichees;

    void construireMatriceTrajets();
    void remplirTableau();
    void appliquerFiltres();   // Affiché colorés les trajets possibles
    QString formaterTemps(size_t minutes) const;

public:
    MatriceTrajetsDialog(QWidget* parent,
                         const std::vector<Ville*>& villes,
                         const std::vector<Trajet*>& trajets);

private slots:
    void exporterCSV();
    void filtrerDonnees();
};

#endif // MATRICETRAJETSDIALOG_H
