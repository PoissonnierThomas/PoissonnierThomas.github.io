#include "ville.h"
#ifndef TRAJET_H
#define TRAJET_H

class Trajet
{
private:
    const Ville* ville1; // Villes pouvant être lues dans les deux sens, il n'y a pas de ville de départ et d'arrivée mais 1 et 2
    const Ville* ville2;
    size_t temps; // Indiqué en minutes comme pour le fichier .csv
    size_t idVille1; // Pour stocker les IDs temporairement
    size_t idVille2;
public:
    Trajet(std::istream &is, const std::vector<Ville*> &Villes); // Pour contenir les potentielles étapes
    ~Trajet() {}
    inline const Ville* getVille1() const { return ville1; }
    inline const Ville* getVille2() const { return ville2; }
    inline void setVille1(const Ville* ville) {ville1 = ville;};
    inline void setVille2(const Ville* ville) {ville2 = ville;};
    inline size_t getTemps() const { return temps; }
    inline size_t getIdVille1() const { return idVille1; }
    inline size_t getIdVille2() const { return idVille2; }
};

#endif // TRAJET_H
