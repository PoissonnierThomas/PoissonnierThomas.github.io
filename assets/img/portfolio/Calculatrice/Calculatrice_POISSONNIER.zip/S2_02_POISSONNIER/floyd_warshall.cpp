#include "floyd_warshall.h"
#include <algorithm>
#include <iostream>
#include <QDebug>

// Constructeur
FloydWarshall::FloydWarshall(const std::vector<Ville*>& villes, const std::vector<Trajet*>& trajets) {
    // Créer un vecteur de pointeurs constants vers les villes
    for (const auto& ville : villes) {
        this->villes.push_back(ville);
        villeToIndex[ville] = this->villes.size() - 1;
    }

    size_t n = this->villes.size();
    qDebug() << "Initialisation de Floyd-Warshall avec" << n << "villes et" << trajets.size() << "trajets";

    // Initialiser les matrices dist et next
    const size_t INF = std::numeric_limits<size_t>::max() / 2; // Diviser par 2 pour imposer une limite lors des additions

    // Initialiser toutes les distances à l'infini et next à un indicateur d'absence de chemin
    dist = std::vector<std::vector<size_t>>(n, std::vector<size_t>(n, INF));
    next = std::vector<std::vector<size_t>>(n, std::vector<size_t>(n, n)); // n est utilisé comme indicateur "pas de chemin"

    // La distance d'une ville à elle-même est 0
    for (size_t i = 0; i < n; i++) {
        dist[i][i] = 0;
        next[i][i] = i; // Chemin de i à i est i
    }

    // Remplir la matrice avec les trajets connus
    int trajetsUtilises = 0;
    for (const auto& trajet : trajets) {
        const Ville* ville1 = trajet->getVille1();
        const Ville* ville2 = trajet->getVille2();

        // Vérifier que les deux villes sont bien définies
        if (ville1 && ville2) {
            size_t i = villeToIndex[ville1];
            size_t j = villeToIndex[ville2];
            size_t temps = trajet->getTemps();

            // Si ce chemin est plus court que l'actuel
            if (temps < dist[i][j]) {
                dist[i][j] = temps;
                next[i][j] = j;  // Chemin direct
                trajetsUtilises++;
            }

            // Considérer le trajet dans l'autre sens aussi (bidirectionnel)
            if (temps < dist[j][i]) {
                dist[j][i] = temps;
                next[j][i] = i;  // Chemin direct dans l'autre sens
                trajetsUtilises++;
            }
        }
    }

    qDebug() << "Nombre de trajets utilisés:" << trajetsUtilises;

    // Exécuter l'algorithme de Floyd-Warshall
    qDebug() << "Exécution de l'algorithme Floyd-Warshall...";
    for (size_t k = 0; k < n; k++) {
        for (size_t i = 0; i < n; i++) {
            for (size_t j = 0; j < n; j++) {
                if (dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                    next[i][j] = next[i][k];  // Change la matrice next
                }
            }
        }
    }
    qDebug() << "Algorithme Floyd-Warshall terminé.";

    // Vérifier que le graphe est bien connecté
    int cheminsValides = 0;
    int cheminsPossibles = n * (n - 1);
    for (size_t i = 0; i < n; i++) {
        for (size_t j = 0; j < n; j++) {
            if (i != j && dist[i][j] < INF) {
                cheminsValides++;
            }
        }
    }

    double pourcentage = (static_cast<double>(cheminsValides) / cheminsPossibles) * 100.0;
    qDebug() << "Connectivité du graphe:" << cheminsValides << "/" << cheminsPossibles
             << "(" << pourcentage << "% des chemins possibles)";
}

// Retourne le temps du trajet le plus court entre deux villes
size_t FloydWarshall::getTempsTrajet(const Ville* depart, const Ville* arrivee) const {
    // Vérifier que les villes existent dans notre graphe
    if (villeToIndex.find(depart) == villeToIndex.end() ||
        villeToIndex.find(arrivee) == villeToIndex.end()) {
        qDebug() << "getTempsTrajet: Une des villes n'existe pas dans le graphe";
        return std::numeric_limits<size_t>::max();
    }

    size_t i = villeToIndex.at(depart);
    size_t j = villeToIndex.at(arrivee);

    return dist[i][j];
}

// Reconstruit et retourne le chemin le plus court entre deux villes
std::vector<const Ville*> FloydWarshall::getChemin(const Ville* depart, const Ville* arrivee) const {
    std::vector<const Ville*> chemin;

    // Vérifier que les villes existent dans notre graphe
    if (villeToIndex.find(depart) == villeToIndex.end() ||
        villeToIndex.find(arrivee) == villeToIndex.end()) {
        qDebug() << "getChemin: Une des villes n'existe pas dans le graphe";
        return chemin; // Chemin vide
    }

    size_t i = villeToIndex.at(depart);
    size_t j = villeToIndex.at(arrivee);

    // Obtenir les noms des villes pour l'afficher dans qDebug()
    std::string nomDepart = depart->getNom();
    std::string nomArrivee = arrivee->getNom();

    qDebug() << "Reconstruction du chemin de" << QString::fromStdString(nomDepart)
             << "à" << QString::fromStdString(nomArrivee);
    qDebug() << "Indices:" << i << "->" << j;

    const size_t INF = std::numeric_limits<size_t>::max() / 2;
    if (dist[i][j] >= INF) {
        qDebug() << "Aucun chemin trouvé (distance infinie)";
        return chemin; // Pas de chemin trouvé
    }

    // Ajouter la ville de départ
    chemin.push_back(villes[i]);
    qDebug() << "Ajout de" << QString::fromStdString(villes[i]->getNom()) << "au chemin";

    // Reconstruire le chemin
    while (i != j) {
        i = next[i][j];
        if (i >= villes.size()) {
            qDebug() << "Erreur: indice de ville invalide" << i;
            break; // Sécurité pour éviter une boucle infinie
        }
        chemin.push_back(villes[i]);
        qDebug() << "Ajout de" << QString::fromStdString(villes[i]->getNom()) << "au chemin";
    }

    qDebug() << "Chemin reconstruit avec" << chemin.size() << "étapes";
    return chemin;
}

// Fonction permettant d'obtenir la matrice des distances
const std::vector<std::vector<size_t>>& FloydWarshall::getDistMatrix() const {
    return dist;
}

// Fonction pour trouver le chemin le plus court entre deux villes
ResultatChemin trouverCheminPlusCourt(
    const std::vector<Ville*>& villes,
    const std::vector<Trajet*>& trajets,
    const Ville* villeDepart,
    const Ville* villeArrivee) {

    // Créer le graphe et appliquer Floyd-Warshall
    FloydWarshall fw(villes, trajets);

    // Trouver le temps du trajet le plus court
    size_t temps = fw.getTempsTrajet(villeDepart, villeArrivee);

    // Reconstruire le chemin le plus court
    std::vector<const Ville*> chemin = fw.getChemin(villeDepart, villeArrivee);

    return {temps, chemin};
}
