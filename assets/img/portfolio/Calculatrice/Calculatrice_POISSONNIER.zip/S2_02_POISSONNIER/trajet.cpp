#include "trajet.h"
#include <vector>

// Implémentation d'un outil permettant la construction du trajet
const Ville* searchVille(const std::string& nom, const std::vector<Ville*> &Villes)
{
    // Recherche par nom exact d'abord
    for (const Ville* ville : Villes)
    {
        if (nom == ville->getNom())
            return ville;
    }
// Recherche par ID si le nom est un nombre
    try {
        size_t id = std::stoull(nom);
        for (const Ville* ville : Villes)
        {
            if (id == ville->getId())
                return ville;
        }
    } catch(...) {
        // Ce n'est pas un ID, continuer avec d'autres méthodes de recherche
    }
    // Recherche par nom ASCII (alternative)
    for (const Ville* ville : Villes)
    {
        if (nom == ville->getNomAscii())
            return ville;
    }

    // Recherche dans les noms alternatifs
    for (const Ville* ville : Villes)
    {
        std::string alternatifs = ville->getNomAlternatifs();
        if (alternatifs.find(nom) != std::string::npos)
            return ville;
    }

    return nullptr;
}








// Implémentation du constructeur de Trajet
// Format attendu: ville1, ville2, temps
Trajet::Trajet(std::istream &is, const std::vector<Ville*> &Villes) {
    std::string ligne;
    if (std::getline(is, ligne)) {
        std::stringstream ss(ligne);
        std::string token;

        // Initialisation des pointeurs à null
        ville1 = nullptr;
        ville2 = nullptr;
        temps = 0;
        idVille1 = 0;
        idVille2 = 0;

        // Lecture de la première ville
        if (std::getline(ss, token, ',')) {
            try {
                // Essayer d'abord de récupérer l'ID si c'est un nombre
                idVille1 = std::stoull(token);
                // Chercher la ville par ID
                for (const Ville* ville : Villes) {
                    if (ville->getId() == idVille1) {
                        ville1 = ville;
                        break;
                    }
                }
            } catch(...) {
                // Si ce n'est pas un ID, chercher par nom
                ville1 = searchVille(token, Villes);
            }
        }

        // Lecture de la seconde ville
        if (std::getline(ss, token, ',')) {
            try {
                // Essayer d'abord de récupérer l'ID si c'est un nombre
                idVille2 = std::stoull(token);
                // Chercher la ville par ID
                for (const Ville* ville : Villes) {
                    if (ville->getId() == idVille2) {
                        ville2 = ville;
                        break;
                    }
                }
            } catch(...) {
                // Si ce n'est pas un ID, chercher par nom
                ville2 = searchVille(token, Villes);
            }
        }

        // Lecture du temps
        if (std::getline(ss, token)) {
            try {
                temps = std::stoull(token);
            } catch(...) {
                temps = 0;
            }
        }
    }
}
