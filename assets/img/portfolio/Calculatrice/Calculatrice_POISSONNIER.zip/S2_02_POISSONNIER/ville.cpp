#include "ville.h"
#include <QDebug>


// Implémentation du constructeur de Ville
Ville::Ville(std::istream &is) {
    std::string ligne;
    if (std::getline(is, ligne)) {
        std::stringstream ss(ligne);
        std::string token;
        std::string nomIdentique;

        // Format attendu du CSV:
        // nom;nomascii;nomsalternatifs;latitude;longitude;pays;iso2;iso3;
        // nom région;nomasciiregion;coderegion;capital;densité;population;
        // populationalentour;rang;fuseau;nomidentique;id

        // nom
        if (std::getline(ss, token, ';')) {
            nom = token;
        }

        // nomascii
        if (std::getline(ss, token, ';')) {
            nom_ASCII = token;
        }

        // nomsalternatifs
        if (std::getline(ss, token, ';')) {
            nomsalternatifs = token;
        }

        // latitude
        if (std::getline(ss, token, ';')) {
            try {
                latitude = std::stod(token);
            } catch(...) {
                latitude = 0.0;
            }
        }

        // longitude
        if (std::getline(ss, token, ';')) {
            try {
                longitude = std::stod(token);
            } catch(...) {
                longitude = 0.0;
            }
        }

        // pays
        if (std::getline(ss, token, ';')) {
            pays = token;
        }

        // iso2
        if (std::getline(ss, token, ';')) {
            iso2 = token;
        }

        // iso3
        if (std::getline(ss, token, ';')) {
            iso3 = token;
        }

        // nom région
        if (std::getline(ss, token, ';')) {
            region = token;
        }

        // nomasciiregion
        if (std::getline(ss, token, ';')) {
            regionASCII =token;
        }

        // coderegion
        if (std::getline(ss, token, ';')) {
            regioncode = token;
        }

        // regiontype
        if (std::getline(ss, token, ';')) {
            region_type = token;
        }

        // capital
        if (std::getline(ss, token, ';')) {
            capital = token;
        }

        // densité
        if (std::getline(ss, token, ';')) {
            try {
                densite = std::stod(token);
            } catch(...) {
                densite = 0.0;
            }
        }

        // population
        if (std::getline(ss, token, ';')) {
            try {
                population = std::stod(token);
            } catch(...) {
                population = 0.0;
            }
        }

        // populationalentour
        if (std::getline(ss, token, ';')) {
            try {
                population_zone = std::stod(token);
            } catch(...) {
                population_zone = 0.0;
            }
        }

        // rang
        if (std::getline(ss, token, ';')) {
            try {
                ranking = std::stoi(token);
            } catch(...) {
                ranking = 0;
            }
        }

        // fuseau
        if (std::getline(ss, token, ';')) {
            fuseau = token;
        }


        // nomidentique
        if (std::getline(ss, token, ';')) {
            nom_identique = (token == "1" || token == "true" || token == "oui");
        }

        // id (dernier élément)
        if (std::getline(ss, token,' ')) {
            try {
                id = std::stoull(token);
            } catch(...) {
                id = 0;
            }
        }
    }
}



// Implémentation de l'opérateur << pour les objets Ville
std::ostream& operator<<(std::ostream &os, const Ville& ville) {
    os << ville.getNom() << " (" << ville.getPays() << ")";
    return os;
}


std::ostream& Ville::getAll(std::ostream &os) const
{
    os << getNom() << " "  << getNomAscii()  << " "  << getNomAlternatifs()  << " " << getPays()  << " " << getIso2()  << " " << getIso3()  << " " ;
    os << getRegion()  << " " << getCapital() << getDensite()  << " " << getLongitude()  << " "  << getLatitude()  << " "<< getPopulation() << " " << getPopulationZone() << " " ;
    os << getRanking()  << " " << getFuseau() << " " ;
    return os;
}


void Ville::getAll() const
{
    qDebug() << getNom() << " "  << getNomAscii()  << " "  << getNomAlternatifs()  << " " << getPays()  << " " << getIso2()  << " " << getIso3()  << " " ;
    qDebug() << getRegion()  << " " << getCapital() << getDensite()  << " " << getLongitude()  << " "  << getLatitude()  << " "<< getPopulation() << " " << getPopulationZone() << " " ;
    qDebug() << getRanking()  << " " << getFuseau() << " " ;
}
