package group.keyp;

import java.security.MessageDigest;
import java.util.Base64;
import java.nio.charset.StandardCharsets;

/**
 * Context class for the Strategy design pattern implementation.
 * This class manages the current encryption strategy and delegates
 * encryption/decryption operations to the selected strategy.
 * 
 * <p>The Strategy pattern provides:</p>
 * <ul>
 *   <li>Encapsulation of different encryption algorithms</li>
 *   <li>Runtime algorithm selection and switching</li>
 *   <li>Easy addition of new algorithms without code modification</li>
 * </ul>
 * 
 * <p><b>Example usage:</b></p>
 * <pre>
 * EncryptionContext context = new EncryptionContext("AES");
 * String encrypted = context.encrypt("my secret text");
 * context.setStrategy("BLOWFISH"); // Switch algorithm
 * String encrypted2 = context.encrypt("another secret");
 * </pre>
 * 
 * @author Thomas Poissonnier
 * @see EncryptionStrategy
 */
public class EncryptionContext {
    
    /**
     * The current encryption strategy being used.
     */
    private EncryptionStrategy strategy;
    
    /**
     * Constructs a new EncryptionContext with AES as the default strategy.
     */
    public EncryptionContext() {
        this.strategy = new AESEncryption(); // Default strategy
    }
    
    /**
     * Constructs a new EncryptionContext with the specified encryption algorithm.
     * 
     * @param algorithmName the name of the encryption algorithm (AES, DES, or BLOWFISH)
     */
    public EncryptionContext(String algorithmName) {
        setStrategy(algorithmName);
    }
    
    /**
     * Changes the current encryption strategy.
     * This method demonstrates the Strategy pattern's flexibility by allowing
     * runtime algorithm switching.
     * 
     * @param algorithmName the name of the new encryption algorithm (AES, DES, or BLOWFISH)
     */
    public void setStrategy(String algorithmName) {
        switch (algorithmName.toUpperCase()) {
            case "AES":
                this.strategy = new AESEncryption();
                break;
            case "DES":
                this.strategy = new DESEncryption();
                break;
            case "BLOWFISH":
                this.strategy = new BlowfishEncryption();
                break;
            default:
                this.strategy = new AESEncryption();
        }
    }
    
    /**
     * Encrypts plain text using the current encryption strategy.
     * 
     * @param plainText the text to encrypt
     * @return the encrypted text encoded in Base64
     * @throws Exception if an encryption error occurs
     */
    public String encrypt(String plainText) throws Exception {
        return strategy.encrypt(plainText);
    }
    
    /**
     * Decrypts encrypted text using the current encryption strategy.
     * 
     * @param encryptedText the encrypted text in Base64 format
     * @return the decrypted plain text
     * @throws Exception if a decryption error occurs
     */
    public String decrypt(String encryptedText) throws Exception {
        return strategy.decrypt(encryptedText);
    }
    
    /**
     * Returns the name of the current encryption algorithm.
     * 
     * @return the algorithm name (AES, DES, or BLOWFISH)
     */
    public String getAlgorithmName() {
        return strategy.getAlgorithmName();
    }
    
    /**
     * Hashes a password using SHA-256 algorithm.
     * This method is used for storing user account passwords securely.
     * 
     * @param password the password to hash
     * @return the password hash encoded in Base64
     * @throws Exception if hashing fails
     */
    public static String hashPassword(String password) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(hash);
    }
}