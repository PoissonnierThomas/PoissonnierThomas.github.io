package group.keyp;

import javafx.application.Application;
import javafx.scene.layout.BorderPane;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.geometry.Pos;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Priority;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.geometry.Insets;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.TableRow;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.control.ComboBox;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import java.time.temporal.ChronoUnit;

/**
 * Main application class for the Keyp password manager.
 * This class implements the View and Controller components of the MVC design pattern,
 * managing the JavaFX user interface and application logic.
 * 
 * <p>The application provides:</p>
 * <ul>
 *   <li>Secure password storage with multiple encryption algorithms (AES, DES, Blowfish)</li>
 *   <li>User authentication and registration system</li>
 *   <li>Password expiration tracking and alerts</li>
 *   <li>Password management operations (add, edit, delete, copy)</li>
 *   <li>Dynamic encryption algorithm switching</li>
 * </ul>
 * 
 * <p><b>Design Patterns Implemented:</b></p>
 * <ul>
 *   <li><b>MVC (Model-View-Controller):</b> Separates data (User, Password), 
 *       view (JavaFX UI), and control logic (event handlers)</li>
 *   <li><b>DAO (Data Access Object):</b> UserManager and UserDataManager classes
 *       encapsulate all data persistence operations</li>
 *   <li><b>Strategy:</b> EncryptionStrategy interface allows flexible selection
 *       and runtime switching of encryption algorithms</li>
 * </ul>
 * 
 * @author Thomas Poissonnier
 */
public class App extends Application {
    
    /**
     * The currently authenticated user.
     * Contains user information and their password collection.
     */
    User user;
    
    /**
     * Observable list of passwords for the JavaFX TableView.
     * Automatically updates the UI when passwords are added or removed.
     */
    ObservableList<Password> passwords;
    
    /**
     * The main application stage (window).
     */
    Stage mainStage;
    
    /**
     * The table view component displaying password entries.
     */
    TableView<Password> table;
    
    /**
     * Data Access Object for user account operations.
     * Handles authentication, registration, and account persistence.
     */
    UserManager userManager;
    
    /**
     * Data Access Object for user password data operations.
     * Handles loading and saving password collections for individual users.
     */
    UserDataManager userDataManager;
    
    /**
     * Application entry point. Initializes the user manager and displays the login window.
     * This method is called by the JavaFX runtime when the application starts.
     * 
     * @param stage the primary stage provided by JavaFX
     */
    @Override
    public void start(Stage stage) {
        mainStage = stage;
        userManager = new UserManager();
        showConnexionStage();
    }

    /**
     * Main method to launch the JavaFX application.
     * 
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        launch();
    }
    
    /**
     * Displays the login and registration window.
     * This window allows users to either authenticate with existing credentials
     * or register a new account with their choice of encryption algorithm.
     * 
     * <p>Features:</p>
     * <ul>
     *   <li>Toggle between login and registration modes</li>
     *   <li>Password masking with PasswordField</li>
     *   <li>Encryption algorithm selection during registration</li>
     *   <li>Application exit on cancel</li>
     * </ul>
     */
    public void showConnexionStage() {
        Stage connexionStage = new Stage();
        BorderPane borderPane = new BorderPane();
        var scene = new Scene(borderPane, 400, 400);
        
        // Load CSS stylesheet
        try {
            String css = this.getClass().getClassLoader().getResource("style.css").toExternalForm();
            scene.getStylesheets().add(css);
            System.out.println("✓ CSS loaded: " + css);
        } catch (Exception e) {
            System.err.println("✗ CSS not found, using default styling");
            System.err.println("Error: " + e.getMessage());
        }
        
        connexionStage.setScene(scene);
        connexionStage.setTitle("Connexion Keyp");
        connexionStage.setResizable(false);
        
        // Main container with styling
        VBox mainContainer = new VBox();
        mainContainer.getStyleClass().add("connection-container");
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setSpacing(20);
        mainContainer.setPadding(new Insets(30));
        
        // Welcome title
        Label Welcome = new Label("🔐 Keyp");
        Welcome.getStyleClass().add("welcome-label");
        
        Label subtitle = new Label("Gestionnaire de mots de passe sécurisé");
        subtitle.setStyle("-fx-font-size: 12px; -fx-text-fill: white;");
        
        VBox headerBox = new VBox(5);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.getChildren().addAll(Welcome, subtitle);
        
        // Login form
        VBox formBox = new VBox(15);
        formBox.setAlignment(Pos.CENTER);
        formBox.setPadding(new Insets(20, 0, 20, 0));
        
        HBox hbox1 = new HBox(10);
        hbox1.setAlignment(Pos.CENTER);
        Label login = new Label("Login :");
        login.setPrefWidth(100);
        login.setStyle("-fx-font-weight: bold;");
        TextField loginTF = new TextField();
        loginTF.setPromptText("Nom d'utilisateur");
        loginTF.setPrefWidth(200);
        hbox1.getChildren().addAll(login, loginTF);

        HBox hbox2 = new HBox(10);
        hbox2.setAlignment(Pos.CENTER);
        Label password = new Label("Password :");
        password.setPrefWidth(100);
        password.setStyle("-fx-font-weight: bold;");
        PasswordField passwordTF = new PasswordField();
        passwordTF.setPromptText("Mot de passe");
        passwordTF.setPrefWidth(200);
        hbox2.getChildren().addAll(password, passwordTF);
        
        // ComboBox for encryption algorithm selection (visible only during registration)
        HBox hbox3 = new HBox(10);
        hbox3.setAlignment(Pos.CENTER);
        Label algorithmLabel = new Label("Cryptage :");
        algorithmLabel.setPrefWidth(100);
        algorithmLabel.setStyle("-fx-font-weight: bold;");
        ComboBox<String> algorithmComboBox = new ComboBox<>();
        algorithmComboBox.getItems().addAll("AES (Recommandé)", "DES", "BLOWFISH");
        algorithmComboBox.setValue("AES (Recommandé)");
        algorithmComboBox.setPrefWidth(200);
        hbox3.getChildren().addAll(algorithmLabel, algorithmComboBox);
        hbox3.setVisible(false);
        hbox3.setManaged(false);
        
        formBox.getChildren().addAll(hbox1, hbox2, hbox3);

        // Mode state tracker
        final boolean[] isRegisterMode = {false};
        
        // Login button
        Button buttonLogin = new Button("Se connecter");
        buttonLogin.getStyleClass().add("button-primary");
        buttonLogin.setPrefWidth(150);
        buttonLogin.setOnAction(e -> {
            String enteredLogin = loginTF.getText();
            String enteredPassword = passwordTF.getText();
            
            if (userManager.authenticate(enteredLogin, enteredPassword)) {
                userDataManager = new UserDataManager(enteredLogin);
                user = userDataManager.loadUserData();
                connexionStage.close();
                showMainApplication();
            } else {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Erreur de connexion");
                alert.setHeaderText("Identifiants incorrects");
                alert.setContentText("Le login ou le mot de passe est incorrect.");
                alert.showAndWait();
            }
        });
        
        // Register button
        Button buttonRegister = new Button("S'enregistrer");
        buttonRegister.getStyleClass().add("button-success");
        buttonRegister.setPrefWidth(150);
        buttonRegister.setVisible(false);
        buttonRegister.setManaged(false);
        buttonRegister.setOnAction(e -> {
            String enteredLogin = loginTF.getText();
            String enteredPassword = passwordTF.getText();
            String selectedAlgorithm = algorithmComboBox.getValue().split(" ")[0];
            
            if (enteredLogin.isEmpty() || enteredPassword.isEmpty()) {
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("Champs vides");
                alert.setHeaderText("Veuillez remplir tous les champs");
                alert.setContentText("Le login et le mot de passe ne peuvent pas être vides.");
                alert.showAndWait();
                return;
            }
            
            if (userManager.registerUser(enteredLogin, enteredPassword)) {
                UserDataManager newUserDataManager = new UserDataManager(enteredLogin);
                User newUser = new User(1, enteredLogin, "", enteredPassword, selectedAlgorithm);
                newUserDataManager.saveUserData(newUser);
                
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Succès");
                alert.setHeaderText("Enregistrement réussi");
                alert.setContentText("Votre compte a été créé avec le cryptage " + selectedAlgorithm + ".\nVous pouvez maintenant vous connecter.");
                alert.showAndWait();
                
                // Return to login mode
                isRegisterMode[0] = false;
                buttonLogin.setVisible(true);
                buttonLogin.setManaged(true);
                buttonRegister.setVisible(false);
                buttonRegister.setManaged(false);
                hbox3.setVisible(false);
                hbox3.setManaged(false);
            } else {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Erreur");
                alert.setHeaderText("Enregistrement échoué");
                alert.setContentText("Cet utilisateur existe déjà.");
                alert.showAndWait();
            }
        });
        
        // Cancel button
        Button buttonCancel = new Button("Annuler");
        buttonCancel.getStyleClass().add("button-secondary");
        buttonCancel.setPrefWidth(150);
        buttonCancel.setOnAction(e -> {
            connexionStage.close();
            System.exit(0);
        });

        // Main button box (Login/Register + Cancel)
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(buttonLogin, buttonRegister, buttonCancel);
        
        // Toggle button to switch between login and registration modes
        Button toggleModeButton = new Button("Créer un compte");
        toggleModeButton.getStyleClass().add("button-secondary");
        toggleModeButton.setStyle("-fx-font-size: 11px;");
        toggleModeButton.setOnAction(e -> {
            isRegisterMode[0] = !isRegisterMode[0];
            if (isRegisterMode[0]) {
                // Switch to registration mode
                buttonLogin.setVisible(false);
                buttonLogin.setManaged(false);
                buttonRegister.setVisible(true);
                buttonRegister.setManaged(true);
                hbox3.setVisible(true);
                hbox3.setManaged(true);
                toggleModeButton.setText("Retour à la connexion");
            } else {
                // Switch to login mode
                buttonLogin.setVisible(true);
                buttonLogin.setManaged(true);
                buttonRegister.setVisible(false);
                buttonRegister.setManaged(false);
                hbox3.setVisible(false);
                hbox3.setManaged(false);
                toggleModeButton.setText("Créer un compte");
            }
        });
        
        HBox toggleBox = new HBox();
        toggleBox.setAlignment(Pos.CENTER);
        toggleBox.setPadding(new Insets(5, 0, 0, 0));
        toggleBox.getChildren().add(toggleModeButton);

        mainContainer.getChildren().addAll(headerBox, formBox, buttonBox, toggleBox);
        
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: linear-gradient(to bottom, #3498db, #2c3e50);");
        root.getChildren().add(mainContainer);
        
        borderPane.setCenter(root);
        
        connexionStage.show();
    }
    
    /**
     * Displays the main application window after successful authentication.
     * This is the primary interface where users manage their passwords.
     * 
     * <p>Features:</p>
     * <ul>
     *   <li>Password table with show/hide functionality</li>
     *   <li>CRUD operations (Create, Read, Update, Delete)</li>
     *   <li>Double-click to copy password to clipboard</li>
     *   <li>Expiration checking</li>
     *   <li>Dynamic encryption algorithm switching</li>
     * </ul>
     * 
     * <p>The interface is organized into:</p>
     * <ul>
     *   <li>Top bar: Welcome message, encryption info, and show/hide checkbox</li>
     *   <li>Center: Password table with 4 columns</li>
     *   <li>Bottom: Action buttons in two rows</li>
     * </ul>
     */
    public void showMainApplication() {
        BorderPane borderPane = new BorderPane();
        var scene = new Scene(borderPane, 900, 600);
        
        // Load CSS stylesheet
        try {
            String css = this.getClass().getClassLoader().getResource("style.css").toExternalForm();
            scene.getStylesheets().add(css);
            System.out.println("✓ CSS loaded: " + css);
        } catch (Exception e) {
            System.err.println("✗ CSS not found, using default styling");
            System.err.println("Error: " + e.getMessage());
        }
        
        mainStage.setScene(scene);
        mainStage.setTitle("Keyp - Gestionnaire de mots de passe");
        
        passwords = FXCollections.observableArrayList(user.getPasswordTable());
        
        CheckBox showPasswordsCheckBox = new CheckBox("Afficher les mots de passe");
        showPasswordsCheckBox.setSelected(false);
        
        table = new TableView<>();
        TableColumn<Password, String> descriptionCol = new TableColumn<>("Application");
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        descriptionCol.prefWidthProperty().bind(table.widthProperty().multiply(0.25));
        
        TableColumn<Password, String> loginCol = new TableColumn<>("Login");
        loginCol.setCellValueFactory(new PropertyValueFactory<>("login"));
        loginCol.prefWidthProperty().bind(table.widthProperty().multiply(0.25));
        
        TableColumn<Password, String> passwordCol = new TableColumn<>("Mot de passe");
        passwordCol.setCellValueFactory(cellData -> {
            Password p = cellData.getValue();
            if (showPasswordsCheckBox.isSelected()) {
                return new javafx.beans.property.SimpleStringProperty(p.getPassword());
            } else {
                return new javafx.beans.property.SimpleStringProperty("••••••••");
            }
        });
        passwordCol.prefWidthProperty().bind(table.widthProperty().multiply(0.25));
        
        TableColumn<Password, String> dateCol = new TableColumn<>("Date d'expiration");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("expirationDate"));
        dateCol.prefWidthProperty().bind(table.widthProperty().multiply(0.25));
        
        table.getColumns().addAll(descriptionCol, loginCol, passwordCol, dateCol);
        table.setItems(passwords);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        showPasswordsCheckBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
            table.refresh();
        });
        
        // Double-click to copy password
        table.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                Password selectedPassword = table.getSelectionModel().getSelectedItem();
                if (selectedPassword != null) {
                    copyToClipboard(selectedPassword.getPassword());
                    showAlert("Succès", "Mot de passe copié dans le presse-papier", AlertType.INFORMATION);
                }
            }
        });
        
        // Top bar with welcome message, encryption info, and checkbox
        HBox topBar = new HBox(20);
        topBar.getStyleClass().add("top-bar");
        topBar.setAlignment(Pos.CENTER_LEFT);
        
        String encryptionInfo = user.getEncryptionType() != null ? user.getEncryptionType() : "AES";
        Label welcome = new Label("👋 Bienvenue " + user.getFirstName());
        welcome.getStyleClass().add("title-label");
        
        Label encryptionLabel = new Label("🔐 Cryptage : " + encryptionInfo);
        encryptionLabel.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");
        
        Button changeEncryptionButton = new Button("Changer");
        changeEncryptionButton.getStyleClass().add("button-info");
        changeEncryptionButton.setStyle("-fx-font-size: 11px; -fx-padding: 5 10 5 10;");
        changeEncryptionButton.setOnAction(e -> {
            // Dialog to choose new encryption algorithm
            ComboBox<String> algoChoice = new ComboBox<>();
            algoChoice.getItems().addAll("AES (Recommandé)", "DES", "BLOWFISH");
            
            String currentAlgo = user.getEncryptionType() != null ? user.getEncryptionType() : "AES";
            algoChoice.setValue(currentAlgo + (currentAlgo.equals("AES") ? " (Recommandé)" : ""));
            
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Changer l'algorithme de cryptage");
            alert.setHeaderText("Choisir un nouvel algorithme");
            alert.setContentText("Attention : Tous vos mots de passe seront re-cryptés avec le nouvel algorithme.");
            
            VBox dialogContent = new VBox(10);
            dialogContent.getChildren().addAll(new Label("Nouvel algorithme :"), algoChoice);
            alert.getDialogPane().setContent(dialogContent);
            
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                String newAlgorithm = algoChoice.getValue().split(" ")[0];
                user.setEncryptionType(newAlgorithm);
                saveUserData();
                
                // Update display
                encryptionLabel.setText("🔐 Cryptage : " + newAlgorithm);
                
                showAlert("Succès", "L'algorithme de cryptage a été changé vers " + newAlgorithm + ".\nTous vos mots de passe ont été re-cryptés.", AlertType.INFORMATION);
            }
        });
        
        HBox encryptionBox = new HBox(10);
        encryptionBox.setAlignment(Pos.CENTER_LEFT);
        encryptionBox.getChildren().addAll(encryptionLabel, changeEncryptionButton);
        
        HBox.setHgrow(welcome, Priority.ALWAYS);
        topBar.getChildren().addAll(welcome, encryptionBox, showPasswordsCheckBox);
        
        // Main container
        VBox centerContainer = new VBox();
        centerContainer.getStyleClass().add("main-container");
        VBox.setVgrow(table, Priority.ALWAYS);
        centerContainer.getChildren().addAll(topBar, table);
        
        borderPane.setCenter(centerContainer);
        
        // Buttons - Row 1: CRUD operations
        HBox buttonRow1 = new HBox(10);
        buttonRow1.setAlignment(Pos.CENTER);
        
        Button buttonAdd = new Button("➕ Ajouter");
        buttonAdd.getStyleClass().add("button-primary");
        buttonAdd.setOnAction(e -> openEditor(null));
        
        Button buttonModify = new Button("✏ Modifier");
        buttonModify.getStyleClass().add("button-warning");
        buttonModify.setOnAction(e -> {
            Password P = table.getSelectionModel().getSelectedItem();
            openEditor(P);
        });
        buttonModify.disableProperty().bind(table.getSelectionModel().selectedItemProperty().isNull());
        
        Button buttonDelete = new Button("🗑 Supprimer");
        buttonDelete.getStyleClass().add("button-danger");
        buttonDelete.setOnAction(e -> {
            Password selectedPassword = table.getSelectionModel().getSelectedItem();
            if (selectedPassword != null) {
                Alert confirmDialog = new Alert(AlertType.CONFIRMATION);
                confirmDialog.setTitle("Confirmation de suppression");
                confirmDialog.setHeaderText("Supprimer le mot de passe");
                confirmDialog.setContentText("Êtes-vous sûr de vouloir supprimer le mot de passe pour :\n" + 
                                             selectedPassword.getDescription() + " (" + selectedPassword.getLogin() + ") ?");
                
                Optional<ButtonType> result = confirmDialog.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    passwords.remove(selectedPassword);
                    user.getPasswordTable().remove(selectedPassword);
                    saveUserData();
                    showAlert("Succès", "Mot de passe supprimé avec succès", AlertType.INFORMATION);
                }
            }
        });
        buttonDelete.disableProperty().bind(table.getSelectionModel().selectedItemProperty().isNull());
        
        buttonAdd.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(buttonAdd, Priority.ALWAYS);
        buttonModify.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(buttonModify, Priority.ALWAYS);
        buttonDelete.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(buttonDelete, Priority.ALWAYS);
        
        buttonRow1.getChildren().addAll(buttonAdd, buttonModify, buttonDelete);
        
        // Buttons - Row 2: Secondary actions
        HBox buttonRow2 = new HBox(10);
        buttonRow2.setAlignment(Pos.CENTER);
        
        Button buttonCopy = new Button("📋 Copier mot de passe");
        buttonCopy.getStyleClass().add("button-secondary");
        buttonCopy.setOnAction(e -> {
            Password selectedPassword = table.getSelectionModel().getSelectedItem();
            if (selectedPassword != null) {
                copyToClipboard(selectedPassword.getPassword());
                showAlert("Succès", "Mot de passe copié dans le presse-papier", AlertType.INFORMATION);
            }
        });
        buttonCopy.disableProperty().bind(table.getSelectionModel().selectedItemProperty().isNull());
        
        Button buttonCheckExpiry = new Button("⏰ Vérifier expirations");
        buttonCheckExpiry.getStyleClass().add("button-warning");
        buttonCheckExpiry.setOnAction(e -> checkExpiringPasswords());
        
        buttonCopy.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(buttonCopy, Priority.ALWAYS);
        buttonCheckExpiry.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(buttonCheckExpiry, Priority.ALWAYS);
        
        buttonRow2.getChildren().addAll(buttonCopy, buttonCheckExpiry);
        
        // Button container
        VBox buttonContainer = new VBox(10);
        buttonContainer.getStyleClass().add("button-bar");
        buttonContainer.getChildren().addAll(buttonRow1, buttonRow2);
        
        borderPane.setBottom(buttonContainer);
        
        mainStage.show();
    }

    /**
     * Opens the password editor dialog for creating or modifying a password entry.
     * The dialog adapts its behavior based on whether a password is being edited or created.
     * 
     * <p>Features:</p>
     * <ul>
     *   <li>Field validation (description, login, and password are required)</li>
     *   <li>DatePicker for expiration date selection</li>
     *   <li>Auto-population of fields when editing existing password</li>
     *   <li>Automatic save to encrypted file on confirmation</li>
     * </ul>
     * 
     * @param P the Password object to edit, or null to create a new password
     */
    public void openEditor(Password P) {
        Stage dlg = new Stage();
        BorderPane borderPane = new BorderPane();
        var scene = new Scene(borderPane, 450, 350);
        
        // Load CSS stylesheet
        try {
            String css = this.getClass().getClassLoader().getResource("style.css").toExternalForm();
            scene.getStylesheets().add(css);
            System.out.println("✓ CSS loaded: " + css);
        } catch (Exception e) {
            System.err.println("✗ CSS not found, using default styling");
            System.err.println("Error: " + e.getMessage());
        }
        
        dlg.setScene(scene);
        dlg.setTitle(P == null ? "➕ Ajouter un mot de passe" : "✏️ Modifier un mot de passe");
        
        // Title
        Label titleLabel = new Label(P == null ? "Nouveau mot de passe" : "Modifier le mot de passe");
        titleLabel.getStyleClass().add("title-label");
        titleLabel.setPadding(new Insets(15, 0, 10, 0));
        
        HBox titleBox = new HBox(titleLabel);
        titleBox.setAlignment(Pos.CENTER);
        titleBox.setStyle("-fx-background-color: #ecf0f1; -fx-padding: 10;");
        borderPane.setTop(titleBox);
        
        // Form
        VBox formContainer = new VBox(15);
        formContainer.setPadding(new Insets(20));
        formContainer.setAlignment(Pos.CENTER);
        
        // Description field
        HBox hbox1 = new HBox(10);
        hbox1.setAlignment(Pos.CENTER_LEFT);
        Label description = new Label("Description :");
        description.setPrefWidth(130);
        description.setStyle("-fx-font-weight: bold;");
        TextField descriptionTF = new TextField();
        descriptionTF.setPromptText("Ex: Gmail, Facebook...");
        HBox.setHgrow(descriptionTF, Priority.ALWAYS);
        hbox1.getChildren().addAll(description, descriptionTF);
        
        // Login field
        HBox hbox2 = new HBox(10);
        hbox2.setAlignment(Pos.CENTER_LEFT);
        Label login = new Label("Login :");
        login.setPrefWidth(130);
        login.setStyle("-fx-font-weight: bold;");
        TextField loginTF = new TextField();
        loginTF.setPromptText("Nom d'utilisateur");
        HBox.setHgrow(loginTF, Priority.ALWAYS);
        hbox2.getChildren().addAll(login, loginTF);
        
        // Password field
        HBox hbox3 = new HBox(10);
        hbox3.setAlignment(Pos.CENTER_LEFT);
        Label password = new Label("Mot de passe :");
        password.setPrefWidth(130);
        password.setStyle("-fx-font-weight: bold;");
        TextField passwordTF = new TextField();
        passwordTF.setPromptText("Mot de passe");
        HBox.setHgrow(passwordTF, Priority.ALWAYS);
        hbox3.getChildren().addAll(password, passwordTF);
        
        // Expiration date field
        HBox hbox4 = new HBox(10);
        hbox4.setAlignment(Pos.CENTER_LEFT);
        Label expDate = new Label("Date d'expiration :");
        expDate.setPrefWidth(130);
        expDate.setStyle("-fx-font-weight: bold;");
        DatePicker datePicker = new DatePicker();
        datePicker.setPromptText("jj/mm/aaaa");
        HBox.setHgrow(datePicker, Priority.ALWAYS);
        hbox4.getChildren().addAll(expDate, datePicker);
        
        formContainer.getChildren().addAll(hbox1, hbox2, hbox3, hbox4);
        borderPane.setCenter(formContainer);
        
        // Buttons
        HBox hboxButtons = new HBox(15);
        hboxButtons.setAlignment(Pos.CENTER);
        hboxButtons.setPadding(new Insets(15));
        hboxButtons.setStyle("-fx-background-color: #ecf0f1;");
        
        Button buttonOK = new Button("✓ Valider");
        buttonOK.getStyleClass().add("button-success");
        buttonOK.setPrefWidth(120);
        
        Button buttonCancel = new Button("✗ Annuler");
        buttonCancel.getStyleClass().add("button-secondary");
        buttonCancel.setPrefWidth(120);
        
        hboxButtons.getChildren().addAll(buttonOK, buttonCancel);
        borderPane.setBottom(hboxButtons);
        
        if (P != null) {
            // Edit mode: populate fields with existing data
            descriptionTF.setText(P.getDescription());
            loginTF.setText(P.getLogin());
            passwordTF.setText(P.getPassword());
            
            if (P.getExpirationDate() != null && !P.getExpirationDate().isEmpty() && !P.getExpirationDate().equals("None")) {
                try {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate date = LocalDate.parse(P.getExpirationDate(), formatter);
                    datePicker.setValue(date);
                } catch (Exception e) {
                    // Invalid date format, leave empty
                }
            }
            
            buttonOK.setOnAction(event -> {
                if (descriptionTF.getText().trim().isEmpty()) {
                    showAlert("Erreur", "La description est obligatoire", AlertType.WARNING);
                    return;
                }
                if (loginTF.getText().trim().isEmpty()) {
                    showAlert("Erreur", "Le login est obligatoire", AlertType.WARNING);
                    return;
                }
                if (passwordTF.getText().trim().isEmpty()) {
                    showAlert("Erreur", "Le mot de passe est obligatoire", AlertType.WARNING);
                    return;
                }
                
                P.setDescription(descriptionTF.getText());
                P.setLogin(loginTF.getText());
                P.setPassword(passwordTF.getText());
                
                if (datePicker.getValue() != null) {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    P.setExpirationDate(datePicker.getValue().format(formatter));
                } else {
                    P.setExpirationDate("None");
                }
                
                table.refresh();
                saveUserData();
                dlg.close();
            });
        } else {
            // Create mode: add new password
            buttonOK.setOnAction(event -> {
                if (descriptionTF.getText().trim().isEmpty()) {
                    showAlert("Erreur", "La description est obligatoire", AlertType.WARNING);
                    return;
                }
                if (loginTF.getText().trim().isEmpty()) {
                    showAlert("Erreur", "Le login est obligatoire", AlertType.WARNING);
                    return;
                }
                if (passwordTF.getText().trim().isEmpty()) {
                    showAlert("Erreur", "Le mot de passe est obligatoire", AlertType.WARNING);
                    return;
                }
                
                String expirationDate = "None";
                if (datePicker.getValue() != null) {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    expirationDate = datePicker.getValue().format(formatter);
                }
                
                Password newPassword = new Password(
                    loginTF.getText(), 
                    passwordTF.getText(), 
                    descriptionTF.getText(), 
                    expirationDate
                );
                passwords.add(newPassword);
                user.addPassword(newPassword);
                saveUserData();
                dlg.close();
            });
        }
        
        buttonCancel.setOnAction(e -> dlg.close());
        dlg.show();
    }
    
    /**
     * Saves the current user's data to their encrypted file.
     * This method delegates to the UserDataManager DAO, which handles
     * encryption and file I/O operations.
     */
    private void saveUserData() {
        if (userDataManager != null && user != null) {
            userDataManager.saveUserData(user);
        }
    }
    
    /**
     * Displays a simple alert dialog to the user.
     * This is a utility method to standardize alert presentation throughout the application.
     * 
     * @param title   the alert dialog title
     * @param content the alert message content
     * @param type    the alert type (ERROR, WARNING, INFORMATION, CONFIRMATION)
     */
    private void showAlert(String title, String content, AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
    /**
     * Copies text to the system clipboard.
     * Used primarily for copying passwords without displaying them.
     * 
     * @param text the text to copy to clipboard
     */
    private void copyToClipboard(String text) {
        Clipboard clipboard = Clipboard.getSystemClipboard();
        ClipboardContent content = new ClipboardContent();
        content.putString(text);
        clipboard.setContent(content);
    }
    
    /**
     * Prompts the user to check for expiring passwords within a specified time period.
     * Opens a dialog where the user can enter the number of days to check ahead.
     * If expiring passwords are found, displays them in a detailed table.
     * 
     * <p>This feature helps users maintain password security by alerting them
     * to passwords that need renewal.</p>
     */
    private void checkExpiringPasswords() {
        TextInputDialog dialog = new TextInputDialog("30");
        dialog.setTitle("Vérifier les expirations");
        dialog.setHeaderText("Vérification des mots de passe");
        dialog.setContentText("Nombre de jours avant expiration :");
        
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(days -> {
            try {
                int daysToCheck = Integer.parseInt(days);
                
                if (daysToCheck < 0) {
                    showAlert("Erreur", "Veuillez entrer un nombre positif", AlertType.ERROR);
                    return;
                }
                
                List<Password> expiring = getExpiringPasswords(daysToCheck);
                
                if (expiring.isEmpty()) {
                    showAlert("Information", 
                             "Aucun mot de passe n'expire dans les " + daysToCheck + " prochains jours.", 
                             AlertType.INFORMATION);
                } else {
                    showExpiringPasswordsDialog(expiring, daysToCheck);
                }
            } catch (NumberFormatException e) {
                showAlert("Erreur", "Veuillez entrer un nombre valide", AlertType.ERROR);
            }
        });
    }

    /**
     * Returns a list of passwords expiring within the specified number of days.
     * This includes both passwords expiring in the future and already expired passwords.
     * 
     * @param days the number of days to check ahead
     * @return a list of Password objects expiring within the time period
     */
    private List<Password> getExpiringPasswords(int days) {
        List<Password> expiringPasswords = new ArrayList<>();
        LocalDate today = LocalDate.now();
        LocalDate checkDate = today.plusDays(days);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        for (Password password : passwords) {
            String expirationDateStr = password.getExpirationDate();
            
            if (expirationDateStr == null || expirationDateStr.isEmpty() || 
                expirationDateStr.equals("None")) {
                continue;
            }
            
            try {
                LocalDate expirationDate = LocalDate.parse(expirationDateStr, formatter);
                
                if (!expirationDate.isBefore(today) && !expirationDate.isAfter(checkDate)) {
                    expiringPasswords.add(password);
                }
                else if (expirationDate.isBefore(today)) {
                    expiringPasswords.add(password);
                }
            } catch (Exception e) {
                System.err.println("Invalid date format for: " + password.getDescription());
            }
        }
        
        return expiringPasswords;
    }

    /**
     * Displays a dialog window showing passwords that are expiring soon.
     * The dialog presents a table with color-coded rows based on urgency:
     * <ul>
     *   <li>Red background: Already expired</li>
     *   <li>Yellow background: Expiring within 7 days</li>
     *   <li>White background: Expiring in more than 7 days</li>
     * </ul>
     * 
     * <p>The table includes columns for:</p>
     * <ul>
     *   <li>Description (application name)</li>
     *   <li>Login</li>
     *   <li>Expiration date</li>
     *   <li>Days remaining (or "EXPIRED" if already past due)</li>
     * </ul>
     * 
     * @param expiringPasswords the list of expiring Password objects to display
     * @param days              the number of days that was checked
     */
    private void showExpiringPasswordsDialog(List<Password> expiringPasswords, int days) {
        Stage dialog = new Stage();
        dialog.setTitle("⏰ Mots de passe expirant bientôt");
        
        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 700, 450);
        
        // Load CSS stylesheet
        try {
            String css = this.getClass().getClassLoader().getResource("style.css").toExternalForm();
            scene.getStylesheets().add(css);
            System.out.println("✓ CSS loaded: " + css);
        } catch (Exception e) {
            System.err.println("✗ CSS not found, using default styling");
            System.err.println("Error: " + e.getMessage());
        }
        
        dialog.setScene(scene);
        
        // Title
        Label title = new Label("⚠️ Mots de passe expirant dans les " + days + " prochains jours");
        title.getStyleClass().add("title-label");
        title.setPadding(new Insets(15));
        title.setStyle("-fx-background-color: #ecf0f1; -fx-font-size: 16px;");
        title.setMaxWidth(Double.MAX_VALUE);
        title.setAlignment(Pos.CENTER);
        borderPane.setTop(title);
        
        // Table
        TableView<Password> expiryTable = new TableView<>();
        ObservableList<Password> expiringList = FXCollections.observableArrayList(expiringPasswords);
        
        TableColumn<Password, String> descCol = new TableColumn<>("Description");
        descCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        descCol.prefWidthProperty().bind(expiryTable.widthProperty().multiply(0.30));
        
        TableColumn<Password, String> loginCol = new TableColumn<>("Login");
        loginCol.setCellValueFactory(new PropertyValueFactory<>("login"));
        loginCol.prefWidthProperty().bind(expiryTable.widthProperty().multiply(0.25));
        
        TableColumn<Password, String> dateCol = new TableColumn<>("Date d'expiration");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("expirationDate"));
        dateCol.prefWidthProperty().bind(expiryTable.widthProperty().multiply(0.20));
        
        TableColumn<Password, String> remainingCol = new TableColumn<>("Jours restants");
        remainingCol.prefWidthProperty().bind(expiryTable.widthProperty().multiply(0.25));
        remainingCol.setCellValueFactory(cellData -> {
            Password p = cellData.getValue();
            String expirationDateStr = p.getExpirationDate();
            
            if (expirationDateStr == null || expirationDateStr.isEmpty() || 
                expirationDateStr.equals("None")) {
                return new javafx.beans.property.SimpleStringProperty("N/A");
            }
            
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate expirationDate = LocalDate.parse(expirationDateStr, formatter);
                LocalDate today = LocalDate.now();
                long daysRemaining = ChronoUnit.DAYS.between(today, expirationDate);
                
                if (daysRemaining < 0) {
                    return new javafx.beans.property.SimpleStringProperty("EXPIRÉ (" + Math.abs(daysRemaining) + " jours)");
                } else if (daysRemaining == 0) {
                    return new javafx.beans.property.SimpleStringProperty("AUJOURD'HUI");
                } else {
                    return new javafx.beans.property.SimpleStringProperty(daysRemaining + " jours");
                }
            } catch (Exception e) {
                return new javafx.beans.property.SimpleStringProperty("Erreur");
            }
        });
        
        expiryTable.getColumns().addAll(descCol, loginCol, dateCol, remainingCol);
        expiryTable.setItems(expiringList);
        expiryTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        // Color-code rows based on expiration urgency
        expiryTable.setRowFactory(tv -> {
            TableRow<Password> row = new TableRow<>();
            row.itemProperty().addListener((obs, oldPassword, newPassword) -> {
                if (newPassword != null) {
                    String expirationDateStr = newPassword.getExpirationDate();
                    if (expirationDateStr != null && !expirationDateStr.isEmpty() && 
                        !expirationDateStr.equals("None")) {
                        try {
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                            LocalDate expirationDate = LocalDate.parse(expirationDateStr, formatter);
                            LocalDate today = LocalDate.now();
                            
                            if (expirationDate.isBefore(today)) {
                                row.setStyle("-fx-background-color: #ffcccc;");
                            } else {
                                long daysRemaining = ChronoUnit.DAYS.between(today, expirationDate);
                                if (daysRemaining <= 7) {
                                    row.setStyle("-fx-background-color: #fff3cd;");
                                } else {
                                    row.setStyle("");
                                }
                            }
                        } catch (Exception e) {
                            row.setStyle("");
                        }
                    } else {
                        row.setStyle("");
                    }
                } else {
                    row.setStyle("");
                }
            });
            return row;
        });
        
        VBox centerBox = new VBox(expiryTable);
        centerBox.setPadding(new Insets(15));
        VBox.setVgrow(expiryTable, Priority.ALWAYS);
        borderPane.setCenter(centerBox);
        
        // Close button
        Button closeButton = new Button("Fermer");
        closeButton.getStyleClass().add("button-secondary");
        closeButton.setPrefWidth(120);
        closeButton.setOnAction(e -> dialog.close());
        
        HBox buttonBox = new HBox(closeButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(15));
        buttonBox.setStyle("-fx-background-color: #ecf0f1;");
        borderPane.setBottom(buttonBox);
        
        dialog.show();
    }
}