package group.keyp;

/**
 * Represents a stored password entry with associated metadata.
 * Each password contains login credentials, a description, and an optional expiration date.
 * 
 * <p>This class implements the Model component of the MVC design pattern,
 * representing the core data structure for password storage.</p>
 * 
 * @author Thomas Poissonnier
 */
public class Password {
    
    /**
     * The login or username associated with this password.
     */
    private String login;
    
    /**
     * The actual password value.
     */
    private String password;
    
    /**
     * A description or label for this password (e.g., "Gmail", "Facebook").
     */
    private String description;
    
    /**
     * The expiration date of this password in dd/MM/yyyy format.
     * Can be "None" if no expiration date is set.
     */
    private String expirationDate;
    
    /**
     * Constructs a new Password with all fields specified.
     * 
     * @param _login          the login or username
     * @param _password       the password value
     * @param _description    a description or label for this password
     * @param _expirationDate the expiration date in dd/MM/yyyy format, or "None"
     */
    public Password(String _login, String _password, String _description, String _expirationDate) {
        login = _login;
        password = _password;
        description = _description;
        expirationDate = _expirationDate;
    }
    
    /**
     * Constructs a new Password with no expiration date.
     * The expiration date is automatically set to "None".
     * 
     * @param _id          the unique identifier (not currently used)
     * @param _login       the login or username
     * @param _password    the password value
     * @param _description a description or label for this password
     */
    public Password(int _id, String _login, String _password, String _description) {
        login = _login;
        password = _password;
        description = _description;
        expirationDate = "None";
    }
    
    /**
     * Returns the login or username.
     * 
     * @return the login value
     */
    public String getLogin() {
        return login;
    }
    
    /**
     * Sets the login or username.
     * 
     * @param _login the new login value
     */
    public void setLogin(String _login) {
        login = _login;
    }
    
    /**
     * Returns the password value.
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }
    
    /**
     * Sets the password value.
     * 
     * @param _password the new password
     */
    public void setPassword(String _password) {
        password = _password;
    }
    
    /**
     * Returns the description or label of this password entry.
     * 
     * @return the description
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * Sets the description or label of this password entry.
     * 
     * @param _description the new description
     */
    public void setDescription(String _description) {
        description = _description;
    }
    
    /**
     * Returns the expiration date of this password.
     * 
     * @return the expiration date in dd/MM/yyyy format, or "None" if not set
     */
    public String getExpirationDate() {
        return expirationDate;
    }
    
    /**
     * Sets the expiration date of this password.
     * 
     * @param _date the new expiration date in dd/MM/yyyy format, or "None"
     */
    public void setExpirationDate(String _date) {
        expirationDate = _date;
    }
}