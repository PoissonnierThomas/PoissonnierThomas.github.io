package group.keyp;

/**
 * Defines the contract for encryption strategies.
 * This interface implements the Strategy design pattern, allowing different
 * encryption algorithms to be used interchangeably.
 * 
 * <p>The Strategy pattern enables the application to:</p>
 * <ul>
 *   <li>Encapsulate different encryption algorithms</li>
 *   <li>Make algorithms interchangeable at runtime</li>
 *   <li>Add new algorithms without modifying existing code</li>
 * </ul>
 * 
 * @author Thomas Poissonnier
 * @see AESEncryption
 * @see DESEncryption
 * @see BlowfishEncryption
 */
public interface EncryptionStrategy {
    
    /**
     * Encrypts plain text using the specific algorithm implementation.
     * 
     * @param plainText the text to encrypt
     * @return the encrypted text encoded in Base64
     * @throws Exception if an encryption error occurs
     */
    String encrypt(String plainText) throws Exception;
    
    /**
     * Decrypts encrypted text using the specific algorithm implementation.
     * 
     * @param encryptedText the encrypted text in Base64 format
     * @return the decrypted plain text
     * @throws Exception if a decryption error occurs
     */
    String decrypt(String encryptedText) throws Exception;
    
    /**
     * Returns the name of the encryption algorithm.
     * 
     * @return the algorithm name (e.g., "AES", "DES", "BLOWFISH")
     */
    String getAlgorithmName();
}