package group.keyp;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object (DAO) for managing user password data.
 * This class implements the DAO design pattern, encapsulating all
 * persistence logic for individual user's password collections.
 * 
 * <p>Each user has their own encrypted data file containing:</p>
 * <ul>
 *   <li>User metadata (ID, name, encryption preference)</li>
 *   <li>Collection of stored passwords</li>
 * </ul>
 * 
 * <p>The file format uses the user's chosen encryption algorithm,
 * demonstrating the Strategy pattern in action.</p>
 * 
 * @author Thomas Poissonnier
 */
public class UserDataManager {
    
    /**
     * The login name of the user whose data is being managed.
     */
    private String userLogin;
    
    /**
     * The filename for this user's data file.
     */
    private String userDataFile;
    
    /**
     * Constructs a new UserDataManager for the specified user.
     * 
     * @param login the login name of the user
     */
    public UserDataManager(String login) {
        this.userLogin = login;
        this.userDataFile = UserManager.getUserDataFile(login);
    }
    
    /**
     * Saves user data and password collection to encrypted file.
     * The file format is:
     * <ul>
     *   <li>Line 1: User metadata (id|firstName|lastName|encryptionType)</li>
     *   <li>Lines 2+: Password entries (login|password|description|expirationDate)</li>
     * </ul>
     * 
     * All data is encrypted using the user's chosen encryption algorithm.
     * 
     * @param user the User object containing data to save
     */
    public void saveUserData(User user) {
        String algorithm = user.getEncryptionType() != null ? user.getEncryptionType() : "AES";
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(userDataFile))) {
            // Line 1: User metadata
            String userData = user.getId() + "|" + 
                             user.getFirstName() + "|" + 
                             user.getLastName() + "|" + 
                             algorithm;
            String encryptedUserData = Cryption.encrypt(userData, algorithm);
            writer.write(encryptedUserData);
            writer.newLine();
            
            // Following lines: Password entries
            for (Password password : user.getPasswordTable()) {
                String passwordLine = password.getLogin() + "|" + 
                                     password.getPassword() + "|" + 
                                     password.getDescription() + "|" + 
                                     password.getExpirationDate();
                String encryptedPasswordLine = Cryption.encrypt(passwordLine, algorithm);
                writer.write(encryptedPasswordLine);
                writer.newLine();
            }
            
        } catch (Exception e) {
            System.err.println("Error saving user data: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Loads user data and password collection from encrypted file.
     * If the file doesn't exist, creates a new user with default values.
     * 
     * <p>This method attempts to detect the encryption algorithm by trying
     * each available strategy until one succeeds (for backward compatibility).</p>
     * 
     * @return the User object with loaded data
     */
    public User loadUserData() {
        File file = new File(userDataFile);
        if (!file.exists()) {
            User newUser = new User(1, userLogin, "", "", "AES");
            saveUserData(newUser);
            return newUser;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            // Read first line: User metadata
            String firstLine = reader.readLine();
            if (firstLine == null) {
                return new User(1, userLogin, "", "", "AES");
            }
            
            // Try to decrypt with different algorithms
            String decryptedUserData = null;
            String algorithm = "AES";
            
            try {
                decryptedUserData = Cryption.decrypt(firstLine, "AES");
                algorithm = "AES";
            } catch (Exception e) {
                try {
                    decryptedUserData = Cryption.decrypt(firstLine, "DES");
                    algorithm = "DES";
                } catch (Exception e2) {
                    try {
                        decryptedUserData = Cryption.decrypt(firstLine, "BLOWFISH");
                        algorithm = "BLOWFISH";
                    } catch (Exception e3) {
                        System.err.println("Unable to decrypt file with any algorithm");
                        return new User(1, userLogin, "", "", "AES");
                    }
                }
            }
            
            String[] userParts = decryptedUserData.split("\\|");
            
            int id = Integer.parseInt(userParts[0]);
            String firstName = userParts[1];
            String lastName = userParts[2];
            String encryptionType = userParts.length > 3 ? userParts[3] : algorithm;
            
            User user = new User(id, firstName, lastName, "", encryptionType);
            
            // Read following lines: Password entries
            String line;
            while ((line = reader.readLine()) != null) {
                String decryptedPasswordLine = Cryption.decrypt(line, encryptionType);
                String[] passwordParts = decryptedPasswordLine.split("\\|");
                
                if (passwordParts.length >= 4) {
                    String login = passwordParts[0];
                    String password = passwordParts[1];
                    String description = passwordParts[2];
                    String expirationDate = passwordParts[3];
                    
                    Password p = new Password(login, password, description, expirationDate);
                    user.addPassword(p);
                }
            }
            
            return user;
            
        } catch (Exception e) {
            System.err.println("Error loading user data: " + e.getMessage());
            e.printStackTrace();
            return new User(1, userLogin, "", "", "AES");
        }
    }
}