package group.keyp;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;

/**
 * Implementation of the AES (Advanced Encryption Standard) encryption strategy.
 * AES is a symmetric encryption algorithm using 128, 192, or 256-bit keys.
 * This implementation uses AES-128 for a good balance of security and performance.
 * 
 * <p>AES is the recommended encryption standard and provides:</p>
 * <ul>
 *   <li>High security level (NIST approved)</li>
 *   <li>Good performance</li>
 *   <li>Wide industry adoption</li>
 * </ul>
 * 
 * @author Thomas Poissonnier
 */
public class AESEncryption implements EncryptionStrategy {
    
    /**
     * The AES algorithm identifier.
     */
    private static final String ALGORITHM = "AES";
    
    /**
     * The secret key used for encryption/decryption.
     */
    private static final String SECRET_KEY = "KeypSecretKey123";
    
    /**
     * Encrypts plain text using AES algorithm.
     * 
     * @param plainText the text to encrypt
     * @return the encrypted text encoded in Base64
     * @throws Exception if an encryption error occurs
     */
    @Override
    public String encrypt(String plainText) throws Exception {
        SecretKey secretKey = generateKey();
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }
    
    /**
     * Decrypts encrypted text using AES algorithm.
     * 
     * @param encryptedText the encrypted text in Base64 format
     * @return the decrypted plain text
     * @throws Exception if a decryption error occurs
     */
    @Override
    public String decrypt(String encryptedText) throws Exception {
        SecretKey secretKey = generateKey();
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decodedBytes = Base64.getDecoder().decode(encryptedText);
        byte[] decryptedBytes = cipher.doFinal(decodedBytes);
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }
    
    /**
     * Returns the algorithm name.
     * 
     * @return "AES"
     */
    @Override
    public String getAlgorithmName() {
        return "AES";
    }
    
    /**
     * Generates a 128-bit AES key from the secret key using SHA-256 hashing.
     * 
     * @return the generated SecretKey for AES-128
     * @throws Exception if key generation fails
     */
    private SecretKey generateKey() throws Exception {
        byte[] key = SECRET_KEY.getBytes(StandardCharsets.UTF_8);
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        key = sha.digest(key);
        byte[] keyBytes = new byte[16]; // AES-128
        System.arraycopy(key, 0, keyBytes, 0, 16);
        return new SecretKeySpec(keyBytes, ALGORITHM);
    }
}