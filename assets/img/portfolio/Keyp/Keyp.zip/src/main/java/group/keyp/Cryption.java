package group.keyp;

import java.security.MessageDigest;
import java.util.Base64;
import java.nio.charset.StandardCharsets;

/**
 * Facade class for encryption and decryption operations.
 * This class provides a simplified static interface for the Strategy pattern
 * implementation, making encryption operations easier to use throughout the application.
 * 
 * <p>This class implements the Facade design pattern, hiding the complexity
 * of the Strategy pattern behind simple static methods.</p>
 * 
 * @author Thomas Poissonnier
 * @see EncryptionContext
 * @see EncryptionStrategy
 */
public class Cryption {
    
    /**
     * Encrypts plain text using the specified encryption algorithm.
     * 
     * @param plainText the text to encrypt
     * @param algorithm the encryption algorithm to use (AES, DES, or BLOWFISH)
     * @return the encrypted text encoded in Base64
     * @throws Exception if an encryption error occurs
     */
    public static String encrypt(String plainText, String algorithm) throws Exception {
        EncryptionContext context = new EncryptionContext(algorithm);
        return context.encrypt(plainText);
    }
    
    /**
     * Decrypts encrypted text using the specified encryption algorithm.
     * 
     * @param encryptedText the encrypted text in Base64 format
     * @param algorithm     the encryption algorithm to use (AES, DES, or BLOWFISH)
     * @return the decrypted plain text
     * @throws Exception if a decryption error occurs
     */
    public static String decrypt(String encryptedText, String algorithm) throws Exception {
        EncryptionContext context = new EncryptionContext(algorithm);
        return context.decrypt(encryptedText);
    }
    
    /**
     * Hashes a password using SHA-256 algorithm.
     * This method is used for securely storing user account passwords.
     * 
     * @param password the password to hash
     * @return the password hash encoded in Base64
     * @throws Exception if hashing fails
     */
    public static String hashPassword(String password) throws Exception {
        return EncryptionContext.hashPassword(password);
    }
}