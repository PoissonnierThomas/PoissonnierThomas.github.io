package group.keyp;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Data Access Object (DAO) for managing user accounts.
 * This class implements the DAO design pattern, encapsulating all
 * persistence logic for user account data.
 * 
 * <p>Responsibilities:</p>
 * <ul>
 *   <li>Loading user accounts from encrypted file storage</li>
 *   <li>Saving user accounts to encrypted file storage</li>
 *   <li>User authentication</li>
 *   <li>User registration</li>
 * </ul>
 * 
 * <p>The DAO pattern enables easy switching of data sources (e.g., from files
 * to database) without affecting the rest of the application.</p>
 * 
 * @author Thomas Poissonnier
 */
public class UserManager {
    
    /**
     * The filename for storing user account data.
     */
    private static final String USERS_FILE = "users.dat";
    
    /**
     * Map storing user credentials (login -> hashed password).
     */
    private Map<String, String> users;
    
    /**
     * Constructs a new UserManager and loads existing users from file.
     */
    public UserManager() {
        users = new HashMap<>();
        loadUsers();
    }
    
    /**
     * Loads user accounts from the encrypted file.
     * If the file doesn't exist, creates a default user account.
     * Each line in the file contains an encrypted "login:passwordHash" pair.
     */
    private void loadUsers() {
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            try {
                users.put("Thomas", Cryption.hashPassword("password"));
                saveUsers();
            } catch (Exception e) {
                System.err.println("Error creating default user: " + e.getMessage());
            }
            return;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String decryptedLine = Cryption.decrypt(line, "AES");
                String[] parts = decryptedLine.split(":", 2);
                if (parts.length == 2) {
                    users.put(parts[0], parts[1]);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading users: " + e.getMessage());
        }
    }
    
    /**
     * Saves all user accounts to the encrypted file.
     * Each user account is stored as an encrypted "login:passwordHash" pair.
     */
    public void saveUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (Map.Entry<String, String> entry : users.entrySet()) {
                String line = entry.getKey() + ":" + entry.getValue();
                String encryptedLine = Cryption.encrypt(line, "AES");
                writer.write(encryptedLine);
                writer.newLine();
            }
        } catch (Exception e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }
    
    /**
     * Authenticates a user by verifying their login credentials.
     * 
     * @param login    the user's login name
     * @param password the user's password (will be hashed and compared)
     * @return true if authentication succeeds, false otherwise
     */
    public boolean authenticate(String login, String password) {
        try {
            String hashedPassword = Cryption.hashPassword(password);
            return users.containsKey(login) && users.get(login).equals(hashedPassword);
        } catch (Exception e) {
            System.err.println("Error during authentication: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Registers a new user account.
     * 
     * @param login    the new user's login name
     * @param password the new user's password (will be hashed before storage)
     * @return true if registration succeeds, false if user already exists
     */
    public boolean registerUser(String login, String password) {
        if (users.containsKey(login)) {
            return false; // User already exists
        }
        
        try {
            String hashedPassword = Cryption.hashPassword(password);
            users.put(login, hashedPassword);
            saveUsers();
            return true;
        } catch (Exception e) {
            System.err.println("Error during registration: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Checks if a user account exists.
     * 
     * @param login the login name to check
     * @return true if the user exists, false otherwise
     */
    public boolean userExists(String login) {
        return users.containsKey(login);
    }
    
    /**
     * Returns the filename for a user's data file.
     * 
     * @param login the user's login name
     * @return the filename in format "user_[login].dat"
     */
    public static String getUserDataFile(String login) {
        return "user_" + login + ".dat";
    }
}