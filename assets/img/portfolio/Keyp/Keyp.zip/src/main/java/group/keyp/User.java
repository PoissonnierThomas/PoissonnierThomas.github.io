package group.keyp;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a user of the Keyp password manager application.
 * Each user has personal information and a collection of stored passwords.
 * 
 * <p>This class implements the Model component of the MVC design pattern,
 * encapsulating all user-related data and business logic.</p>
 * 
 * @author Thomas Poissonnier
 */
public class User {
    
    /**
     * Unique identifier for the user.
     */
    private int id;
    
    /**
     * First name of the user.
     */
    private String firstName;
    
    /**
     * Last name of the user.
     */
    private String lastName;
    
    /**
     * The user's account password (stored as hash in the system).
     */
    private String countPassword;
    
    /**
     * List of passwords stored by this user.
     */
    private List<Password> passwordTable;
    
    /**
     * Encryption algorithm chosen by the user (AES, DES, or BLOWFISH).
     */
    private String encryptionType;
    
    /**
     * Constructs a new User with complete information including encryption type.
     * 
     * @param _id            the unique identifier for the user
     * @param fn             the first name of the user
     * @param LN             the last name of the user
     * @param CP             the account password (will be hashed)
     * @param ET             the encryption type (AES, DES, or BLOWFISH)
     */
    public User(int _id, String fn, String LN, String CP, String ET) {
        id = _id;
        firstName = fn;
        lastName = LN;
        countPassword = CP;
        encryptionType = ET;
        passwordTable = new ArrayList<Password>();
    }
    
    /**
     * Constructs a new User with default AES encryption.
     * 
     * @param _id  the unique identifier for the user
     * @param fn   the first name of the user
     * @param LN   the last name of the user
     * @param CP   the account password (will be hashed)
     */
    public User(int _id, String fn, String LN, String CP) {
        id = _id;
        firstName = fn;
        lastName = LN;
        countPassword = CP; 
        passwordTable = new ArrayList<Password>();
    }
    
    /**
     * Returns the unique identifier of the user.
     * 
     * @return the user's ID
     */
    public int getId() {
        return id;
    }
    
    /**
     * Returns the list of passwords stored by this user.
     * 
     * @return the list of Password objects
     */
    public List<Password> getPasswordTable() {
        return passwordTable;
    }
    
    /**
     * Adds a password to the user's password collection.
     * 
     * @param p the Password object to add
     */
    public void addPassword(Password p) {
        passwordTable.add(p);
    }
    
    /**
     * Returns the first name of the user.
     * 
     * @return the user's first name
     */
    public String getFirstName() {
        return firstName;
    }
    
    /**
     * Sets the first name of the user.
     * 
     * @param fn the new first name
     */
    public void setFirstname(String fn) {
        firstName = fn;
    }
    
    /**
     * Returns the last name of the user.
     * 
     * @return the user's last name
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * Sets the last name of the user.
     * 
     * @param ln the new last name
     */
    public void setLastname(String ln) {
        lastName = ln;
    }
    
    /**
     * Returns the user's account password.
     * 
     * @return the account password
     */
    public String getCountPassword() {
        return countPassword;
    }
    
    /**
     * Sets the user's account password.
     * 
     * @param p the new account password
     */
    public void setCountPassword(String p) {
        countPassword = p;
    }
    
    /**
     * Returns the encryption algorithm type used by this user.
     * 
     * @return the encryption type (AES, DES, or BLOWFISH)
     */
    public String getEncryptionType() {
        return encryptionType;
    }
    
    /**
     * Sets the encryption algorithm type for this user.
     * All passwords will be re-encrypted with the new algorithm.
     * 
     * @param E the new encryption type (AES, DES, or BLOWFISH)
     */
    public void setEncryptionType(String E) {
        encryptionType = E;
    }
}