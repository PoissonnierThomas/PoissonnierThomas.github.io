package group.keyp;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;

/**
 * Implementation of the DES (Data Encryption Standard) encryption strategy.
 * DES is an older symmetric encryption algorithm using 56-bit keys.
 * 
 * <p>DES characteristics:</p>
 * <ul>
 *   <li>Lower security (considered weak by modern standards)</li>
 *   <li>Faster performance than AES</li>
 *   <li>Maintained for compatibility with legacy systems</li>
 * </ul>
 * 
 * <p><b>Note:</b> DES is not recommended for new applications requiring high security.</p>
 * 
 * @author Thomas Poissonnier
 */
public class DESEncryption implements EncryptionStrategy {
    
    /**
     * The DES algorithm identifier.
     */
    private static final String ALGORITHM = "DES";
    
    /**
     * The secret key used for encryption/decryption.
     */
    private static final String SECRET_KEY = "KeypSecretKey123";
    
    /**
     * Encrypts plain text using DES algorithm.
     * 
     * @param plainText the text to encrypt
     * @return the encrypted text encoded in Base64
     * @throws Exception if an encryption error occurs
     */
    @Override
    public String encrypt(String plainText) throws Exception {
        SecretKey secretKey = generateKey();
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }
    
    /**
     * Decrypts encrypted text using DES algorithm.
     * 
     * @param encryptedText the encrypted text in Base64 format
     * @return the decrypted plain text
     * @throws Exception if a decryption error occurs
     */
    @Override
    public String decrypt(String encryptedText) throws Exception {
        SecretKey secretKey = generateKey();
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decodedBytes = Base64.getDecoder().decode(encryptedText);
        byte[] decryptedBytes = cipher.doFinal(decodedBytes);
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }
    
    /**
     * Returns the algorithm name.
     * 
     * @return "DES"
     */
    @Override
    public String getAlgorithmName() {
        return "DES";
    }
    
    /**
     * Generates a 56-bit DES key from the secret key using SHA-256 hashing.
     * DES uses 8 bytes (64 bits) but only 56 bits are used as key material.
     * 
     * @return the generated SecretKey for DES
     * @throws Exception if key generation fails
     */
    private SecretKey generateKey() throws Exception {
        byte[] key = SECRET_KEY.getBytes(StandardCharsets.UTF_8);
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        key = sha.digest(key);
        byte[] keyBytes = new byte[8]; // DES uses 8 bytes
        System.arraycopy(key, 0, keyBytes, 0, 8);
        return new SecretKeySpec(keyBytes, ALGORITHM);
    }
}