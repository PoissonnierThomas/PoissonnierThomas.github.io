import './styles.css';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});


// Create header
const header = document.createElement('header');
header.style.cssText = `
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 20px;
  text-align: center;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
`;
header.innerHTML = `
  <h1 style="margin: 0; font-size: 2em; font-weight: bold;">🏉 Weather Rugby</h1>
  <p style="margin: 10px 0 0 0; opacity: 0.9;">Real-time weather for all rugby fields in France</p>
`;
document.body.appendChild(header);

// Create div for the map
const mapDiv = document.createElement('div');
mapDiv.id = 'map';
mapDiv.style.height = 'calc(100vh - 180px)'; // Adjusted for header and footer
mapDiv.style.width = '100%';
document.body.appendChild(mapDiv);

// Create footer
const footer = document.createElement('footer');
footer.style.cssText = `
  background: #2c3e50;
  color: white;
  padding: 15px 20px;
  text-align: center;
  font-size: 0.9em;
  box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
`;
footer.innerHTML = `
  <p style="margin: 0;">
    Data from 
    <a href="https://hub.huwise.com/pages/home/" target="_blank" style="color: #3498db; text-decoration: none;">Huwise</a>,
    <a href="https://www.openstreetmap.org" target="_blank" style="color: #3498db; text-decoration: none;">OpenStreetMap</a> 
    & 
    <a href="https://open-meteo.com" target="_blank" style="color: #3498db; text-decoration: none;">Open-Meteo</a>
    | Created by POISSONNIER Thomas © ${new Date().getFullYear()}
  </p>
`;
document.body.appendChild(footer);


// Initialize map on France
var map = L.map('map').setView([46.603354, 1.888334], 5);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Function to get weather from coordinates
async function getMeteo(latitude, longitude) {
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=Europe/Paris&forecast_days=3`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Weather error:', error);
    return null;
  }
}

// Function to create popup
function createPopupContent(terrain, meteo) {
  let content = `<div style="min-width: 200px;">`;
  content += `<h3 style="margin: 0 0 10px 0;">${terrain.name || 'Rugby field (Unnamed)'}</h3>`;
  
  if (terrain.meta_name_com) {
    content += `<p style="margin: 5px 0;"><strong>📍 City:</strong> ${terrain.meta_name_com}</p>`;
  }
  
  if (terrain.meta_name_dep) {
    content += `<p style="margin: 5px 0;"><strong>Department:</strong> ${terrain.meta_name_dep}</p>`;
  }
  
  if (terrain.type) {
    content += `<p style="margin: 5px 0;"><strong>Type:</strong> ${terrain.type}</p>`;
  }
  
  if (meteo && meteo.current_weather) {
    const temp = meteo.current_weather.temperature;
    const windSpeed = meteo.current_weather.windspeed;
    
    content += `<hr style="margin: 10px 0;">`;
    content += `<p style="margin: 5px 0;"><strong>🌡️ Temperature:</strong> ${temp}°C</p>`;
    content += `<p style="margin: 5px 0;"><strong>💨 Wind:</strong> ${windSpeed} km/h</p>`;
    
    if (meteo.daily) {
      content += `<p style="margin: 5px 0;"><strong>📅 Today:</strong></p>`;
      content += `<p style="margin: 5px 0 5px 15px;">Min: ${meteo.daily.temperature_2m_min[0]}°C | Max: ${meteo.daily.temperature_2m_max[0]}°C</p>`;
      
      if (meteo.daily.precipitation_sum[0] > 0) {
        content += `<p style="margin: 5px 0 5px 15px;">☔ Precipitation: ${meteo.daily.precipitation_sum[0]} mm</p>`;
      }
    }
  } else {
    content += `<p style="margin: 5px 0; color: #888;">Weather not available</p>`;
  }
  
  content += `</div>`;
  return content;
}

// Function to get all Fields
async function fetchAllRugbyFields() {
  const allResults = [];
  let offset = 0;
  const limit = 100; // Number of results per request
  let hasMore = true;
  
  console.log('Starting to collect all fields...');
  
  while (hasMore) {
    try {
      const url = `https://hub.huwise.com/api/explore/v2.1/catalog/datasets/osm-france-sport-facility/records/?limit=${limit}&offset=${offset}&where=sport%3D%27rugby%27`;
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.results && data.results.length > 0) {
        allResults.push(...data.results);
        console.log(`Collected: ${data.results.length} fields (total: ${allResults.length})`);
        offset += limit;
        
        // If we retrieved less than the limit, we have everything
        if (data.results.length < limit) {
          hasMore = false;
        }
      } else {
        hasMore = false;
      }
      
      await new Promise(resolve => setTimeout(resolve, 10));
      
    } catch (error) {
      console.error('Error while collecting:', error);
      hasMore = false;
    }
  }
  
  console.log(`Total fields collected: ${allResults.length}`);
  return allResults;
}

// Main function
async function loadRugbyFields() {
  try {
    // 1. Get all rugby fields
    const allFields = await fetchAllRugbyFields();
    
    console.log('📍 Adding all markers to the map...');
    
    // 2. Add all markers immediately
    const markersData = [];
    for (let i = 0; i < allFields.length; i++) {
      const record = allFields[i];
      const terrain = record.fields || record;
      
      // Get the coordinates 
      let latitude, longitude;
      
      if (terrain.meta_geo_point && terrain.meta_geo_point.lat && terrain.meta_geo_point.lon) {
        latitude = terrain.meta_geo_point.lat;
        longitude = terrain.meta_geo_point.lon;
      } else if (terrain.geo_point_2d) {
        latitude = terrain.geo_point_2d.lat;
        longitude = terrain.geo_point_2d.lon;
      } else if (terrain.coordinates) {
        longitude = terrain.coordinates[0];
        latitude = terrain.coordinates[1];
      } else {
        continue;
      }
      
      // Create marker immediately
      const marker = L.marker([latitude, longitude]).addTo(map);
      
      // Create basic popup without weather
      const basicContent = createPopupContent(terrain, null);
      marker.bindPopup(basicContent);
      
      markersData.push({ marker, terrain, latitude, longitude });
    }
    
    console.log(`✅ ${markersData.length} fields added to the map`);
    console.log('🌤️ Loading weather data for all fields...');
    
    // 3. Load weather data in parallel (batches of 50 for performance)
    const batchSize = 50;
    let processed = 0;
    
    for (let i = 0; i < markersData.length; i += batchSize) {
      const batch = markersData.slice(i, i + batchSize);
      
      // Load weather for all fields in this batch in parallel
      await Promise.all(batch.map(async ({ marker, terrain, latitude, longitude }) => {
        try {
          const meteo = await getMeteo(latitude, longitude);
          const updatedContent = createPopupContent(terrain, meteo);
          marker.setPopupContent(updatedContent);
        } catch (error) {
          console.error('Weather error for field:', terrain.name, error);
        }
      }));
      
      processed += batch.length;
      console.log(`⏳ Weather loaded: ${processed}/${markersData.length} fields`);
      // Small pause between batches to avoid API overload
      if (i + batchSize < markersData.length) {
        await new Promise(resolve => setTimeout(resolve, 10));
      }
    }
    
    console.log(`✅ Finished! All ${markersData.length} fields with weather data loaded`);
     
  } catch (error) {
    console.error('Error while loading fields:', error);
  }
}

// launch loading
loadRugbyFields();