# Weather Rugby

## Student

Poissonnier Thomas  
universitary mail : <thomas.poissonnier@etu.univ-amu.fr>

## Project description

The goal of this web application is to provide users with a map viewer of rugby fields identified by Huwise (<https://hub.huwise.com/explore/assets/osm-france-sport-facility/>).
Its operation is simple: the application loads and stores rugby fields, then browses them one by one to place them on the map (leaflet). As it browses them, it retrieves their longitude and latitude, which will allow us to call a second weather API (<https://open-meteo.com/>) and add weather forecast information to the pin that will be added to the map.

### How it works

1. The application loads all rugby fields from the Huwise API
2. Each field is displayed as a marker on an interactive Leaflet map
3. Weather data is fetched from Open-Meteo API for each field
4. Users can click on any marker to view field details and current weather conditions

### Features 

- Interactive map of France with all rugby fields
- Real-time weather data for each field
- Detailed information about each rugby field (name, city, department)
- Temperature, wind speed and precipitation data
- Responsiv design

## Technologies Used

- **Leaflet** - Interactive maps
- **Webpack** - Module bundler
- **Huwise API** - Rugby fields data
- **Open-Meteo API** - Weather data
- **OpenStreetMap** - Map tiles

## Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

## Installation

### File Structure

To procede with the installation, you must place your files according to this architecture :

```répertoire
Weather_rugby
│   package-lock.json
│   package.json
│   webpack.config.js
├───dist
└───src
    │   index.js
    │   style.scss
    └───images
            rugby.ico
```

### Install Dependencies

Run the following commands in your terminal:

```bash  
# Install dependencies
npm install css-loader html-webpack-plugin leaflet style-loader webpack webpack-cli webpack-dev-server

# Start the development server
npm start
```

The application will open automatically in your browser at <http://localhost:8080>

## Usage

1. The map loads centerend on France
2. All ruby fields are displayed as markers
3. Click on any marker to view :
    - Field name and location
    - Current temperature
    - Wind speed (useful for kickers)
    - Today's min/max temperatures
    - Prepicipitation data (if any)

What you should get :

![Screenshot of the application](/src/images/Screenshot1.jpg "Screenshot Home")
![Screenshot of the application on a marker](/src/images/Screenshot2.jpg "Screenshot on marker")

## Data Sources

- Rugby fields : <https://hub.huwise.com/pages/home/>
- Weather data : <https://open-meteo.com>
- Map tiles : <https://www.openstreetmap.org>