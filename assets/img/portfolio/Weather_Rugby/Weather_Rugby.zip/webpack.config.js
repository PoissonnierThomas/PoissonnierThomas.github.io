const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
    mode: 'development',
    entry: './src/index.js',
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname,'dist'),
        clean:true,
    },
    devServer: {
        static: './dist',
        port: 8080,
        hot: true,
    },
    module: {
        rules: [
          {
            test: /\.css$/i,
            use: ['style-loader', 'css-loader'],
          },
          {
            test: /\.(png|svg|jpg|jpeg|gif)$/i,
            type: 'asset/resource',
          },
        ],
      },
      plugins: [
        new HtmlWebpackPlugin({
          title: 'Weather Rugby',
          favicon: path.resolve(__dirname, './src/images/rugby.ico'),
          meta: {
            viewport: 'width=device-width, initial-scale=1.0',
            charset: 'UTF-8',
          },
        }),
      ],
};